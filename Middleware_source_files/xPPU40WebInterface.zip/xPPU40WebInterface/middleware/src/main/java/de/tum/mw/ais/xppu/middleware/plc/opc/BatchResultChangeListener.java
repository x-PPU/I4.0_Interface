package de.tum.mw.ais.xppu.middleware.plc.opc;

import org.opcfoundation.ua.builtintypes.DataValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prosysopc.ua.client.MonitoredDataItem;
import com.prosysopc.ua.client.MonitoredDataItemListener;

import de.tum.mw.ais.xppu.middleware.plc.ExecuteBatchOperationCallback;
import de.tum.mw.ais.xppu.middleware.plc.ResultCodes;

/**
 * Implementation of {@link MonitoredDataItemListener} that handles changes to the result field of a
 * batch operation.
 *
 * @author Lucas Koehler
 *
 */
public class BatchResultChangeListener implements MonitoredDataItemListener {
	private static final Logger logger = LoggerFactory.getLogger(ResultChangeListener.class);

	private final MonitoredDataItem resultItem;
	private final ExecuteBatchOperationCallback callback;
	private final String operationId;
	private final String resolvedOperationPath;

	/**
	 * A {@link BatchResultChangeListener} registers the change of a batch operation's result
	 * variable once and then notifies the given callback. Afterwards, it removes itself from the
	 * {@link MonitoredDataItem} that it is listening on.
	 *
	 * @param resultItem
	 *            The resultItem to which this listener is registered.
	 * @param callback
	 *            The {@link ExecuteBatchOperationCallback} that is notified about the execution
	 *            result.
	 * @param operationId
	 *            The operation whose execution result is awaited.
	 * @param resolvedOperationPath
	 *            The operation's resolved path
	 */
	public BatchResultChangeListener(MonitoredDataItem resultItem, ExecuteBatchOperationCallback callback,
			String operationId, String resolvedOperationPath) {
		this.resultItem = resultItem;
		this.callback = callback;
		this.operationId = operationId;
		this.resolvedOperationPath = resolvedOperationPath;
	}

	@Override
	public void onDataChange(MonitoredDataItem sender, DataValue prevValue, DataValue value) {
		final String rawResult = (String) value.getValue().getValue();
		if (rawResult == null || rawResult.isEmpty()) {
			logger.debug(
					"Result listener for batch operation with id {} received a null or empty result string -> Ignore it.");
			return;
		}
		final String[] resultArray = rawResult.split(":");
		if (!operationId.equals(resultArray[0])) {
			logger.info("Received result was not for this operation. This operation: {}. Received operation: {}.",
					operationId, resultArray[0]);
			return;
		}

		final int result = Integer.parseInt(resultArray[1]);

		// result code < 0 is a placeholder until the result is written
		if (result < 0) {
			logger.debug(
					"A placeholder result code was received for this operation. Operation ID: {}. Result code: {}.",
					operationId, result);
			return;
		}

		logger.debug("Received result code {} for operation with id {}.", result, operationId);

		if (result == ResultCodes.START) {
			callback.executionStarted(operationId, resolvedOperationPath, result);
			return;
		} else if (result == ResultCodes.SUCCESS) {
			callback.executionSuccessful(operationId, result);
		} else if (result == ResultCodes.CANCEL) {
			callback.executionCanceled(operationId, result);
		} else {
			callback.executionFailed(operationId, result);
		}
		// Remove this listener as it is only supposed to process one operation execution result
		// (except for start)
		resultItem.setDataChangeListener(null);
		logger.debug("Removed this listener from MonitoredDataItem: {}", resultItem);

	}

}
