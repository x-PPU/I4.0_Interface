package de.tum.mw.ais.xppu.middleware.history;

/**
 * A {@link PlcAction} describes what happened for a {@link HistoryEntry}.
 *
 * @author Lucas Koehler
 *
 */
public enum PlcAction {
	/**
	 * The execution of an operation was started.
	 */
	START,
	/**
	 * The execution of a held operation was continued.
	 */
	RESTART,
	/**
	 * The execution of a running operation was paused.
	 */
	HOLD,
	/**
	 * The execution of an operation was canceled (Doesn't matter whether it was running or paused
	 * before).
	 */
	ABORT,
	/**
	 * The execution of an operation was finished and a result code was returned.
	 */
	COMPLETE,
	/**
	 * An automatic batch was started
	 */
	BATCH_START,
	/**
	 * An automatic batch was finished
	 */
	BATCH_COMPLETE,
	/**
	 * The history was set to manual mode.
	 */
	SET_MANUAL_MODE,
	/**
	 * The history was set to automatic mode.
	 */
	SET_AUTOMATIC_MODE,
	/**
	 * An emergency stop occurred.
	 */
	STOP,
	/**
	 * An emergency stop was resolved.
	 */
	RESET
}
