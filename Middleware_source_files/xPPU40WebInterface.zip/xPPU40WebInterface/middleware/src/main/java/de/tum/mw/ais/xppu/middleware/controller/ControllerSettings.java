package de.tum.mw.ais.xppu.middleware.controller;

/**
 * Defines the keys that are used to configure a {@link Controller} instance.
 *
 * @author Lucas Koehler
 *
 */
public enum ControllerSettings {
	/**
	 * The path to the isa88 instance model. Mandatory parameter
	 */
	MODEL_PATH,
	/**
	 * The path to the operation list that is used to resolve the operation usages. Mandatory
	 * parameter
	 */
	OPERATION_LIST_PATH,
	/**
	 * The {@link de.tum.mw.ais.xppu.middleware.history.History History} used by the controller.
	 * Mandatory parameter.
	 */
	HISTORY
}
