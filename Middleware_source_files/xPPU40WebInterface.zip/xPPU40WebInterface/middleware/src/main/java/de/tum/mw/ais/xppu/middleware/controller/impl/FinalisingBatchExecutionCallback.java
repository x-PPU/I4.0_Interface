package de.tum.mw.ais.xppu.middleware.controller.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.tum.mw.ais.xppu.middleware.history.History;
import de.tum.mw.ais.xppu.middleware.history.HistoryException;

/**
 * The {@link FinalisingBatchExecutionCallback} differs from the {@link BatchExecutionCallback} in
 * the regard that it is used for the last operation of a batch: When the
 * {@link #executionSuccessful(String, int)} method is called, the whole batch is finalized in the
 * {@link History}.
 *
 * @author Lucas Koehler
 *
 */
class FinalisingBatchExecutionCallback extends BatchExecutionCallback {
	private static final Logger logger = LoggerFactory.getLogger(FinalisingBatchExecutionCallback.class);

	/**
	 * Creates a new {@link FinalisingBatchExecutionCallback}.
	 *
	 * @param history
	 * @param executionId
	 */
	public FinalisingBatchExecutionCallback(History history, String executionId) {
		super(history, executionId);
	}

	@Override
	public void executionSuccessful(String operationId, int operationResult) {
		try {
			history.completeOperation(executionId, operationResult);
			history.finishBatchExecution(operationResult);
		} catch (final HistoryException e) {
			logger.error("Could not add finish history entry.", e);
		}
	}
}
