package de.tum.mw.ais.xppu.middleware.plc;

/**
 * @author Lucas Koehler
 *
 */
public class PlcConnectionException extends Exception {
	/**
	 * Generated serialization ID.
	 */
	private static final long serialVersionUID = 1632579853529014546L;

	/**
	 * Creates a new {@link PlcConnectionException} with the given detail message.
	 *
	 * @param message
	 *            The exception's detail message
	 */
	public PlcConnectionException(String message) {
		super(message);
	}

	/**
	 * Create a new {@link PlcConnectionException} with the given detail message and cause.
	 *
	 * @param message
	 *            The exception's detail message
	 * @param cause
	 *            The {@link Throwable} that caused this exception
	 */
	public PlcConnectionException(String message, Throwable cause) {
		super(message, cause);
	}
}
