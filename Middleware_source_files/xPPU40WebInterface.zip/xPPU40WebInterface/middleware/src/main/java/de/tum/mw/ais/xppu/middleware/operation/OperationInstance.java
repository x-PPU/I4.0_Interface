package de.tum.mw.ais.xppu.middleware.operation;

import de.tum.mw.ais.isa88.GeneralOperation;
import de.tum.mw.ais.isa88.NamedElement;

/**
 * Information about one resolved instance of an operation in a isa88 model. An instance is defined
 * by its id, operation, path in the model, and resolved path in the model.
 *
 * @author Lucas Koehler
 *
 */
public interface OperationInstance extends OperationInformation {
	/**
	 * The resolved path of the operation usage consists of the hierarchy of {@link NamedElement
	 * NamedElements} that leads to the operation usage.
	 *
	 * @return The human readable and resolved path to the operation
	 */
	String getResolvedPath();

	/**
	 * The resolved {@link GeneralOperation} object that is used
	 *
	 * @return The resolved {@link GeneralOperation}
	 */
	GeneralOperation getOperation();
}
