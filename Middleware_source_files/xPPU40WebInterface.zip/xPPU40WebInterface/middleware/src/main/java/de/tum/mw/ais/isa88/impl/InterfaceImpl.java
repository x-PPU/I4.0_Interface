/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.ITF_Property;
import de.tum.mw.ais.isa88.Interface;
import de.tum.mw.ais.isa88.isa88Package;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Interface</b></em>'. <!--
 * end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.impl.InterfaceImpl#getITF_property <em>ITF property</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InterfaceImpl extends NamedElementImpl implements Interface {
	/**
	 * The cached value of the '{@link #getITF_property() <em>ITF property</em>}' containment
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getITF_property()
	 * @generated
	 * @ordered
	 */
	protected EList<ITF_Property> itF_property;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected InterfaceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.INTERFACE;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList<ITF_Property> getITF_property() {
		if (itF_property == null) {
			itF_property = new EObjectContainmentEList<ITF_Property>(ITF_Property.class, this,
					isa88Package.INTERFACE__ITF_PROPERTY);
		}
		return itF_property;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case isa88Package.INTERFACE__ITF_PROPERTY:
			return ((InternalEList<?>) getITF_property()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case isa88Package.INTERFACE__ITF_PROPERTY:
			return getITF_property();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case isa88Package.INTERFACE__ITF_PROPERTY:
			getITF_property().clear();
			getITF_property().addAll((Collection<? extends ITF_Property>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case isa88Package.INTERFACE__ITF_PROPERTY:
			getITF_property().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case isa88Package.INTERFACE__ITF_PROPERTY:
			return itF_property != null && !itF_property.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} // InterfaceImpl
