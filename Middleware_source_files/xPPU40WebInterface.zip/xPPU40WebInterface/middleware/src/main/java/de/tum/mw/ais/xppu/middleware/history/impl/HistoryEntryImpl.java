package de.tum.mw.ais.xppu.middleware.history.impl;

import java.time.Instant;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

import de.tum.mw.ais.xppu.middleware.history.HistoryEntry;
import de.tum.mw.ais.xppu.middleware.history.PlcAction;

/**
 * Implementation of {@link HistoryEntry}.
 *
 * @author Lucas Koehler
 *
 */
public class HistoryEntryImpl implements HistoryEntry {
	private String operationId;
	private String executionId;
	private String resolvedOperationPath;
	@JsonSerialize(using = ToStringSerializer.class)
	private Instant timestamp;
	private PlcAction action;
	private int resultCode = Integer.MIN_VALUE;

	/**
	 * Private constructor that is used by Jackson.
	 */
	@SuppressWarnings("unused")
	private HistoryEntryImpl() {
	}

	/**
	 * Creates a new {@link HistoryEntryImpl} with the result code set to the minimum integer and
	 * the timestamp set to the current UTC (Coordinated Universal Time).
	 *
	 * @param operationId
	 * @param executionId
	 * @param resolvedOperationPath
	 * @param action
	 */
	public HistoryEntryImpl(String operationId, String executionId, String resolvedOperationPath,
			PlcAction action) {
		this.operationId = operationId;
		this.executionId = executionId;
		this.resolvedOperationPath = resolvedOperationPath;
		this.action = action;
		timestamp = Instant.now();
	}

	/**
	 * Creates a new {@link HistoryEntryImpl} with the timestamp set to the current UTC.
	 *
	 * @param operationId
	 * @param executionId
	 * @param resolvedOperationPath
	 * @param action
	 * @param resultCode
	 */
	public HistoryEntryImpl(String operationId, String executionId, String resolvedOperationPath, PlcAction action,
			int resultCode) {
		this(operationId, executionId, resolvedOperationPath, action);
		this.resultCode = resultCode;
	}

	/**
	 * Creates a {@link HistoryEntryImpl} for the given {@link PlcAction} and with the timestamp set
	 * to the current UTC. Use this constructor to create mode switch entries.
	 *
	 * @param action
	 *            The {@link PlcAction} of the entry
	 *
	 */
	public HistoryEntryImpl(PlcAction action) {
		this("", "", "", action);
	}

	/**
	 * Creates a {@link HistoryEntryImpl} for the given execution id, {@link PlcAction}, and with
	 * the timestamp set to the current UTC.
	 *
	 * @param executionId
	 * @param action
	 */
	public HistoryEntryImpl(String executionId, PlcAction action) {
		this("", executionId, "", action);
	}

	@Override
	public String getOperationId() {
		return operationId;
	}

	/**
	 * @param operationId
	 *            the operationId to set
	 */
	public void setOperationId(String operationId) {
		this.operationId = operationId;
	}

	@Override
	public String getExecutionId() {
		return executionId;
	}

	/**
	 * @param executionId
	 *            the executionId to set
	 */
	public void setExecutionId(String executionId) {
		this.executionId = executionId;
	}

	@Override
	public String getResolvedOperationPath() {
		return resolvedOperationPath;
	}

	/**
	 * @param resolvedOperationPath
	 *            the resolvedOperationPath to set
	 */
	public void setResolvedOperationPath(String resolvedOperationPath) {
		this.resolvedOperationPath = resolvedOperationPath;
	}

	@Override
	public Instant getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp
	 *            the timestamp to set
	 */
	public void setTimestamp(Instant timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public PlcAction getAction() {
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(PlcAction action) {
		this.action = action;
	}

	@Override
	public int getResultCode() {
		return resultCode;
	}

	/**
	 * @param resultCode
	 *            the resultCode to set
	 */
	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((executionId == null) ? 0 : executionId.hashCode());
		result = prime * result + ((operationId == null) ? 0 : operationId.hashCode());
		result = prime * result + ((resolvedOperationPath == null) ? 0 : resolvedOperationPath.hashCode());
		result = prime * result + resultCode;
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof HistoryEntryImpl)) {
			return false;
		}
		final HistoryEntryImpl other = (HistoryEntryImpl) obj;
		if (action != other.action) {
			return false;
		}
		if (executionId == null) {
			if (other.executionId != null) {
				return false;
			}
		} else if (!executionId.equals(other.executionId)) {
			return false;
		}
		if (operationId == null) {
			if (other.operationId != null) {
				return false;
			}
		} else if (!operationId.equals(other.operationId)) {
			return false;
		}
		if (resolvedOperationPath == null) {
			if (other.resolvedOperationPath != null) {
				return false;
			}
		} else if (!resolvedOperationPath.equals(other.resolvedOperationPath)) {
			return false;
		}
		if (resultCode != other.resultCode) {
			return false;
		}
		if (timestamp == null) {
			if (other.timestamp != null) {
				return false;
			}
		} else if (!timestamp.equals(other.timestamp)) {
			return false;
		}
		return true;
	}

}
