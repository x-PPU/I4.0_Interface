/**
 */
package de.tum.mw.ais.isa88;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Enterprise</b></em>'. <!--
 * end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.Enterprise#getSite <em>Site</em>}</li>
 * </ul>
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getEnterprise()
 * @model
 * @generated
 */
public interface Enterprise extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Site</b></em>' containment reference list. The list contents
	 * are of type {@link de.tum.mw.ais.isa88.Site}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Site</em>' containment reference list isn't clear, there really
	 * should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Site</em>' containment reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getEnterprise_Site()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Site> getSite();

} // Enterprise
