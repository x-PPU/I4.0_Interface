package de.tum.mw.ais.xppu.middleware.plc;

/**
 * A callback that is called to handle the result of an invocation of
 * {@link PlcConnection#startOperation(String, ExecuteOperationCallback)}.
 *
 * @author Lucas Koehler
 *
 */
public interface ExecuteOperationCallback {
	/**
	 * Called when the execution of the operation with the given id finished successfully.
	 *
	 * @param operationId
	 *            The id of the executed operation
	 * @param operationResult
	 *            The result code of the execution
	 */
	void executionSuccessful(String operationId, int operationResult);

	/**
	 * Called when the execution of the operation with the given id failed.
	 *
	 * @param operationId
	 *            The id of the executed operation
	 * @param operationResult
	 *            The result code of the execution
	 */
	void executionFailed(String operationId, int operationResult);

	/**
	 * Called when the execution of the operation with the given id was canceled.
	 *
	 * @param operationId
	 *            The id of the executed operation
	 * @param operationResult
	 *            The result code of the execution
	 */
	void executionCanceled(String operationId, int operationResult);
}
