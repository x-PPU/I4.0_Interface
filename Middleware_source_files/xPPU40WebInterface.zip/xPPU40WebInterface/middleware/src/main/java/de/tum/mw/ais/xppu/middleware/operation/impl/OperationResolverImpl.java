package de.tum.mw.ais.xppu.middleware.operation.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.tum.mw.ais.isa88.Enterprise;
import de.tum.mw.ais.isa88.GeneralOperation;
import de.tum.mw.ais.isa88.NamedElement;
import de.tum.mw.ais.xppu.middleware.operation.OperationInformation;
import de.tum.mw.ais.xppu.middleware.operation.OperationInstance;
import de.tum.mw.ais.xppu.middleware.operation.OperationResolver;

/**
 * Implementation of {@link OperationResolver}.
 *
 * @author Lucas Koehler
 *
 */
public class OperationResolverImpl implements OperationResolver {
	// Need to escape the . because it is used as a regex
	private static final String PATH_SEGMENT_SEPARATOR = "\\.";
	private static final String MULTI_REF_REGEX = "[a-zA-Z0-9]+\\(\\d+\\)";
	private static final int INDEX_OFFSET = -1;
	private static Logger logger = LoggerFactory.getLogger(OperationResolverImpl.class);


	@Override
	public Map<String, OperationInstance> resolveOperations(List<OperationInformation> operations,
			Enterprise modelRoot) {
		logger.info("Start resolving {} operation usages against Enterprise with name: \"{}\" and ObjectID: {}",
				operations.size(), modelRoot.getName(), modelRoot.getObjectId());

		final Map<String, OperationInstance> resultMap = new LinkedHashMap<>();
		for (final OperationInformation operation : operations) {
			final String[] pathSegments = operation.getPath().split(PATH_SEGMENT_SEPARATOR);
			// Every type of the isa88 model implements NamedElement
			NamedElement currentSegmentRoot = modelRoot;

			boolean resolvementSuccessful = true;
			final StringBuilder resolvedPathBuilder = new StringBuilder();
			for (final String pathSegment : pathSegments) {
				resolvedPathBuilder.append(currentSegmentRoot.getName());
				resolvedPathBuilder.append('/');

				String structuralFeatureName;
				int featureIndex = 0;
				final boolean multiPathSegment;
				if (pathSegment.matches(MULTI_REF_REGEX)) {
					// The path segment is a multi reference and contains the index in parentheses
					final String[] split = pathSegment.split("[()]");
					structuralFeatureName = split[0];
					featureIndex = Integer.parseInt(split[1]) + INDEX_OFFSET;
					multiPathSegment = true;
				} else {
					structuralFeatureName = pathSegment;
					multiPathSegment = false;
				}

				// Get feature from current root's EClass
				final EStructuralFeature structuralFeature = currentSegmentRoot.eClass()
						.getEStructuralFeature(structuralFeatureName);
				final boolean isStructuralFeatureOk = checkStructuralFeature(structuralFeature, multiPathSegment,
						operation, pathSegment, structuralFeatureName, currentSegmentRoot.eClass());
				if (!isStructuralFeatureOk) {
					resolvementSuccessful = false;
					break;
				}

				if (multiPathSegment) {
					@SuppressWarnings("unchecked")
					final EList<NamedElement> list = (EList<NamedElement>) currentSegmentRoot.eGet(structuralFeature);
					currentSegmentRoot = list.get(featureIndex);
				} else {
					currentSegmentRoot = (NamedElement) currentSegmentRoot.eGet(structuralFeature);
				}
			}

			if (!resolvementSuccessful) {
				// Problem has already been logged when resolvementSuccessful was set to false
				continue;
			}
			if (!(currentSegmentRoot instanceof GeneralOperation)) {
				logger.warn(
						"Could not resolve operation usage because the path did not end in a GeneralOperation. The operation usage's path was: {}",
						operation.getPath());
				continue;
			}
			final GeneralOperation resolvedOperation = (GeneralOperation) currentSegmentRoot;
			resolvedPathBuilder.append(resolvedOperation.getName());
			final OperationInstanceImpl instance = new OperationInstanceImpl(operation, resolvedOperation,
					resolvedPathBuilder.toString());
			resultMap.put(instance.getOperationId(), instance);
			logger.debug("Successfully resolved operation usage with id: {} and resolved path: {}",
					instance.getOperationId(), instance.getResolvedPath());
		}

		logger.info("Successfully resolved {} out of {} operation usages.", resultMap.size(), operations.size());
		return resultMap;
	}

	/**
	 * Checks that the given structural feature, non null, a {@link EReference} and whether it is a
	 * multi reference depending on the given multiPathSegment argument. If anything is wrong, a
	 * message is logged and false returned.
	 *
	 * @param structuralFeature
	 *            The {@link EStructuralFeature} to check, might be null
	 * @param multiPathSegment
	 *            Whether the structural feature is supposed to be a multi feature
	 * @param operation
	 *            Only for logging purposes
	 * @param pathSegment
	 *            Only for logging purposes
	 * @param structuralFeatureName
	 *            Only for logging purposes
	 * @param resolvingEClass
	 *            Only for logging purposes
	 * @return true if the structural feature fulfills all criteria, false otherwise
	 */
	private boolean checkStructuralFeature(final EStructuralFeature structuralFeature, final boolean multiPathSegment,
			final OperationInformation operation, final String pathSegment, String structuralFeatureName,
			EClass resolvingEClass) {
		if (structuralFeature == null) {
			logger.warn(
					"Could not find structural feature \"{}\" in EClass {}. Therefore the operation usage for {} could not be resolved.",
					structuralFeatureName, resolvingEClass.getName(), operation);
			return false;
		}
		if (!(structuralFeature instanceof EReference)) {
			logger.warn(
					"The structural feature resolved from path segment \"{}\" was no EReference. Operation usage for {} could not be resolved.",
					pathSegment, operation);
			return false;
		}
		if (multiPathSegment != structuralFeature.isMany()) {
			if (multiPathSegment) {
				logger.warn(
						"Path segment: {} was given as a multi reference but was resolved as a single reference. Therefore the operation usage for id {} could not be resolved.",
						pathSegment, operation.getOperationId());
				return false;
			}
			logger.warn(
					"Path segment: {} was given as a single reference but was resolved as a multi reference. Therefore the operation usage for id {} could not be resolved.",
					pathSegment, operation.getOperationId());
			return false;
		}
		return true;
	}

}
