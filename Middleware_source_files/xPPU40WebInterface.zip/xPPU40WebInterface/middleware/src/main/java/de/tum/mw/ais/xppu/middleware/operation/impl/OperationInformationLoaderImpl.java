package de.tum.mw.ais.xppu.middleware.operation.impl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.tum.mw.ais.xppu.middleware.operation.OperationInformation;
import de.tum.mw.ais.xppu.middleware.operation.OperationInformationLoader;

/**
 * Implementation of {@link OperationInformationLoader} that loads the operations from a text file.
 *
 * @author Lucas Koehler
 *
 */
public class OperationInformationLoaderImpl implements OperationInformationLoader {
	private static Logger logger = LoggerFactory.getLogger(OperationInformationLoaderImpl.class);
	/**
	 * {@inheritDoc}
	 * <p>
	 * Loads the {@link OperationInformation} from a text file that contains the operations usages
	 * in the following format with one operation usage per line: <strong>id;path;name</strong>
	 */
	@Override
	public List<OperationInformation> loadOperationInformation(String path) throws IOException {
		logger.info("Start reading operations from operation list from file at: {}", path);
		int skippedLines = 0;
		final List<OperationInformation> resultList = new LinkedList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			String line = br.readLine();
			for (; line != null; line = br.readLine()) {
				final String[] parameters = line.trim().split(";");
				if (parameters.length != 3) {
					logger.warn("Could not read line because it did not have the correct format. The line was: {}",
							line);
					skippedLines++;
					continue;
				}

				final String id = parameters[0];
				final String operationPath = parameters[1];
				final String name = parameters[2];
				if (id.isEmpty()) {
					logger.warn("Line was invalid because the ID was empty.");
					skippedLines++;
					continue;
				}
				if (operationPath.isEmpty()) {
					logger.warn("Line was invalid because the path was empty.");
					skippedLines++;
					continue;
				}
				if (name.isEmpty()) {
					logger.warn("Line was invalid because the name was empty.");
					skippedLines++;
					continue;
				}

				// File has format: id;path;name
				resultList.add(new OperationInformationImpl(id, name, operationPath));
			}
		}
		logger.info("Read {} operations and skipped {} lines of the operation list.", resultList.size(), skippedLines);
		return resultList;
	}

}
