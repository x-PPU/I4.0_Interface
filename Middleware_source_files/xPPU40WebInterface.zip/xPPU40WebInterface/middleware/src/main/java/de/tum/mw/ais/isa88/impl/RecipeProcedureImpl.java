/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.RecipeProcedure;
import de.tum.mw.ais.isa88.isa88Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Recipe Procedure</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RecipeProcedureImpl extends GeneralOperationImpl implements RecipeProcedure {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected RecipeProcedureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.RECIPE_PROCEDURE;
	}

} // RecipeProcedureImpl
