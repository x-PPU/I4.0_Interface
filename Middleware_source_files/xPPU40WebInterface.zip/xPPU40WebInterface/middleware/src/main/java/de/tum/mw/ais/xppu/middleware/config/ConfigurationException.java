package de.tum.mw.ais.xppu.middleware.config;

/**
 * An Exception indicating that something went wrong during the creation of a {@link Configuration}.
 * May include usage instructions for the {@link Configuration Configuration's} arguments.
 *
 * @author Lucas Koehler
 *
 */
public class ConfigurationException extends Exception {
	/**
	 * Generated serialization ID.
	 */
	private static final long serialVersionUID = 1681483624453524627L;

	private final String usage;

	ConfigurationException(String message) {
		super(message);
		usage = null;
	}

	ConfigurationException(String message, Throwable cause) {
		super(message, cause);
		usage = null;
	}

	ConfigurationException(String message, Throwable cause, String usage) {
		super(message, cause);
		this.usage = usage;
	}

	/**
	 *
	 * @return The usage message for the configuration that threw this exception. May be null.
	 */
	public String getUsage() {
		return usage;
	}
}
