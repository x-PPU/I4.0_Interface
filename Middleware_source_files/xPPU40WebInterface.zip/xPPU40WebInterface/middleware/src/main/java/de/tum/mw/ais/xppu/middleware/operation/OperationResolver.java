package de.tum.mw.ais.xppu.middleware.operation;

import java.util.List;
import java.util.Map;

import de.tum.mw.ais.isa88.Enterprise;

/**
 * Resolves one or more operations given by their id, name and path to a humanly readable path. Also
 * checks whether the operation is present in the given model.
 *
 * @author Lucas Koehler
 *
 */
public interface OperationResolver {

	/**
	 * Resolves the given operations against the isa88 model given as the model's root
	 * {@link Enterprise} object.
	 *
	 * @param operations
	 *            The list of operations to resolve
	 * @param modelRoot
	 *            The root of the isa88 model
	 * @return The map with the operations' ids as keys and the resolved {@link OperationInstance
	 *         OperationInstances} as values. Does not return null but may return an empty map
	 */
	Map<String, OperationInstance> resolveOperations(List<OperationInformation> operations, Enterprise modelRoot);
}
