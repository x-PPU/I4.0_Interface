/**
 */
package de.tum.mw.ais.isa88;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Constraint Set</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.ConstraintSet#getPre <em>Pre</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.ConstraintSet#getPost <em>Post</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.ConstraintSet#getConstraintSet <em>Constraint Set</em>}</li>
 * </ul>
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getConstraintSet()
 * @model
 * @generated
 */
public interface ConstraintSet extends EObject {
	/**
	 * Returns the value of the '<em><b>Pre</b></em>' containment reference. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pre</em>' containment reference isn't clear, there really should
	 * be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Pre</em>' containment reference.
	 * @see #setPre(Constraint)
	 * @see de.tum.mw.ais.isa88.isa88Package#getConstraintSet_Pre()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Constraint getPre();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.ConstraintSet#getPre <em>Pre</em>}'
	 * containment reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Pre</em>' containment reference.
	 * @see #getPre()
	 * @generated
	 */
	void setPre(Constraint value);

	/**
	 * Returns the value of the '<em><b>Post</b></em>' containment reference. <!-- begin-user-doc
	 * -->
	 * <p>
	 * If the meaning of the '<em>Post</em>' containment reference isn't clear, there really should
	 * be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Post</em>' containment reference.
	 * @see #setPost(Constraint)
	 * @see de.tum.mw.ais.isa88.isa88Package#getConstraintSet_Post()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Constraint getPost();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.ConstraintSet#getPost <em>Post</em>}'
	 * containment reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Post</em>' containment reference.
	 * @see #getPost()
	 * @generated
	 */
	void setPost(Constraint value);

	/**
	 * Returns the value of the '<em><b>Constraint Set</b></em>' reference. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constraint Set</em>' reference isn't clear, there really should be
	 * more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Constraint Set</em>' reference.
	 * @see #setConstraintSet(GeneralOperation)
	 * @see de.tum.mw.ais.isa88.isa88Package#getConstraintSet_ConstraintSet()
	 * @model required="true"
	 * @generated
	 */
	GeneralOperation getConstraintSet();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.ConstraintSet#getConstraintSet
	 * <em>Constraint Set</em>}' reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Constraint Set</em>' reference.
	 * @see #getConstraintSet()
	 * @generated
	 */
	void setConstraintSet(GeneralOperation value);

} // ConstraintSet
