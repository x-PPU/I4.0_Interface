/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.Area;
import de.tum.mw.ais.isa88.Interface;
import de.tum.mw.ais.isa88.Module;
import de.tum.mw.ais.isa88.isa88Package;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Area</b></em>'. <!--
 * end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.impl.AreaImpl#getOwnedModule <em>Owned Module</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.AreaImpl#getInterface <em>Interface</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AreaImpl extends NamedElementImpl implements Area {
	/**
	 * The cached value of the '{@link #getOwnedModule() <em>Owned Module</em>}' containment
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getOwnedModule()
	 * @generated
	 * @ordered
	 */
	protected EList<Module> ownedModule;

	/**
	 * The cached value of the '{@link #getInterface() <em>Interface</em>}' containment reference
	 * list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getInterface()
	 * @generated
	 * @ordered
	 */
	protected EList<Interface> interface_;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected AreaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.AREA;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList<Module> getOwnedModule() {
		if (ownedModule == null) {
			ownedModule = new EObjectContainmentEList<Module>(Module.class, this, isa88Package.AREA__OWNED_MODULE);
		}
		return ownedModule;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList<Interface> getInterface() {
		if (interface_ == null) {
			interface_ = new EObjectContainmentEList<Interface>(Interface.class, this, isa88Package.AREA__INTERFACE);
		}
		return interface_;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case isa88Package.AREA__OWNED_MODULE:
			return ((InternalEList<?>) getOwnedModule()).basicRemove(otherEnd, msgs);
		case isa88Package.AREA__INTERFACE:
			return ((InternalEList<?>) getInterface()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case isa88Package.AREA__OWNED_MODULE:
			return getOwnedModule();
		case isa88Package.AREA__INTERFACE:
			return getInterface();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case isa88Package.AREA__OWNED_MODULE:
			getOwnedModule().clear();
			getOwnedModule().addAll((Collection<? extends Module>) newValue);
			return;
		case isa88Package.AREA__INTERFACE:
			getInterface().clear();
			getInterface().addAll((Collection<? extends Interface>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case isa88Package.AREA__OWNED_MODULE:
			getOwnedModule().clear();
			return;
		case isa88Package.AREA__INTERFACE:
			getInterface().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case isa88Package.AREA__OWNED_MODULE:
			return ownedModule != null && !ownedModule.isEmpty();
		case isa88Package.AREA__INTERFACE:
			return interface_ != null && !interface_.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} // AreaImpl
