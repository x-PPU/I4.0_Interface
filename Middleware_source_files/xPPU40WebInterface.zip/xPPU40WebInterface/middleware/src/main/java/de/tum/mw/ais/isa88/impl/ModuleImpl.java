/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.DataType;
import de.tum.mw.ais.isa88.GeneralOperation;
import de.tum.mw.ais.isa88.Interface;
import de.tum.mw.ais.isa88.Module;
import de.tum.mw.ais.isa88.Property;
import de.tum.mw.ais.isa88.isa88Package;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Module</b></em>'. <!--
 * end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.impl.ModuleImpl#getOwnedProperty <em>Owned Property</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.ModuleImpl#getOwnedGeneralOperation <em>Owned General
 * Operation</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.ModuleImpl#getDatatype <em>Datatype</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.ModuleImpl#getInterface <em>Interface</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.ModuleImpl#getBody <em>Body</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ModuleImpl extends NamedElementImpl implements Module {
	/**
	 * The cached value of the '{@link #getOwnedProperty() <em>Owned Property</em>}' containment
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getOwnedProperty()
	 * @generated
	 * @ordered
	 */
	protected EList<Property> ownedProperty;

	/**
	 * The cached value of the '{@link #getOwnedGeneralOperation() <em>Owned General
	 * Operation</em>}' containment reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getOwnedGeneralOperation()
	 * @generated
	 * @ordered
	 */
	protected EList<GeneralOperation> ownedGeneralOperation;

	/**
	 * The cached value of the '{@link #getDatatype() <em>Datatype</em>}' containment reference
	 * list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getDatatype()
	 * @generated
	 * @ordered
	 */
	protected EList<DataType> datatype;

	/**
	 * The cached value of the '{@link #getInterface() <em>Interface</em>}' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getInterface()
	 * @generated
	 * @ordered
	 */
	protected Interface interface_;

	/**
	 * The default value of the '{@link #getBody() <em>Body</em>}' attribute. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @see #getBody()
	 * @generated
	 * @ordered
	 */
	protected static final String BODY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBody() <em>Body</em>}' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @see #getBody()
	 * @generated
	 * @ordered
	 */
	protected String body = BODY_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected ModuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.MODULE;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList<Property> getOwnedProperty() {
		if (ownedProperty == null) {
			ownedProperty = new EObjectContainmentEList<Property>(Property.class, this,
					isa88Package.MODULE__OWNED_PROPERTY);
		}
		return ownedProperty;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList<GeneralOperation> getOwnedGeneralOperation() {
		if (ownedGeneralOperation == null) {
			ownedGeneralOperation = new EObjectContainmentEList<GeneralOperation>(GeneralOperation.class, this,
					isa88Package.MODULE__OWNED_GENERAL_OPERATION);
		}
		return ownedGeneralOperation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList<DataType> getDatatype() {
		if (datatype == null) {
			datatype = new EObjectContainmentEList<DataType>(DataType.class, this, isa88Package.MODULE__DATATYPE);
		}
		return datatype;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Interface getInterface() {
		if (interface_ != null && interface_.eIsProxy()) {
			InternalEObject oldInterface = (InternalEObject) interface_;
			interface_ = (Interface) eResolveProxy(oldInterface);
			if (interface_ != oldInterface) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, isa88Package.MODULE__INTERFACE,
							oldInterface, interface_));
			}
		}
		return interface_;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Interface basicGetInterface() {
		return interface_;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setInterface(Interface newInterface) {
		Interface oldInterface = interface_;
		interface_ = newInterface;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.MODULE__INTERFACE, oldInterface,
					interface_));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String getBody() {
		return body;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setBody(String newBody) {
		String oldBody = body;
		body = newBody;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.MODULE__BODY, oldBody, body));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case isa88Package.MODULE__OWNED_PROPERTY:
			return ((InternalEList<?>) getOwnedProperty()).basicRemove(otherEnd, msgs);
		case isa88Package.MODULE__OWNED_GENERAL_OPERATION:
			return ((InternalEList<?>) getOwnedGeneralOperation()).basicRemove(otherEnd, msgs);
		case isa88Package.MODULE__DATATYPE:
			return ((InternalEList<?>) getDatatype()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case isa88Package.MODULE__OWNED_PROPERTY:
			return getOwnedProperty();
		case isa88Package.MODULE__OWNED_GENERAL_OPERATION:
			return getOwnedGeneralOperation();
		case isa88Package.MODULE__DATATYPE:
			return getDatatype();
		case isa88Package.MODULE__INTERFACE:
			if (resolve)
				return getInterface();
			return basicGetInterface();
		case isa88Package.MODULE__BODY:
			return getBody();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case isa88Package.MODULE__OWNED_PROPERTY:
			getOwnedProperty().clear();
			getOwnedProperty().addAll((Collection<? extends Property>) newValue);
			return;
		case isa88Package.MODULE__OWNED_GENERAL_OPERATION:
			getOwnedGeneralOperation().clear();
			getOwnedGeneralOperation().addAll((Collection<? extends GeneralOperation>) newValue);
			return;
		case isa88Package.MODULE__DATATYPE:
			getDatatype().clear();
			getDatatype().addAll((Collection<? extends DataType>) newValue);
			return;
		case isa88Package.MODULE__INTERFACE:
			setInterface((Interface) newValue);
			return;
		case isa88Package.MODULE__BODY:
			setBody((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case isa88Package.MODULE__OWNED_PROPERTY:
			getOwnedProperty().clear();
			return;
		case isa88Package.MODULE__OWNED_GENERAL_OPERATION:
			getOwnedGeneralOperation().clear();
			return;
		case isa88Package.MODULE__DATATYPE:
			getDatatype().clear();
			return;
		case isa88Package.MODULE__INTERFACE:
			setInterface((Interface) null);
			return;
		case isa88Package.MODULE__BODY:
			setBody(BODY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case isa88Package.MODULE__OWNED_PROPERTY:
			return ownedProperty != null && !ownedProperty.isEmpty();
		case isa88Package.MODULE__OWNED_GENERAL_OPERATION:
			return ownedGeneralOperation != null && !ownedGeneralOperation.isEmpty();
		case isa88Package.MODULE__DATATYPE:
			return datatype != null && !datatype.isEmpty();
		case isa88Package.MODULE__INTERFACE:
			return interface_ != null;
		case isa88Package.MODULE__BODY:
			return BODY_EDEFAULT == null ? body != null : !BODY_EDEFAULT.equals(body);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Body: ");
		result.append(body);
		result.append(')');
		return result.toString();
	}

} // ModuleImpl
