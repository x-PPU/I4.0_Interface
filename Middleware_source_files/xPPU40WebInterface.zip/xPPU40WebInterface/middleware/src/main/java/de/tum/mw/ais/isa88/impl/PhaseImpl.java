/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.Phase;
import de.tum.mw.ais.isa88.isa88Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Phase</b></em>'. <!--
 * end-user-doc -->
 *
 * @generated
 */
public class PhaseImpl extends GeneralOperationImpl implements Phase {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected PhaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.PHASE;
	}

} // PhaseImpl
