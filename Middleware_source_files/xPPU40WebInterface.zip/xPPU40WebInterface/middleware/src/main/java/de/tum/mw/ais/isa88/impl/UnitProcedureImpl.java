/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.UnitProcedure;
import de.tum.mw.ais.isa88.isa88Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Unit Procedure</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class UnitProcedureImpl extends GeneralOperationImpl implements UnitProcedure {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected UnitProcedureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.UNIT_PROCEDURE;
	}

} // UnitProcedureImpl
