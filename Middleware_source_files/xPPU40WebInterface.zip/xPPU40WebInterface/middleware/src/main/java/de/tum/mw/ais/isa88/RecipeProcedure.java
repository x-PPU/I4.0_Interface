/**
 */
package de.tum.mw.ais.isa88;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Recipe Procedure</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getRecipeProcedure()
 * @model
 * @generated
 */
public interface RecipeProcedure extends GeneralOperation {
} // RecipeProcedure
