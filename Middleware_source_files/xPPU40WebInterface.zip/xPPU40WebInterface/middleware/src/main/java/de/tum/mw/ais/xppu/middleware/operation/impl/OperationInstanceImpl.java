package de.tum.mw.ais.xppu.middleware.operation.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;

import de.tum.mw.ais.isa88.GeneralOperation;
import de.tum.mw.ais.xppu.middleware.operation.OperationInformation;
import de.tum.mw.ais.xppu.middleware.operation.OperationInstance;

/**
 * Implementation of {@link OperationInstance}.
 *
 * @author Lucas Koehler
 *
 */
public class OperationInstanceImpl extends OperationInformationImpl implements OperationInstance {
	private String resolvedPath;
	@JsonIgnore
	private GeneralOperation operation;

	/**
	 * Private constructor for JSON
	 */
	@SuppressWarnings("unused")
	private OperationInstanceImpl() {
	}

	/**
	 * Creates a new {@link OperationInstanceImpl} from an {@link OperationInformation} instance.
	 * This should be the instance that this {@link OperationInstanceImpl} was resolved from.
	 * <p>
	 * <strong>All parameters must not be null.</strong>
	 *
	 * @param operationInformation
	 *            The {@link OperationInformation} from which this {@link OperationInstance} was
	 *            resolved
	 * @param operation
	 *            The operation EObject
	 * @param resolvedPath
	 *            The resolved path of the operation usage
	 */
	public OperationInstanceImpl(OperationInformation operationInformation, GeneralOperation operation,
			String resolvedPath) {
		super(operationInformation.getOperationId(), operationInformation.getName(), operationInformation.getPath());
		this.operation = operation;
		this.resolvedPath = resolvedPath;
	}

	/**
	 * Creates a new {@link OperationInstanceImpl}.
	 * <p>
	 * <strong>All parameters must not be null.</strong>
	 *
	 * @param operationId
	 *            The operation's unique id
	 * @param name
	 *            The operation's name
	 * @param path
	 *            The unambiguous path to the operation's usage in the isa88 model
	 * @param operation
	 *            The operation EObject
	 * @param resolvedPath
	 *            The resolved path of the operation usage
	 */
	public OperationInstanceImpl(String operationId, String name, String path, GeneralOperation operation,
			String resolvedPath) {
		super(operationId, name, path);
		this.operation = operation;
		this.resolvedPath = resolvedPath;
	}

	@Override
	public String getResolvedPath() {
		return resolvedPath;
	}

	/**
	 * @param resolvedPath
	 *            the resolvedPath to set
	 */
	public void setResolvedPath(String resolvedPath) {
		this.resolvedPath = resolvedPath;
	}

	@Override
	public GeneralOperation getOperation() {
		return operation;
	}

	/**
	 * @param operation
	 *            the operation to set
	 */
	public void setOperation(GeneralOperation operation) {
		this.operation = operation;
	}

	@Override
	public String toString() {
		return String.format("OperationInstanceImpl [operationId=%s, name=%s, resolvedPath=%s]", getOperationId(),
				getName(), resolvedPath);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((operation == null) ? 0 : operation.hashCode());
		result = prime * result + ((resolvedPath == null) ? 0 : resolvedPath.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof OperationInstanceImpl)) {
			return false;
		}
		final OperationInstanceImpl other = (OperationInstanceImpl) obj;
		if (operation == null) {
			if (other.operation != null) {
				return false;
			}
		} else if (!operation.equals(other.operation)) {
			return false;
		}
		if (resolvedPath == null) {
			if (other.resolvedPath != null) {
				return false;
			}
		} else if (!resolvedPath.equals(other.resolvedPath)) {
			return false;
		}
		return true;
	}

}
