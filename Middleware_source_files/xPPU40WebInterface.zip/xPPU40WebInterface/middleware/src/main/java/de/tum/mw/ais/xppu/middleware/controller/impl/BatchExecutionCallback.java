package de.tum.mw.ais.xppu.middleware.controller.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.tum.mw.ais.xppu.middleware.history.History;
import de.tum.mw.ais.xppu.middleware.history.HistoryException;
import de.tum.mw.ais.xppu.middleware.plc.ExecuteBatchOperationCallback;

/**
 * @author Lucas Koehler
 *
 */
class BatchExecutionCallback implements ExecuteBatchOperationCallback {
	private static final Logger logger = LoggerFactory.getLogger(ExecuteBatchOperationCallback.class);

	/**
	 * The batch's execution id
	 */
	protected final String executionId;
	/**
	 * The {@link History} to write execution events to
	 */
	protected final History history;

	/**
	 * Creates a {@link BatchExecutionCallback}.
	 *
	 * @param history
	 *            The history to write events to
	 * @param executionId
	 *            The batch's execution id
	 */
	public BatchExecutionCallback(History history, String executionId) {
		this.history = history;
		this.executionId = executionId;
	}

	@Override
	public void executionSuccessful(String operationId, int operationResult) {
		try {
			history.completeOperation(executionId, operationResult);
		} catch (final HistoryException e) {
			logger.error("Could not add finish history entry.", e);
		}
	}

	@Override
	public void executionFailed(String operationId, int operationResult) {
		try {
			history.completeOperation(executionId, operationResult);
			history.finishBatchExecution(operationResult);
		} catch (final HistoryException e) {
			logger.error("Could not add history entry.", e);
		}
	}

	@Override
	public void executionCanceled(String operationId, int operationResult) {
		try {
			// History cancel entry already added in controller

			history.finishBatchExecution(operationResult);
		} catch (final HistoryException e) {
			history.resetOffer();
			logger.error("Could not add history entry.", e);
		}
	}

	@Override
	public void executionStarted(String operationId, String resolvedOperationPath, int resultCode) {
		try {
			history.startBatchOperation(executionId, operationId, resolvedOperationPath);
		} catch (final HistoryException e) {
			logger.error("Could not add execute batch operation history entry.", e);
		}
	}
}
