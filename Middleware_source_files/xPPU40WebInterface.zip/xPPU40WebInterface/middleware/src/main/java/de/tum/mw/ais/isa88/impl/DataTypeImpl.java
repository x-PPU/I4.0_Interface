/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.DataType;
import de.tum.mw.ais.isa88.isa88Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Data Type</b></em>'. <!--
 * end-user-doc -->
 *
 * @generated
 */
public class DataTypeImpl extends NamedElementImpl implements DataType {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected DataTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.DATA_TYPE;
	}

} // DataTypeImpl
