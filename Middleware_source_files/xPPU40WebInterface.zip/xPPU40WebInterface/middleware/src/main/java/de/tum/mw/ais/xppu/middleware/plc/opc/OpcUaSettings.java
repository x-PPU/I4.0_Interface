package de.tum.mw.ais.xppu.middleware.plc.opc;

/**
 * Specifies the different initialization parameters of a {@link OpcUaConnection}.
 *
 * @author Lucas Koehler
 *
 */
public enum OpcUaSettings {

	/**
	 * The opc uri of the opc ua server. Must be given as a {@link String}.
	 */
	SERVER_URI,
	/**
	 * The opc namespace index of the namespace in which the communication variables are located on
	 * the opc ua server. Must be given as an {@link Integer}.
	 * <p>
	 * <strong>Note:</strong> Only the namespace index or the namespace uri have to be provided. If
	 * both are given, the index is used.
	 */
	NAMESPACE_INDEX,
	/**
	 * The opc namespace uri of the namespace in which the communication variables are located on
	 * the opc ua server. Must be given as a {@link String}.
	 * <p>
	 * <strong>Note:</strong> Only the namespace index or the namespace uri have to be provided. If
	 * both are given, the index is used.
	 */
	NAMESPACE_URI,
	/**
	 * The 'flag switch delay' is the delay that is used when (boolean) variables on the plc are
	 * switched back and forth (e.g. <code>true -> false -> true</code>) to trigger rising or
	 * falling edges. The delay may be necessary because the PLC does not recognize rising or
	 * falling edges if the switch is executed too quickly.
	 */
	FLAG_SWITCH_DELAY,
	/**
	 * The {@link de.tum.mw.ais.xppu.middleware.history.History History} that is notified in case of
	 * an emergency stop.
	 */
	HISTORY
}
