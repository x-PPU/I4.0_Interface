/**
 */
package de.tum.mw.ais.isa88;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Operation</b></em>'. <!--
 * end-user-doc -->
 *
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getOperation()
 * @model
 * @generated
 */
public interface Operation extends GeneralOperation {
} // Operation
