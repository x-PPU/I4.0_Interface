/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.Constraint;
import de.tum.mw.ais.isa88.ConstraintSet;
import de.tum.mw.ais.isa88.GeneralOperation;
import de.tum.mw.ais.isa88.isa88Package;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Constraint Set</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.impl.ConstraintSetImpl#getPre <em>Pre</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.ConstraintSetImpl#getPost <em>Post</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.ConstraintSetImpl#getConstraintSet <em>Constraint
 * Set</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConstraintSetImpl extends MinimalEObjectImpl.Container implements ConstraintSet {
	/**
	 * The cached value of the '{@link #getPre() <em>Pre</em>}' containment reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getPre()
	 * @generated
	 * @ordered
	 */
	protected Constraint pre;

	/**
	 * The cached value of the '{@link #getPost() <em>Post</em>}' containment reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getPost()
	 * @generated
	 * @ordered
	 */
	protected Constraint post;

	/**
	 * The cached value of the '{@link #getConstraintSet() <em>Constraint Set</em>}' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getConstraintSet()
	 * @generated
	 * @ordered
	 */
	protected GeneralOperation constraintSet;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected ConstraintSetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.CONSTRAINT_SET;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Constraint getPre() {
		return pre;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public NotificationChain basicSetPre(Constraint newPre, NotificationChain msgs) {
		Constraint oldPre = pre;
		pre = newPre;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					isa88Package.CONSTRAINT_SET__PRE, oldPre, newPre);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setPre(Constraint newPre) {
		if (newPre != pre) {
			NotificationChain msgs = null;
			if (pre != null)
				msgs = ((InternalEObject) pre).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - isa88Package.CONSTRAINT_SET__PRE, null, msgs);
			if (newPre != null)
				msgs = ((InternalEObject) newPre).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - isa88Package.CONSTRAINT_SET__PRE, null, msgs);
			msgs = basicSetPre(newPre, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.CONSTRAINT_SET__PRE, newPre, newPre));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Constraint getPost() {
		return post;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public NotificationChain basicSetPost(Constraint newPost, NotificationChain msgs) {
		Constraint oldPost = post;
		post = newPost;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					isa88Package.CONSTRAINT_SET__POST, oldPost, newPost);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setPost(Constraint newPost) {
		if (newPost != post) {
			NotificationChain msgs = null;
			if (post != null)
				msgs = ((InternalEObject) post).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - isa88Package.CONSTRAINT_SET__POST, null, msgs);
			if (newPost != null)
				msgs = ((InternalEObject) newPost).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - isa88Package.CONSTRAINT_SET__POST, null, msgs);
			msgs = basicSetPost(newPost, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.CONSTRAINT_SET__POST, newPost, newPost));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public GeneralOperation getConstraintSet() {
		if (constraintSet != null && constraintSet.eIsProxy()) {
			InternalEObject oldConstraintSet = (InternalEObject) constraintSet;
			constraintSet = (GeneralOperation) eResolveProxy(oldConstraintSet);
			if (constraintSet != oldConstraintSet) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							isa88Package.CONSTRAINT_SET__CONSTRAINT_SET, oldConstraintSet, constraintSet));
			}
		}
		return constraintSet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public GeneralOperation basicGetConstraintSet() {
		return constraintSet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setConstraintSet(GeneralOperation newConstraintSet) {
		GeneralOperation oldConstraintSet = constraintSet;
		constraintSet = newConstraintSet;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.CONSTRAINT_SET__CONSTRAINT_SET,
					oldConstraintSet, constraintSet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case isa88Package.CONSTRAINT_SET__PRE:
			return basicSetPre(null, msgs);
		case isa88Package.CONSTRAINT_SET__POST:
			return basicSetPost(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case isa88Package.CONSTRAINT_SET__PRE:
			return getPre();
		case isa88Package.CONSTRAINT_SET__POST:
			return getPost();
		case isa88Package.CONSTRAINT_SET__CONSTRAINT_SET:
			if (resolve)
				return getConstraintSet();
			return basicGetConstraintSet();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case isa88Package.CONSTRAINT_SET__PRE:
			setPre((Constraint) newValue);
			return;
		case isa88Package.CONSTRAINT_SET__POST:
			setPost((Constraint) newValue);
			return;
		case isa88Package.CONSTRAINT_SET__CONSTRAINT_SET:
			setConstraintSet((GeneralOperation) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case isa88Package.CONSTRAINT_SET__PRE:
			setPre((Constraint) null);
			return;
		case isa88Package.CONSTRAINT_SET__POST:
			setPost((Constraint) null);
			return;
		case isa88Package.CONSTRAINT_SET__CONSTRAINT_SET:
			setConstraintSet((GeneralOperation) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case isa88Package.CONSTRAINT_SET__PRE:
			return pre != null;
		case isa88Package.CONSTRAINT_SET__POST:
			return post != null;
		case isa88Package.CONSTRAINT_SET__CONSTRAINT_SET:
			return constraintSet != null;
		}
		return super.eIsSet(featureID);
	}

} // ConstraintSetImpl
