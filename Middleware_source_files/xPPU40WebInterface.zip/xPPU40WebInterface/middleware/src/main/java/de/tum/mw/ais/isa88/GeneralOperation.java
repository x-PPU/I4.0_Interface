/**
 */
package de.tum.mw.ais.isa88;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>General Operation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#getPre <em>Pre</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#getPost <em>Post</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#getBody <em>Body</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#getOwnedGeneralOperation <em>Owned General
 * Operation</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#isIs_implemented <em>Is implemented</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#isAvailable_for_user <em>Available for
 * user</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#getHolding_Routine <em>Holding Routine</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#getReset_Routine <em>Reset Routine</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.GeneralOperation#getAbort_Routine <em>Abort Routine</em>}</li>
 * </ul>
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation()
 * @model
 * @generated
 */
public interface GeneralOperation extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Pre</b></em>' containment reference. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pre</em>' containment reference isn't clear, there really should
	 * be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Pre</em>' containment reference.
	 * @see #setPre(Constraint)
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_Pre()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Constraint getPre();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.GeneralOperation#getPre <em>Pre</em>}'
	 * containment reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Pre</em>' containment reference.
	 * @see #getPre()
	 * @generated
	 */
	void setPre(Constraint value);

	/**
	 * Returns the value of the '<em><b>Post</b></em>' containment reference. <!-- begin-user-doc
	 * -->
	 * <p>
	 * If the meaning of the '<em>Post</em>' containment reference isn't clear, there really should
	 * be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Post</em>' containment reference.
	 * @see #setPost(Constraint)
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_Post()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Constraint getPost();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.GeneralOperation#getPost <em>Post</em>}'
	 * containment reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Post</em>' containment reference.
	 * @see #getPost()
	 * @generated
	 */
	void setPost(Constraint value);

	/**
	 * Returns the value of the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Body</em>' attribute isn't clear, there really should be more of a
	 * description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Body</em>' attribute.
	 * @see #setBody(String)
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_Body()
	 * @model
	 * @generated
	 */
	String getBody();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.GeneralOperation#getBody <em>Body</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Body</em>' attribute.
	 * @see #getBody()
	 * @generated
	 */
	void setBody(String value);

	/**
	 * Returns the value of the '<em><b>Owned General Operation</b></em>' reference list. The list
	 * contents are of type {@link de.tum.mw.ais.isa88.GeneralOperation}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned General Operation</em>' reference list isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Owned General Operation</em>' reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_OwnedGeneralOperation()
	 * @model
	 * @generated
	 */
	EList<GeneralOperation> getOwnedGeneralOperation();

	/**
	 * Returns the value of the '<em><b>Is implemented</b></em>' attribute. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is implemented</em>' attribute isn't clear, there really should be
	 * more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Is implemented</em>' attribute.
	 * @see #setIs_implemented(boolean)
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_Is_implemented()
	 * @model required="true"
	 * @generated
	 */
	boolean isIs_implemented();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.GeneralOperation#isIs_implemented <em>Is
	 * implemented</em>}' attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Is implemented</em>' attribute.
	 * @see #isIs_implemented()
	 * @generated
	 */
	void setIs_implemented(boolean value);

	/**
	 * Returns the value of the '<em><b>Available for user</b></em>' attribute. <!-- begin-user-doc
	 * -->
	 * <p>
	 * If the meaning of the '<em>Available for user</em>' attribute isn't clear, there really
	 * should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Available for user</em>' attribute.
	 * @see #setAvailable_for_user(boolean)
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_Available_for_user()
	 * @model required="true"
	 * @generated
	 */
	boolean isAvailable_for_user();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.GeneralOperation#isAvailable_for_user
	 * <em>Available for user</em>}' attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Available for user</em>' attribute.
	 * @see #isAvailable_for_user()
	 * @generated
	 */
	void setAvailable_for_user(boolean value);

	/**
	 * Returns the value of the '<em><b>Holding Routine</b></em>' attribute. The default value is
	 * <code>""</code>. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Holding Routine</em>' attribute isn't clear, there really should
	 * be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Holding Routine</em>' attribute.
	 * @see #setHolding_Routine(String)
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_Holding_Routine()
	 * @model default=""
	 * @generated
	 */
	String getHolding_Routine();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.GeneralOperation#getHolding_Routine
	 * <em>Holding Routine</em>}' attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Holding Routine</em>' attribute.
	 * @see #getHolding_Routine()
	 * @generated
	 */
	void setHolding_Routine(String value);

	/**
	 * Returns the value of the '<em><b>Reset Routine</b></em>' attribute. The default value is
	 * <code>""</code>. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reset Routine</em>' attribute isn't clear, there really should be
	 * more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Reset Routine</em>' attribute.
	 * @see #setReset_Routine(String)
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_Reset_Routine()
	 * @model default=""
	 * @generated
	 */
	String getReset_Routine();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.GeneralOperation#getReset_Routine <em>Reset
	 * Routine</em>}' attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Reset Routine</em>' attribute.
	 * @see #getReset_Routine()
	 * @generated
	 */
	void setReset_Routine(String value);

	/**
	 * Returns the value of the '<em><b>Abort Routine</b></em>' attribute. The default value is
	 * <code>""</code>. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Abort Routine</em>' attribute isn't clear, there really should be
	 * more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Abort Routine</em>' attribute.
	 * @see #setAbort_Routine(String)
	 * @see de.tum.mw.ais.isa88.isa88Package#getGeneralOperation_Abort_Routine()
	 * @model default=""
	 * @generated
	 */
	String getAbort_Routine();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.GeneralOperation#getAbort_Routine <em>Abort
	 * Routine</em>}' attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Abort Routine</em>' attribute.
	 * @see #getAbort_Routine()
	 * @generated
	 */
	void setAbort_Routine(String value);

} // GeneralOperation
