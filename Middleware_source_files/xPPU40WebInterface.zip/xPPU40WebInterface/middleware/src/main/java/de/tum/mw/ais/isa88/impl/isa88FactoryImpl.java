/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc --> An implementation of the model <b>Factory</b>. <!-- end-user-doc -->
 * 
 * @generated
 */
public class isa88FactoryImpl extends EFactoryImpl implements isa88Factory {
	/**
	 * Creates the default factory implementation. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public static isa88Factory init() {
		try {
			isa88Factory theisa88Factory = (isa88Factory) EPackage.Registry.INSTANCE.getEFactory(isa88Package.eNS_URI);
			if (theisa88Factory != null) {
				return theisa88Factory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new isa88FactoryImpl();
	}

	/**
	 * Creates an instance of the factory. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public isa88FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case isa88Package.PROPERTY:
			return createProperty();
		case isa88Package.MODULE:
			return createModule();
		case isa88Package.DATA_TYPE:
			return createDataType();
		case isa88Package.PROCESS_CELL:
			return createProcessCell();
		case isa88Package.UNIT:
			return createUnit();
		case isa88Package.EQUIPMENT_MODULE:
			return createEquipmentModule();
		case isa88Package.CONTROL_MODULE:
			return createControlModule();
		case isa88Package.NAMED_ELEMENT:
			return createNamedElement();
		case isa88Package.GENERAL_OPERATION:
			return createGeneralOperation();
		case isa88Package.RECIPE_PROCEDURE:
			return createRecipeProcedure();
		case isa88Package.UNIT_PROCEDURE:
			return createUnitProcedure();
		case isa88Package.OPERATION:
			return createOperation();
		case isa88Package.PHASE:
			return createPhase();
		case isa88Package.CONSTRAINT:
			return createConstraint();
		case isa88Package.CONSTRAINT_SET:
			return createConstraintSet();
		case isa88Package.AREA:
			return createArea();
		case isa88Package.SITE:
			return createSite();
		case isa88Package.ENTERPRISE:
			return createEnterprise();
		case isa88Package.INTERFACE:
			return createInterface();
		case isa88Package.ITF_PROPERTY:
			return createITF_Property();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Property createProperty() {
		PropertyImpl property = new PropertyImpl();
		return property;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Module createModule() {
		ModuleImpl module = new ModuleImpl();
		return module;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public DataType createDataType() {
		DataTypeImpl dataType = new DataTypeImpl();
		return dataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public ProcessCell createProcessCell() {
		ProcessCellImpl processCell = new ProcessCellImpl();
		return processCell;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Unit createUnit() {
		UnitImpl unit = new UnitImpl();
		return unit;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EquipmentModule createEquipmentModule() {
		EquipmentModuleImpl equipmentModule = new EquipmentModuleImpl();
		return equipmentModule;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public ControlModule createControlModule() {
		ControlModuleImpl controlModule = new ControlModuleImpl();
		return controlModule;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public NamedElement createNamedElement() {
		NamedElementImpl namedElement = new NamedElementImpl();
		return namedElement;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public GeneralOperation createGeneralOperation() {
		GeneralOperationImpl generalOperation = new GeneralOperationImpl();
		return generalOperation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public RecipeProcedure createRecipeProcedure() {
		RecipeProcedureImpl recipeProcedure = new RecipeProcedureImpl();
		return recipeProcedure;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public UnitProcedure createUnitProcedure() {
		UnitProcedureImpl unitProcedure = new UnitProcedureImpl();
		return unitProcedure;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Operation createOperation() {
		OperationImpl operation = new OperationImpl();
		return operation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Phase createPhase() {
		PhaseImpl phase = new PhaseImpl();
		return phase;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Constraint createConstraint() {
		ConstraintImpl constraint = new ConstraintImpl();
		return constraint;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public ConstraintSet createConstraintSet() {
		ConstraintSetImpl constraintSet = new ConstraintSetImpl();
		return constraintSet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Area createArea() {
		AreaImpl area = new AreaImpl();
		return area;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Site createSite() {
		SiteImpl site = new SiteImpl();
		return site;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Enterprise createEnterprise() {
		EnterpriseImpl enterprise = new EnterpriseImpl();
		return enterprise;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Interface createInterface() {
		InterfaceImpl interface_ = new InterfaceImpl();
		return interface_;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public ITF_Property createITF_Property() {
		ITF_PropertyImpl itF_Property = new ITF_PropertyImpl();
		return itF_Property;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public isa88Package getisa88Package() {
		return (isa88Package) getEPackage();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static isa88Package getPackage() {
		return isa88Package.eINSTANCE;
	}

} // isa88FactoryImpl
