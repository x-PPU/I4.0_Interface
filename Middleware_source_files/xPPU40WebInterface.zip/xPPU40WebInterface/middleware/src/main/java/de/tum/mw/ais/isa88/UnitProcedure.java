/**
 */
package de.tum.mw.ais.isa88;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Unit Procedure</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getUnitProcedure()
 * @model
 * @generated
 */
public interface UnitProcedure extends GeneralOperation {
} // UnitProcedure
