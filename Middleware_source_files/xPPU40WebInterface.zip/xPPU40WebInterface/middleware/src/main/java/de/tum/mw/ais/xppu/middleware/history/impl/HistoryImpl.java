package de.tum.mw.ais.xppu.middleware.history.impl;

import java.time.Instant;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.tum.mw.ais.xppu.middleware.history.History;
import de.tum.mw.ais.xppu.middleware.history.HistoryEntry;
import de.tum.mw.ais.xppu.middleware.history.HistoryException;
import de.tum.mw.ais.xppu.middleware.history.PlcAction;
import de.tum.mw.ais.xppu.middleware.plc.ResultCodes;

/**
 * Implementation of {@link History}.
 *
 * @author Lucas Koehler
 *
 */
public class HistoryImpl implements History {

	private static final Logger logger = LoggerFactory.getLogger(HistoryImpl.class);

	private final ExecutionIdGenerator idGen;
	private final int capacity;
	private boolean manualMode = true;
	private boolean batchInProgress = false;
	/**
	 * The list storing all entries of this history.
	 * <p>
	 * <strong>Important:</strong> To make sure the capacity constraint of the list remains intact,
	 * only use {@link #addEntry(HistoryEntry)} to add new entries to the list.
	 */
	private final LinkedList<HistoryEntry> entries;

	private HistoryEntry offer;
	private boolean offerInterrupted;

	/**
	 * Creates a new {@link HistoryImpl} with the given capacity of {@link HistoryEntry
	 * HistoryEntries}. Once the history is full and a new entry is added, the oldest entry is
	 * removed.
	 *
	 * @param capacity
	 *            The maximum number of {@link HistoryEntry HistoryEntries} stored in this
	 *            {@link History}.
	 */
	public HistoryImpl(int capacity) {
		if (capacity < 1) {
			throw new IllegalArgumentException("The HistoryImpl's capacity must be at least 1.");
		}
		this.capacity = capacity;
		idGen = new ExecutionIdGenerator();
		entries = new LinkedList<>();
		offer = null;
		offerInterrupted = false;
		logger.debug("Created HistoryImpl with capacity {}.", capacity);
	}

	@Override
	public synchronized HistoryEntry finishOffer() throws HistoryException {
		checkEmergencyStop();
		if (offer == null) {
			throw new HistoryException("There was no offered entry that could be finished.");
		}
		if (offerInterrupted) {
			offerInterrupted = false;
			offer = null;
			throw new HistoryException(
					"Could not finish the offered HistoryEntry because the operation was finished in the meantime.");
		}
		addEntry(offer);
		final HistoryEntry added = offer;
		offer = null;
		return added;
	}

	@Override
	public synchronized HistoryEntry resetOffer() {
		logger.debug(
				"An offered HistoryEntry was reseted. The offered HistoryEntry was {}. The offer interrupted state was {}.",
				offer, offerInterrupted);
		offerInterrupted = false;
		final HistoryEntry ret = offer;
		offer = null;
		return ret;
	}

	@Override
	public synchronized boolean isBusy() {
		if (entries.isEmpty()) {
			return false;
		}
		if (PlcAction.STOP.equals(entries.getLast().getAction())) {
			return true;
		}
		if (!manualMode) {
			return batchInProgress;
		}

		final PlcAction action = entries.getLast().getAction();
		if (PlcAction.COMPLETE.equals(action) || PlcAction.ABORT.equals(action)
				|| PlcAction.SET_MANUAL_MODE.equals(action) || PlcAction.RESET.equals(action)) {
			return false;
		}
		return true;
	}

	@Override
	public synchronized boolean isCurrentExecution(String executionId) {
		if (!isBusy()) {
			return false;
		}

		final String lastExecutionId = entries.getLast().getExecutionId();
		return lastExecutionId.equals(executionId);
	}

	@Override
	public synchronized HistoryEntry startOperation(String operationId, String resolvedOperationPath)
			throws HistoryException {
		checkEmergencyStop();
		if (!manualMode) {
			throw new HistoryException(
					"Single operations must be executed in manual mode. The current mode is automatic.");
		}
		if (isBusy()) {
			throw new HistoryException("The history is still busy.");
		}
		final String executionId = idGen.next();
		final HistoryEntry entry = new HistoryEntryImpl(operationId, executionId, resolvedOperationPath,
				PlcAction.START);
		addEntry(entry);
		return entry;
	}

	@Override
	public synchronized HistoryEntry restartOperation(String executionId) throws HistoryException {
		checkEmergencyStop();
		if (!isBusy()) {
			throw new HistoryException("No operation is executed at the moment. Therefore, none can be continued.");
		}
		final HistoryEntry lastEntry = entries.getLast();
		if (!lastEntry.getExecutionId().equals(executionId)) {
			throw new HistoryException(
					"Could not continue the current operation as its execution id does not match the given one.");
		}
		if (!PlcAction.HOLD.equals(lastEntry.getAction())) {
			throw new HistoryException("Could not continue the operation as it has not been paused.");
		}

		final HistoryEntry entry = new HistoryEntryImpl(lastEntry.getOperationId(), executionId,
				lastEntry.getResolvedOperationPath(), PlcAction.RESTART);
		addEntry(entry);
		return entry;
	}

	@Override
	public synchronized HistoryEntry offerHoldOperation(String executionId) throws HistoryException {
		checkEmergencyStop();
		if (!isBusy()) {
			throw new HistoryException("No operation is executed at the moment. Therefore, none can be paused.");
		}
		final HistoryEntry lastEntry = entries.getLast();
		if (!lastEntry.getExecutionId().equals(executionId)) {
			throw new HistoryException(
					"Could not continue the current operation as its execution id does not match the given one.");
		}
		if (!(PlcAction.RESTART.equals(lastEntry.getAction()) || PlcAction.START.equals(lastEntry.getAction()))) {
			throw new HistoryException("Could not pause the operation as it is not running.");
		}
		final HistoryEntryImpl entry = new HistoryEntryImpl(lastEntry.getOperationId(), executionId, lastEntry.getResolvedOperationPath(),
				PlcAction.HOLD);
		offerEntry(entry);
		return entry;

	}

	@Override
	public synchronized HistoryEntry offerAbortOperation(String executionId) throws HistoryException {
		checkEmergencyStop();
		if (!isBusy()) {
			throw new HistoryException("No operation is executed at the moment. Therefore, none can be canceled.");
		}
		final HistoryEntry lastEntry = entries.getLast();
		if (!lastEntry.getExecutionId().equals(executionId)) {
			throw new HistoryException(
					"Could not cancel the current operation as its execution id does not match the given one.");
		}
		final HistoryEntryImpl entry = new HistoryEntryImpl(lastEntry.getOperationId(), executionId,
				lastEntry.getResolvedOperationPath(), PlcAction.ABORT);
		offerEntry(entry);
		return entry;
	}

	private void offerEntry(HistoryEntry entry) {
		offer = entry;
		offerInterrupted = false;
		logger.debug("An entry was offered: {}", entry.toString());
	}

	@Override
	public synchronized void completeOperation(String executionId, int resultCode) throws HistoryException {
		checkEmergencyStop();
		if (!isBusy()) {
			throw new HistoryException("No operation is executed at the moment. Therefore, none can be finished.");
		}
		final HistoryEntry lastEntry = entries.getLast();
		if (!lastEntry.getExecutionId().equals(executionId)) {
			throw new HistoryException(
					"Could not finish the current operation as its execution id does not match the given one.");
		}
		if (PlcAction.HOLD.equals(lastEntry.getAction())) {
			// Risk for not finishing in history despite a real finish because of the delay between
			// OPC server and middleware
			throw new HistoryException("Operation cannot finish while its paused");
		}

		if (offer != null && !offerInterrupted) {
			offerInterrupted = true;
			logger.debug("Finish operation for execution id {} and result code {} interrupted offer of entry: {}",
					executionId, resultCode, offer.toString());
		}
		addEntry(new HistoryEntryImpl(lastEntry.getOperationId(), executionId, lastEntry.getResolvedOperationPath(),
				PlcAction.COMPLETE, resultCode));
	}

	@Override
	public synchronized List<HistoryEntry> getAllEntries() {
		return new LinkedList<>(entries);
	}

	@Override
	public synchronized List<HistoryEntry> getEntriesForModule(String moduleName) {
		return entries.parallelStream()
				.filter((entry -> entry.getResolvedOperationPath().contains(moduleName)))
				.collect(Collectors.toCollection(LinkedList::new));
	}

	@Override
	public synchronized List<HistoryEntry> getEntriesForOperationId(String operationId) {
		return entries.parallelStream()
				.filter((entry -> entry.getOperationId().equals(operationId)))
				.collect(Collectors.toCollection(LinkedList::new));
	}

	@Override
	public synchronized List<HistoryEntry> getEntriesForExecutionId(String executionId) {
		return entries.parallelStream()
				.filter((entry -> entry.getExecutionId().equals(executionId)))
				.collect(Collectors.toCollection(LinkedList::new));
	}

	/**
	 * Adds a {@link HistoryEntry} and makes sure that the entry list's size does not define this
	 * history's capacity.
	 *
	 * @param entry
	 *            The {@link HistoryEntry} to add to this history
	 * @return The removed {@link HistoryEntry} if the entry list was full, <code>null</code>
	 *         otherwise
	 */
	private HistoryEntry addEntry(HistoryEntry entry) {
		HistoryEntry removed = null;
		if (entries.size() >= capacity) {
			removed = entries.removeFirst();
			logger.debug("Removed oldest entry from the history: {}", removed.toString());
		}
		entries.add(entry);
		logger.debug("Added new HistoryEntry: {}", entry.toString());
		return removed;
	}

	@Override
	public synchronized HistoryEntry removeNewestEntry() {
		if (entries.isEmpty()) {
			return null;
		}
		final HistoryEntry removedEntry = entries.removeLast();
		if (removedEntry.getAction() == PlcAction.SET_MANUAL_MODE
				|| removedEntry.getAction() == PlcAction.SET_AUTOMATIC_MODE) {
			manualMode = !manualMode;
		}
		if (removedEntry.getAction() == PlcAction.BATCH_START) {
			batchInProgress = false;
		}
		return removedEntry;
	}

	@Override
	public synchronized List<HistoryEntry> getEntriesNewerThan(Instant timestamp) {
		return entries.parallelStream().filter((entry -> entry.getTimestamp().compareTo(timestamp) >= 0))
				.collect(Collectors.toCollection(LinkedList::new));
	}

	@Override
	public synchronized HistoryEntry startBatchOperation(String executionId, String operationId,
			String resolvedOperationPath) throws HistoryException {
		checkEmergencyStop();
		if (manualMode) {
			throw new HistoryException(
					"Batch operations can only be executed as part of a batch in automatic mode. The current mode is manual.");
		}
		if (!batchInProgress) {
			throw new HistoryException("There is no batch in progress. Therefore, no batch operation can be executed.");
		}
		final HistoryEntry entry = new HistoryEntryImpl(operationId, executionId, resolvedOperationPath,
				PlcAction.START, ResultCodes.START);
		addEntry(entry);
		return entry;
	}

	@Override
	public synchronized HistoryEntry startBatchExecution(int size) throws HistoryException {
		checkEmergencyStop();
		if (manualMode) {
			throw new HistoryException(
					"A batch execution can only be started in automatic mode. The current mode is manual.");
		}
		if (isBusy()) {
			throw new HistoryException("The batch execution cannot be started because the history is busy.");
		}
		final String executionId = idGen.next();
		batchInProgress = true;
		final HistoryEntryImpl entry = new HistoryEntryImpl(executionId, PlcAction.BATCH_START);
		addEntry(entry);
		return entry;
	}

	@Override
	public synchronized HistoryEntry finishBatchExecution(int resultCode) throws HistoryException {
		checkEmergencyStop();
		if (!batchInProgress) {
			throw new HistoryException("There is no running batch to finish");
		}
		batchInProgress = false;
		final HistoryEntryImpl entry = new HistoryEntryImpl("", "", "", PlcAction.BATCH_COMPLETE, resultCode);
		addEntry(entry);
		return entry;
	}

	@Override
	public synchronized HistoryEntry setManualMode() throws HistoryException {
		checkEmergencyStop();
		if (manualMode) {
			return null;
		}
		if (isBusy()) {
			throw new HistoryException(
					"Execution mode cannot be changed to MANUAL because the history is currently busy.");
		}
		manualMode = true;
		final HistoryEntryImpl entry = new HistoryEntryImpl(PlcAction.SET_MANUAL_MODE);
		addEntry(entry);
		return entry;
	}

	@Override
	public synchronized HistoryEntry setAutomaticMode() throws HistoryException {
		checkEmergencyStop();
		if (!manualMode) {
			return null;
		}
		if (isBusy()) {
			throw new HistoryException(
					"Execution mode cannot be changed to AUTOMATIC because the history is currently busy.");
		}
		manualMode = false;
		final HistoryEntryImpl entry = new HistoryEntryImpl(PlcAction.SET_AUTOMATIC_MODE);
		addEntry(entry);
		return entry;
	}

	@Override
	public synchronized HistoryEntry setEmergencyStop(boolean emergencyStop) {
		HistoryEntry entry;
		if (emergencyStop) {
			entry = new HistoryEntryImpl(PlcAction.STOP);
			logger.info("History has been set to Emergency Stop.");
			batchInProgress = false;
			offerInterrupted = true;
		} else {
			entry = new HistoryEntryImpl(PlcAction.RESET);
			logger.info("The History's Emergency Stop has been resolved.");
		}
		addEntry(entry);
		return entry;
	}

	/**
	 * @throws HistoryException
	 *             if the middleware is currently in the stopped state (this state usually results
	 *             from an emergency stopp of the XPPU).
	 */
	private void checkEmergencyStop() throws HistoryException {
		if (!entries.isEmpty() && PlcAction.STOP.equals(entries.getLast().getAction())) {
			throw new HistoryException(
					"The system is currently in the STOPPED state. Therefore, no actions can be executed until the stop is resolved.");
		}
	}
}
