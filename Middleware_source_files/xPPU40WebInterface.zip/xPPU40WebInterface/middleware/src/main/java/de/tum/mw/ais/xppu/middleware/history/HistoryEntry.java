package de.tum.mw.ais.xppu.middleware.history;

import java.time.Instant;

/**
 * A {@link HistoryEntry} contains information about one logged history event.
 *
 * @author Lucas Koehler
 *
 */
public interface HistoryEntry {

	/**
	 * @return The operation id of the corresponding operation
	 */
	String getOperationId();

	/**
	 * An execution id is issued whenever the execution of a new operation is started. It is then
	 * used to group all further actions (pause, continue, etc.) related to this execution.
	 * Furthermore, the execution id is needed to pause, continue, or cancel a running operation.
	 * This ensures that only the intended operation is affected by such a call.
	 *
	 * @return The execution id
	 */
	String getExecutionId();

	/**
	 * @return The resolved path of the operation usage in the model
	 */
	String getResolvedOperationPath();

	/**
	 * <strong>Important:</strong> The returned {@link Instant} does not include a timezone. All
	 * timestamps use UTC.
	 *
	 * @return The timestamp of the executed action.
	 */
	Instant getTimestamp();

	/**
	 * @return The action that was executed on the PLC (e.g. execute operation)
	 */
	PlcAction getAction();

	/**
	 * @return The result code of the operation if this entry represents the completion of an
	 *         operation; the minimum integer (-2147483648) otherwise
	 */
	int getResultCode();
}
