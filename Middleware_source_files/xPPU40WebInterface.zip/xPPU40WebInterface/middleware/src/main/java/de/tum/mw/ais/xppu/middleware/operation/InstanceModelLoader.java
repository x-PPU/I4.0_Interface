package de.tum.mw.ais.xppu.middleware.operation;

import java.io.IOException;

import de.tum.mw.ais.isa88.Enterprise;

/**
 * An {@link InstanceModelLoader} loads an instance of a ISA88 model.
 *
 * @author Lucas Koehler
 *
 */
public interface InstanceModelLoader {
	/**
	 * Loads the isa88 model from the file at the given path and returns its root {@link Enterprise}
	 * object. Every loaded model must contain exactly one root element which is of type Enterprise.
	 *
	 * @param modelFilePath
	 *            The path to the file to load the model from
	 * @return The root {@link Enterprise} object of the model.
	 * @throws IOException
	 *             If the file does not exist or an exception occurs while accessing the file
	 * @throws ModelLoadException
	 *             If the model cannot be loaded due to errors in the model or no root Enterprise
	 *             object.
	 */
	Enterprise loadModel(String modelFilePath) throws IOException, ModelLoadException;
}
