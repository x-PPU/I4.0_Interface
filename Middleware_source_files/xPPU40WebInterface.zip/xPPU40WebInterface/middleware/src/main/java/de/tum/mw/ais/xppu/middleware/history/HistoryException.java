package de.tum.mw.ais.xppu.middleware.history;

/**
 * @author Lucas Koehler
 *
 */
public class HistoryException extends Exception {
	/**
	 * Generated serialization id.
	 */
	private static final long serialVersionUID = -6871352425317352853L;

	/**
	 * Creates a new {@link HistoryException} with the given message
	 * 
	 * @param message
	 *            The exception's message
	 */
	public HistoryException(String message) {
		super(message);
	}
}
