package de.tum.mw.ais.xppu.middleware.operation;

import java.io.IOException;
import java.util.List;

/**
 * Loads {@link OperationInformation OperationInformation} from a given source.
 *
 * @author Lucas Koehler
 *
 */
public interface OperationInformationLoader {

	/**
	 * Loads all available {@link OperationInformation} from the source given by a path.
	 *
	 * @param path
	 *            The path to the source that contains the {@link OperationInformation}.
	 * @return The list of loaded {@link OperationInformation}, does not return null but may return
	 *         an empty list
	 * @throws IOException
	 *             If something goes wrong reading the operation list
	 */
	List<OperationInformation> loadOperationInformation(String path) throws IOException;
}
