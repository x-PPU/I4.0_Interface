package de.tum.mw.ais.xppu.middleware.controller;

import java.util.Map;

import spark.Request;
import spark.Response;

/**
 * Handles method calls of the webservice: Executes called methods and/or returns requested data
 * (e.g. the set of resolved operations).
 *
 * @author Lucas Koehler
 *
 */
public interface Controller {

	/**
	 * Initializes the {@link Controller} for the provided configuration. Keys to use in the
	 * configuration map are defined in {@link ControllerSettings}.
	 * <p>
	 * <strong>This method must be executed successfully before any other method can be
	 * executed.</strong>
	 *
	 * @param configuration
	 *            The configuration map.
	 * @throws ControllerInitializationException
	 *             If something goes wrong during the initialization.
	 */
	void initialize(Map<Object, Object> configuration) throws ControllerInitializationException;

	/**
	 * Returns the isa88 instance model as xmi and sets appropriate header fields in the response.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The model as text, this will be in the body of the webservice's response. An error
	 *         message if something goes wrong reading the model.
	 */
	String getInstanceModel(Request request, Response response);

	/**
	 * Returns all operations in JSON format and sets appropriate header fields in the response.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return All resolved operations serialized as JSON
	 */
	String getOperations(Request request, Response response);

	/**
	 * Returns the resolved operation for the id specified in the request and sets appropriate
	 * header fields in the response. Sets an error code in the response if the operation does not
	 * exist.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The operation serialized as JSON; an error message if it does not exist
	 */
	String getOperation(Request request, Response response);

	/**
	 * Tells the PLC to cancel the current operation execution.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return an error message IF something goes wrong
	 */
	String abortOperationExcecution(Request request, Response response);

	/**
	 * Tells the PLC to continue the current operation execution after it has been held.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return an error message IF something goes wrong
	 */
	String restartOperationExcecution(Request request, Response response);

	/**
	 * Tells the PLC to pause the current operation execution.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return an error message IF something goes wrong
	 */
	String holdOperationExcecution(Request request, Response response);

	/**
	 * Tells the PLC to execute the operation with the operation id given in the request. Only
	 * possible in manual mode.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return an error message IF something goes wrong or no operation for the given id exists
	 */
	String startOperation(Request request, Response response);

	/**
	 * Returns all history entries. Also sets appropriate header fields in the response.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The history entries as JSON, this will be in the body of the webservice's response.
	 *         An error message if something goes wrong serializing the history entries.
	 */
	String getCompleteHistory(Request request, Response response);

	/**
	 * Returns all history entries newer for the operation id given in the request. Also sets
	 * appropriate header fields in the response.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The history entries as JSON, this will be in the body of the webservice's response.
	 *         An error message if something goes wrong serializing the history entries.
	 */
	String getHistoryByOperationId(Request request, Response response);

	/**
	 * Returns all history entries newer for the execution id given in the request. Also sets
	 * appropriate header fields in the response.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The history entries as JSON, this will be in the body of the webservice's response.
	 *         An error message if something goes wrong serializing the history entries.
	 */
	String getHistoryByExecutionId(Request request, Response response);

	/**
	 * Returns all history entries newer whose resolved operation path contain the module name given
	 * in the request. Also sets appropriate header fields in the response.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The history entries as JSON, this will be in the body of the webservice's response.
	 *         An error message if something goes wrong serializing the history entries.
	 */
	String getHistoryByModuleName(Request request, Response response);

	/**
	 * Returns all history entries newer or equally old as the date-time given in the request. Also
	 * sets appropriate header fields in the response.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The history entries as JSON, this will be in the body of the webservice's response.
	 *         An error message if something goes wrong serializing the history entries.
	 */
	String getHistoryNewerThanDate(Request request, Response response);

	/**
	 * Sets the middleware to automatic (batch) execution mode. While this mode is active, all
	 * manual execution requests will be denied.
	 * <p>
	 * The HTTP code is set to 204 (successful, no content) if the middleware already is in
	 * automatic mode.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The created history entry if the switch was successful, an empty String if the mode
	 *         was already automatic, or an error message
	 */
	String setAutomaticMode(Request request, Response response);

	/**
	 * Sets the middleware to manual (single operation) execution mode. While this mode is active,
	 * all automatic execution requests will be denied.
	 * <p>
	 * The HTTP code is set to 204 (successful, no content) if the middleware already is in manual
	 * mode.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The created history entry if the switch was successful, an empty String if the mode
	 *         was already manual, or an error message
	 */
	String setManualMode(Request request, Response response);

	/**
	 * Tells the PLC to execute the batch of given operation ids in automatic mode. This fails if
	 * the middleware is not set to automatic mode or if there are no or too many given operation
	 * ids.
	 * <p>
	 * <strong>Important:</strong> The operation ids are given as query parameters for the
	 * "operationids" key. The ids must be separated by semicolons.
	 *
	 * @param request
	 *            The HTTP request
	 * @param response
	 *            The HTTP response
	 * @return The batch start history entry for the execution start of this batch or an error
	 *         message if the batch cannot be executed
	 */
	String startBatchFromQuery(Request request, Response response);
}
