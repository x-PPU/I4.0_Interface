/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.Constraint;
import de.tum.mw.ais.isa88.GeneralOperation;
import de.tum.mw.ais.isa88.isa88Package;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>General
 * Operation</b></em>'. <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#getPre <em>Pre</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#getPost <em>Post</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#getBody <em>Body</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#getOwnedGeneralOperation <em>Owned
 * General Operation</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#isIs_implemented <em>Is
 * implemented</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#isAvailable_for_user <em>Available for
 * user</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#getHolding_Routine <em>Holding
 * Routine</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#getReset_Routine <em>Reset
 * Routine</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl#getAbort_Routine <em>Abort
 * Routine</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GeneralOperationImpl extends NamedElementImpl implements GeneralOperation {
	/**
	 * The cached value of the '{@link #getPre() <em>Pre</em>}' containment reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getPre()
	 * @generated
	 * @ordered
	 */
	protected Constraint pre;

	/**
	 * The cached value of the '{@link #getPost() <em>Post</em>}' containment reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getPost()
	 * @generated
	 * @ordered
	 */
	protected Constraint post;

	/**
	 * The default value of the '{@link #getBody() <em>Body</em>}' attribute. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @see #getBody()
	 * @generated
	 * @ordered
	 */
	protected static final String BODY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBody() <em>Body</em>}' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @see #getBody()
	 * @generated
	 * @ordered
	 */
	protected String body = BODY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOwnedGeneralOperation() <em>Owned General
	 * Operation</em>}' reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getOwnedGeneralOperation()
	 * @generated
	 * @ordered
	 */
	protected EList<GeneralOperation> ownedGeneralOperation;

	/**
	 * The default value of the '{@link #isIs_implemented() <em>Is implemented</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #isIs_implemented()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_IMPLEMENTED_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIs_implemented() <em>Is implemented</em>}' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #isIs_implemented()
	 * @generated
	 * @ordered
	 */
	protected boolean is_implemented = IS_IMPLEMENTED_EDEFAULT;

	/**
	 * The default value of the '{@link #isAvailable_for_user() <em>Available for user</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #isAvailable_for_user()
	 * @generated
	 * @ordered
	 */
	protected static final boolean AVAILABLE_FOR_USER_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isAvailable_for_user() <em>Available for user</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #isAvailable_for_user()
	 * @generated
	 * @ordered
	 */
	protected boolean available_for_user = AVAILABLE_FOR_USER_EDEFAULT;

	/**
	 * The default value of the '{@link #getHolding_Routine() <em>Holding Routine</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getHolding_Routine()
	 * @generated
	 * @ordered
	 */
	protected static final String HOLDING_ROUTINE_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getHolding_Routine() <em>Holding Routine</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getHolding_Routine()
	 * @generated
	 * @ordered
	 */
	protected String holding_Routine = HOLDING_ROUTINE_EDEFAULT;

	/**
	 * The default value of the '{@link #getReset_Routine() <em>Reset Routine</em>}' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getReset_Routine()
	 * @generated
	 * @ordered
	 */
	protected static final String RESET_ROUTINE_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getReset_Routine() <em>Reset Routine</em>}' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getReset_Routine()
	 * @generated
	 * @ordered
	 */
	protected String reset_Routine = RESET_ROUTINE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAbort_Routine() <em>Abort Routine</em>}' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getAbort_Routine()
	 * @generated
	 * @ordered
	 */
	protected static final String ABORT_ROUTINE_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getAbort_Routine() <em>Abort Routine</em>}' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getAbort_Routine()
	 * @generated
	 * @ordered
	 */
	protected String abort_Routine = ABORT_ROUTINE_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected GeneralOperationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.GENERAL_OPERATION;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Constraint getPre() {
		return pre;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public NotificationChain basicSetPre(Constraint newPre, NotificationChain msgs) {
		Constraint oldPre = pre;
		pre = newPre;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					isa88Package.GENERAL_OPERATION__PRE, oldPre, newPre);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setPre(Constraint newPre) {
		if (newPre != pre) {
			NotificationChain msgs = null;
			if (pre != null)
				msgs = ((InternalEObject) pre).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - isa88Package.GENERAL_OPERATION__PRE, null, msgs);
			if (newPre != null)
				msgs = ((InternalEObject) newPre).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - isa88Package.GENERAL_OPERATION__PRE, null, msgs);
			msgs = basicSetPre(newPre, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.GENERAL_OPERATION__PRE, newPre, newPre));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Constraint getPost() {
		return post;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public NotificationChain basicSetPost(Constraint newPost, NotificationChain msgs) {
		Constraint oldPost = post;
		post = newPost;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					isa88Package.GENERAL_OPERATION__POST, oldPost, newPost);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setPost(Constraint newPost) {
		if (newPost != post) {
			NotificationChain msgs = null;
			if (post != null)
				msgs = ((InternalEObject) post).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - isa88Package.GENERAL_OPERATION__POST, null, msgs);
			if (newPost != null)
				msgs = ((InternalEObject) newPost).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - isa88Package.GENERAL_OPERATION__POST, null, msgs);
			msgs = basicSetPost(newPost, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.GENERAL_OPERATION__POST, newPost,
					newPost));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String getBody() {
		return body;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setBody(String newBody) {
		String oldBody = body;
		body = newBody;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.GENERAL_OPERATION__BODY, oldBody, body));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList<GeneralOperation> getOwnedGeneralOperation() {
		if (ownedGeneralOperation == null) {
			ownedGeneralOperation = new EObjectResolvingEList<GeneralOperation>(GeneralOperation.class, this,
					isa88Package.GENERAL_OPERATION__OWNED_GENERAL_OPERATION);
		}
		return ownedGeneralOperation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean isIs_implemented() {
		return is_implemented;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setIs_implemented(boolean newIs_implemented) {
		boolean oldIs_implemented = is_implemented;
		is_implemented = newIs_implemented;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.GENERAL_OPERATION__IS_IMPLEMENTED,
					oldIs_implemented, is_implemented));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean isAvailable_for_user() {
		return available_for_user;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setAvailable_for_user(boolean newAvailable_for_user) {
		boolean oldAvailable_for_user = available_for_user;
		available_for_user = newAvailable_for_user;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.GENERAL_OPERATION__AVAILABLE_FOR_USER,
					oldAvailable_for_user, available_for_user));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String getHolding_Routine() {
		return holding_Routine;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setHolding_Routine(String newHolding_Routine) {
		String oldHolding_Routine = holding_Routine;
		holding_Routine = newHolding_Routine;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.GENERAL_OPERATION__HOLDING_ROUTINE,
					oldHolding_Routine, holding_Routine));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String getReset_Routine() {
		return reset_Routine;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setReset_Routine(String newReset_Routine) {
		String oldReset_Routine = reset_Routine;
		reset_Routine = newReset_Routine;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.GENERAL_OPERATION__RESET_ROUTINE,
					oldReset_Routine, reset_Routine));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String getAbort_Routine() {
		return abort_Routine;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setAbort_Routine(String newAbort_Routine) {
		String oldAbort_Routine = abort_Routine;
		abort_Routine = newAbort_Routine;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.GENERAL_OPERATION__ABORT_ROUTINE,
					oldAbort_Routine, abort_Routine));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case isa88Package.GENERAL_OPERATION__PRE:
			return basicSetPre(null, msgs);
		case isa88Package.GENERAL_OPERATION__POST:
			return basicSetPost(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case isa88Package.GENERAL_OPERATION__PRE:
			return getPre();
		case isa88Package.GENERAL_OPERATION__POST:
			return getPost();
		case isa88Package.GENERAL_OPERATION__BODY:
			return getBody();
		case isa88Package.GENERAL_OPERATION__OWNED_GENERAL_OPERATION:
			return getOwnedGeneralOperation();
		case isa88Package.GENERAL_OPERATION__IS_IMPLEMENTED:
			return isIs_implemented();
		case isa88Package.GENERAL_OPERATION__AVAILABLE_FOR_USER:
			return isAvailable_for_user();
		case isa88Package.GENERAL_OPERATION__HOLDING_ROUTINE:
			return getHolding_Routine();
		case isa88Package.GENERAL_OPERATION__RESET_ROUTINE:
			return getReset_Routine();
		case isa88Package.GENERAL_OPERATION__ABORT_ROUTINE:
			return getAbort_Routine();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case isa88Package.GENERAL_OPERATION__PRE:
			setPre((Constraint) newValue);
			return;
		case isa88Package.GENERAL_OPERATION__POST:
			setPost((Constraint) newValue);
			return;
		case isa88Package.GENERAL_OPERATION__BODY:
			setBody((String) newValue);
			return;
		case isa88Package.GENERAL_OPERATION__OWNED_GENERAL_OPERATION:
			getOwnedGeneralOperation().clear();
			getOwnedGeneralOperation().addAll((Collection<? extends GeneralOperation>) newValue);
			return;
		case isa88Package.GENERAL_OPERATION__IS_IMPLEMENTED:
			setIs_implemented((Boolean) newValue);
			return;
		case isa88Package.GENERAL_OPERATION__AVAILABLE_FOR_USER:
			setAvailable_for_user((Boolean) newValue);
			return;
		case isa88Package.GENERAL_OPERATION__HOLDING_ROUTINE:
			setHolding_Routine((String) newValue);
			return;
		case isa88Package.GENERAL_OPERATION__RESET_ROUTINE:
			setReset_Routine((String) newValue);
			return;
		case isa88Package.GENERAL_OPERATION__ABORT_ROUTINE:
			setAbort_Routine((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case isa88Package.GENERAL_OPERATION__PRE:
			setPre((Constraint) null);
			return;
		case isa88Package.GENERAL_OPERATION__POST:
			setPost((Constraint) null);
			return;
		case isa88Package.GENERAL_OPERATION__BODY:
			setBody(BODY_EDEFAULT);
			return;
		case isa88Package.GENERAL_OPERATION__OWNED_GENERAL_OPERATION:
			getOwnedGeneralOperation().clear();
			return;
		case isa88Package.GENERAL_OPERATION__IS_IMPLEMENTED:
			setIs_implemented(IS_IMPLEMENTED_EDEFAULT);
			return;
		case isa88Package.GENERAL_OPERATION__AVAILABLE_FOR_USER:
			setAvailable_for_user(AVAILABLE_FOR_USER_EDEFAULT);
			return;
		case isa88Package.GENERAL_OPERATION__HOLDING_ROUTINE:
			setHolding_Routine(HOLDING_ROUTINE_EDEFAULT);
			return;
		case isa88Package.GENERAL_OPERATION__RESET_ROUTINE:
			setReset_Routine(RESET_ROUTINE_EDEFAULT);
			return;
		case isa88Package.GENERAL_OPERATION__ABORT_ROUTINE:
			setAbort_Routine(ABORT_ROUTINE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case isa88Package.GENERAL_OPERATION__PRE:
			return pre != null;
		case isa88Package.GENERAL_OPERATION__POST:
			return post != null;
		case isa88Package.GENERAL_OPERATION__BODY:
			return BODY_EDEFAULT == null ? body != null : !BODY_EDEFAULT.equals(body);
		case isa88Package.GENERAL_OPERATION__OWNED_GENERAL_OPERATION:
			return ownedGeneralOperation != null && !ownedGeneralOperation.isEmpty();
		case isa88Package.GENERAL_OPERATION__IS_IMPLEMENTED:
			return is_implemented != IS_IMPLEMENTED_EDEFAULT;
		case isa88Package.GENERAL_OPERATION__AVAILABLE_FOR_USER:
			return available_for_user != AVAILABLE_FOR_USER_EDEFAULT;
		case isa88Package.GENERAL_OPERATION__HOLDING_ROUTINE:
			return HOLDING_ROUTINE_EDEFAULT == null ? holding_Routine != null
					: !HOLDING_ROUTINE_EDEFAULT.equals(holding_Routine);
		case isa88Package.GENERAL_OPERATION__RESET_ROUTINE:
			return RESET_ROUTINE_EDEFAULT == null ? reset_Routine != null
					: !RESET_ROUTINE_EDEFAULT.equals(reset_Routine);
		case isa88Package.GENERAL_OPERATION__ABORT_ROUTINE:
			return ABORT_ROUTINE_EDEFAULT == null ? abort_Routine != null
					: !ABORT_ROUTINE_EDEFAULT.equals(abort_Routine);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Body: ");
		result.append(body);
		result.append(", is_implemented: ");
		result.append(is_implemented);
		result.append(", available_for_user: ");
		result.append(available_for_user);
		result.append(", Holding_Routine: ");
		result.append(holding_Routine);
		result.append(", Reset_Routine: ");
		result.append(reset_Routine);
		result.append(", Abort_Routine: ");
		result.append(abort_Routine);
		result.append(')');
		return result.toString();
	}

} // GeneralOperationImpl
