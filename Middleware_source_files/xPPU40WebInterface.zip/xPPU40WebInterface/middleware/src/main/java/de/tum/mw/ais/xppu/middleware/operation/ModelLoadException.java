package de.tum.mw.ais.xppu.middleware.operation;

import de.tum.mw.ais.isa88.Enterprise;

/**
 * Indicates that a model could not be loaded because it did not have an {@link Enterprise} root
 * element or the model could not be loaded for other reasons.
 *
 * @author Lucas Koehler
 *
 */
public class ModelLoadException extends Exception {
	/**
	 * Generated serialization ID.
	 */
	private static final long serialVersionUID = -3906881386563327495L;

	/**
	 * Creates a new {@link ModelLoadException} with the given message.
	 *
	 * @param message
	 *            The exception's message
	 */
	public ModelLoadException(String message) {
		super(message);
	}

	/**
	 * Creates a new {@link ModelLoadException} with the given message and cause.
	 *
	 * @param message
	 *            The exception's message
	 * @param cause
	 *            The exception's cause
	 */
	public ModelLoadException(String message, Throwable cause) {
		super(message, cause);
	}
}
