package de.tum.mw.ais.xppu.middleware.config;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.prefs.Preferences;

import org.ini4j.Ini;
import org.ini4j.IniPreferences;
import org.ini4j.InvalidFileFormatException;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class that loads the middleware's configuration file and makes the loaded parameters
 * available.
 * 
 * @author Lucas Koehler
 *
 */
public class Configuration {

	/**
	 * Name of the section containing configuration parameters for the plc.
	 */
	private static final String PLC_SECTION = "PLC";

	/**
	 * Name of the section containing configuration parameters defining the running instance.
	 */
	private static final String INSTANCE_SECTION = "INSTANCE";

	private static final int DEFAULT_HISTORY_CAPACITY = 50;
	private static final int DEFAULT_FLAG_SWITCH_DELAY = 25;

	private static Logger logger = LoggerFactory.getLogger(Configuration.class);

	@Option(name = "-c", usage = "Relative path to the configuration file in the Windows INI format.", required = true)
	private String configFilePath;

	private String serverUri;
	// Integer to allow null
	private Integer namespaceIndex;

	private String namespaceUri;
	private int flagSwitchDelay;

	private String instanceModelPath;
	private String operationListPath;
	private int historyCapacity;

	/**
	 * Parses the middleware's configuration file given via the '-c' parameter. The configuration
	 * file uses the Windows INI format.
	 *
	 * @param args
	 *            The command line arguments of the middleware
	 * @throws ConfigurationException
	 */
	public Configuration(String[] args) throws ConfigurationException {
		parseArguments(args);
		parseConfiguration(configFilePath);
	}

	/**
	 * Parses the command line arguments.
	 *
	 * @param args
	 *            The arguments to parse.
	 * @throws ConfigurationException
	 *             If the arguments cannot be parsed due to an exception. May include usage
	 *             instructions.
	 */
	private void parseArguments(String[] args) throws ConfigurationException {
		logger.debug("Parsing arguments...");
		final CmdLineParser parser = new CmdLineParser(this);

		try {
			parser.parseArgument(args);
		} catch (final CmdLineException e) {
			final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			parser.printUsage(outputStream);
			String usage;
			try {
				usage = outputStream.toString("utf-8");
			} catch (final UnsupportedEncodingException e2) {
				usage = "Unable to retrieve usage message. Could not encode in utf-8.";
			}
			throw new ConfigurationException("An exception occurred while parsing arguments.", e, usage);
		}
		logger.info("Successfully parsed arguments.");
	}

	private void parseConfiguration(String filePath) throws ConfigurationException {
		logger.debug("Try to parse configuration from file at {}", filePath);
		final Ini iniConfig;
		try {
			iniConfig = new Ini(new File(filePath));
		} catch (final InvalidFileFormatException e) {
			throw new ConfigurationException("The configuration file has an invalid format", e);
		} catch (final IOException e) {
			throw new ConfigurationException("Could not read configuration file.", e);
		}

		final Preferences allPreferences = new IniPreferences(iniConfig);
		final Preferences instancePreferences = allPreferences.node(INSTANCE_SECTION);
		final Preferences plcPreferences = allPreferences.node(PLC_SECTION);

		// Read instance preferences
		instanceModelPath = instancePreferences.get("instance_model", null);
		logger.debug("Parsed option instance_model: {}", instanceModelPath);

		operationListPath = instancePreferences.get("operation_list", null);
		logger.debug("Parsed option operation_list: {}", operationListPath);

		historyCapacity = instancePreferences.getInt("history_capacity", DEFAULT_HISTORY_CAPACITY);
		if (historyCapacity < 1) {
			logger.warn(
					"The history's capacity must be a positive number. Therefore, it was set to the default value of {}",
					DEFAULT_HISTORY_CAPACITY);
			historyCapacity = DEFAULT_HISTORY_CAPACITY;
		}

		// Read PLC preferences
		serverUri = plcPreferences.get("server_uri", null);
		logger.debug("Parsed option server_uri: {}", serverUri);

		namespaceIndex = plcPreferences.getInt("namespace_index", Integer.MAX_VALUE);
		if (namespaceIndex == Integer.MAX_VALUE) {
			namespaceIndex = null;
		} else if (namespaceIndex < 0) {
			throw new ConfigurationException(
					"The option namespace_index must not contain a negative Integer. If you do not know the namespace index, use the namespace uri instead.");
		}
		logger.debug("Parsed option namespace_index: {}", namespaceIndex);

		namespaceUri = plcPreferences.get("namespace_uri", null);
		logger.debug("Parsed option namespace_uri: {}", namespaceUri);

		flagSwitchDelay = plcPreferences.getInt("flag_switch_delay", DEFAULT_FLAG_SWITCH_DELAY);
		if (flagSwitchDelay < 0) {
			logger.warn(
					"The flag_switch_delay must be a non-negative number. Therefore, it was set to the default value of {}.",
					DEFAULT_FLAG_SWITCH_DELAY);
			flagSwitchDelay = DEFAULT_FLAG_SWITCH_DELAY;
		}
		logger.debug("Parsed option flag_switch_delay: {}. Default value: {}.", flagSwitchDelay,
				DEFAULT_FLAG_SWITCH_DELAY);

		logger.info("Successfully parsed configuration file at: {}", filePath);
	}

	/**
	 * @return The configured uri of the plc's opc ua server
	 */
	public String getServerUri() {
		return serverUri;
	}

	/**
	 * @return The namespace index of the variables on plc's opc ua server
	 */
	public Integer getNamespaceIndex() {
		return namespaceIndex;
	}

	/**
	 * @return The namespace uri of the variables on plc's opc ua server
	 */
	public String getNamespaceUri() {
		return namespaceUri;
	}

	/**
	 * The 'flag switch delay' is the delay that is used when (boolean) variables on the plc are
	 * switched back and forth (e.g. <code>true -> false -> true</code>) to trigger rising or
	 * falling edges. The delay may be necessary because the PLC does not recognize rising or
	 * falling edges if the switch is executed too quickly.
	 *
	 * @return The flag switch delay
	 */
	public int getFlagSwitchDelay() {
		return flagSwitchDelay;
	}

	/**
	 * @return The path to the file that contains the isa88 instance model
	 */
	public String getInstanceModelPath() {
		return instanceModelPath;
	}

	/**
	 * @return The path to the file that contains the instance's operation usages
	 */
	public String getOperationListPath() {
		return operationListPath;
	}

	/**
	 * @return the maximum capacity of the instance's history
	 */
	public int getHistoryCapacity() {
		return historyCapacity;
	}
}
