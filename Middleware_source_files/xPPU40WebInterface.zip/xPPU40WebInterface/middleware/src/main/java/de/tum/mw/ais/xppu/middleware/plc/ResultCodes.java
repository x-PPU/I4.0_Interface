package de.tum.mw.ais.xppu.middleware.plc;

/**
 * Result codes written out by the PLC which indicate an operation's execution status.
 *
 * @author Lucas Koehler
 *
 */
public interface ResultCodes {

	/**
	 * The execution of the operation has been started.
	 */
	static final int START = 80;

	/**
	 * The execution of the operation has been finished successfully.
	 */
	static final int SUCCESS = 100;

	/**
	 * The execution of the operation has been canceled.
	 */
	static final int CANCEL = 500;
}
