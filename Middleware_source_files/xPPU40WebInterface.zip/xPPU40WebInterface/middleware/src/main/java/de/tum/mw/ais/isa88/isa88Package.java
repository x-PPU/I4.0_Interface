/**
 */
package de.tum.mw.ais.isa88;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc --> The <b>Package</b> for the model. It contains accessors for the meta
 * objects to represent
 * <ul>
 * <li>each class,</li>
 * <li>each feature of each class,</li>
 * <li>each operation of each class,</li>
 * <li>each enum,</li>
 * <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * 
 * @see de.tum.mw.ais.isa88.isa88Factory
 * @model kind="package"
 * @generated
 */
public interface isa88Package extends EPackage {
	/**
	 * The package name. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	String eNAME = "isa88";

	/**
	 * The package namespace URI. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	String eNS_URI = "http://de/tum/mw/ais/isa88/v13";

	/**
	 * The package namespace name. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	String eNS_PREFIX = "isa88";

	/**
	 * The singleton instance of the package. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	isa88Package eINSTANCE = de.tum.mw.ais.isa88.impl.isa88PackageImpl.init();

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.NamedElementImpl <em>Named
	 * Element</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.NamedElementImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getNamedElement()
	 * @generated
	 */
	int NAMED_ELEMENT = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT__OBJECT_ID = 1;

	/**
	 * The number of structural features of the '<em>Named Element</em>' class. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Named Element</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int NAMED_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.PropertyImpl <em>Property</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.PropertyImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getProperty()
	 * @generated
	 */
	int PROPERTY = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROPERTY__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROPERTY__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Type</b></em>' reference. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROPERTY__TYPE = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Constraint Set</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROPERTY__CONSTRAINT_SET = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Property</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROPERTY_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Property</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROPERTY_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.ModuleImpl <em>Module</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.ModuleImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getModule()
	 * @generated
	 */
	int MODULE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Owned Property</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE__OWNED_PROPERTY = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE__OWNED_GENERAL_OPERATION = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Datatype</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE__DATATYPE = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' reference. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE__INTERFACE = NAMED_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE__BODY = NAMED_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Module</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Module</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODULE_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.DataTypeImpl <em>Data Type</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.DataTypeImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getDataType()
	 * @generated
	 */
	int DATA_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DATA_TYPE__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DATA_TYPE__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The number of structural features of the '<em>Data Type</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DATA_TYPE_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Data Type</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DATA_TYPE_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.ProcessCellImpl <em>Process
	 * Cell</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.ProcessCellImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getProcessCell()
	 * @generated
	 */
	int PROCESS_CELL = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL__NAME = MODULE__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL__OBJECT_ID = MODULE__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Owned Property</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL__OWNED_PROPERTY = MODULE__OWNED_PROPERTY;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL__OWNED_GENERAL_OPERATION = MODULE__OWNED_GENERAL_OPERATION;

	/**
	 * The feature id for the '<em><b>Datatype</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL__DATATYPE = MODULE__DATATYPE;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' reference. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL__INTERFACE = MODULE__INTERFACE;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL__BODY = MODULE__BODY;

	/**
	 * The number of structural features of the '<em>Process Cell</em>' class. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL_FEATURE_COUNT = MODULE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Process Cell</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PROCESS_CELL_OPERATION_COUNT = MODULE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.UnitImpl <em>Unit</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.UnitImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getUnit()
	 * @generated
	 */
	int UNIT = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT__NAME = MODULE__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT__OBJECT_ID = MODULE__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Owned Property</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT__OWNED_PROPERTY = MODULE__OWNED_PROPERTY;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT__OWNED_GENERAL_OPERATION = MODULE__OWNED_GENERAL_OPERATION;

	/**
	 * The feature id for the '<em><b>Datatype</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT__DATATYPE = MODULE__DATATYPE;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' reference. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT__INTERFACE = MODULE__INTERFACE;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT__BODY = MODULE__BODY;

	/**
	 * The number of structural features of the '<em>Unit</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_FEATURE_COUNT = MODULE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Unit</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_OPERATION_COUNT = MODULE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.EquipmentModuleImpl <em>Equipment
	 * Module</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.EquipmentModuleImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getEquipmentModule()
	 * @generated
	 */
	int EQUIPMENT_MODULE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE__NAME = MODULE__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE__OBJECT_ID = MODULE__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Owned Property</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE__OWNED_PROPERTY = MODULE__OWNED_PROPERTY;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE__OWNED_GENERAL_OPERATION = MODULE__OWNED_GENERAL_OPERATION;

	/**
	 * The feature id for the '<em><b>Datatype</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE__DATATYPE = MODULE__DATATYPE;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' reference. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE__INTERFACE = MODULE__INTERFACE;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE__BODY = MODULE__BODY;

	/**
	 * The number of structural features of the '<em>Equipment Module</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE_FEATURE_COUNT = MODULE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Equipment Module</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_MODULE_OPERATION_COUNT = MODULE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.ControlModuleImpl <em>Control
	 * Module</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.ControlModuleImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getControlModule()
	 * @generated
	 */
	int CONTROL_MODULE = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE__NAME = MODULE__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE__OBJECT_ID = MODULE__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Owned Property</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE__OWNED_PROPERTY = MODULE__OWNED_PROPERTY;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE__OWNED_GENERAL_OPERATION = MODULE__OWNED_GENERAL_OPERATION;

	/**
	 * The feature id for the '<em><b>Datatype</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE__DATATYPE = MODULE__DATATYPE;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' reference. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE__INTERFACE = MODULE__INTERFACE;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE__BODY = MODULE__BODY;

	/**
	 * The number of structural features of the '<em>Control Module</em>' class. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE_FEATURE_COUNT = MODULE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Control Module</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONTROL_MODULE_OPERATION_COUNT = MODULE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl <em>General
	 * Operation</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.GeneralOperationImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getGeneralOperation()
	 * @generated
	 */
	int GENERAL_OPERATION = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Pre</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__PRE = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Post</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__POST = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__BODY = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__OWNED_GENERAL_OPERATION = NAMED_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Is implemented</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__IS_IMPLEMENTED = NAMED_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Available for user</b></em>' attribute. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__AVAILABLE_FOR_USER = NAMED_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Holding Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__HOLDING_ROUTINE = NAMED_ELEMENT_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Reset Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__RESET_ROUTINE = NAMED_ELEMENT_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Abort Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION__ABORT_ROUTINE = NAMED_ELEMENT_FEATURE_COUNT + 8;

	/**
	 * The number of structural features of the '<em>General Operation</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 9;

	/**
	 * The number of operations of the '<em>General Operation</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERAL_OPERATION_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.RecipeProcedureImpl <em>Recipe
	 * Procedure</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.RecipeProcedureImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getRecipeProcedure()
	 * @generated
	 */
	int RECIPE_PROCEDURE = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__NAME = GENERAL_OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__OBJECT_ID = GENERAL_OPERATION__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Pre</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__PRE = GENERAL_OPERATION__PRE;

	/**
	 * The feature id for the '<em><b>Post</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__POST = GENERAL_OPERATION__POST;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__BODY = GENERAL_OPERATION__BODY;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__OWNED_GENERAL_OPERATION = GENERAL_OPERATION__OWNED_GENERAL_OPERATION;

	/**
	 * The feature id for the '<em><b>Is implemented</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__IS_IMPLEMENTED = GENERAL_OPERATION__IS_IMPLEMENTED;

	/**
	 * The feature id for the '<em><b>Available for user</b></em>' attribute. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__AVAILABLE_FOR_USER = GENERAL_OPERATION__AVAILABLE_FOR_USER;

	/**
	 * The feature id for the '<em><b>Holding Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__HOLDING_ROUTINE = GENERAL_OPERATION__HOLDING_ROUTINE;

	/**
	 * The feature id for the '<em><b>Reset Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__RESET_ROUTINE = GENERAL_OPERATION__RESET_ROUTINE;

	/**
	 * The feature id for the '<em><b>Abort Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE__ABORT_ROUTINE = GENERAL_OPERATION__ABORT_ROUTINE;

	/**
	 * The number of structural features of the '<em>Recipe Procedure</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE_FEATURE_COUNT = GENERAL_OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Recipe Procedure</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int RECIPE_PROCEDURE_OPERATION_COUNT = GENERAL_OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.UnitProcedureImpl <em>Unit
	 * Procedure</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.UnitProcedureImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getUnitProcedure()
	 * @generated
	 */
	int UNIT_PROCEDURE = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__NAME = GENERAL_OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__OBJECT_ID = GENERAL_OPERATION__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Pre</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__PRE = GENERAL_OPERATION__PRE;

	/**
	 * The feature id for the '<em><b>Post</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__POST = GENERAL_OPERATION__POST;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__BODY = GENERAL_OPERATION__BODY;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__OWNED_GENERAL_OPERATION = GENERAL_OPERATION__OWNED_GENERAL_OPERATION;

	/**
	 * The feature id for the '<em><b>Is implemented</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__IS_IMPLEMENTED = GENERAL_OPERATION__IS_IMPLEMENTED;

	/**
	 * The feature id for the '<em><b>Available for user</b></em>' attribute. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__AVAILABLE_FOR_USER = GENERAL_OPERATION__AVAILABLE_FOR_USER;

	/**
	 * The feature id for the '<em><b>Holding Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__HOLDING_ROUTINE = GENERAL_OPERATION__HOLDING_ROUTINE;

	/**
	 * The feature id for the '<em><b>Reset Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__RESET_ROUTINE = GENERAL_OPERATION__RESET_ROUTINE;

	/**
	 * The feature id for the '<em><b>Abort Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE__ABORT_ROUTINE = GENERAL_OPERATION__ABORT_ROUTINE;

	/**
	 * The number of structural features of the '<em>Unit Procedure</em>' class. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE_FEATURE_COUNT = GENERAL_OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Unit Procedure</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UNIT_PROCEDURE_OPERATION_COUNT = GENERAL_OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.OperationImpl
	 * <em>Operation</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.OperationImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getOperation()
	 * @generated
	 */
	int OPERATION = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__NAME = GENERAL_OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__OBJECT_ID = GENERAL_OPERATION__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Pre</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__PRE = GENERAL_OPERATION__PRE;

	/**
	 * The feature id for the '<em><b>Post</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__POST = GENERAL_OPERATION__POST;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__BODY = GENERAL_OPERATION__BODY;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__OWNED_GENERAL_OPERATION = GENERAL_OPERATION__OWNED_GENERAL_OPERATION;

	/**
	 * The feature id for the '<em><b>Is implemented</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__IS_IMPLEMENTED = GENERAL_OPERATION__IS_IMPLEMENTED;

	/**
	 * The feature id for the '<em><b>Available for user</b></em>' attribute. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__AVAILABLE_FOR_USER = GENERAL_OPERATION__AVAILABLE_FOR_USER;

	/**
	 * The feature id for the '<em><b>Holding Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__HOLDING_ROUTINE = GENERAL_OPERATION__HOLDING_ROUTINE;

	/**
	 * The feature id for the '<em><b>Reset Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__RESET_ROUTINE = GENERAL_OPERATION__RESET_ROUTINE;

	/**
	 * The feature id for the '<em><b>Abort Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION__ABORT_ROUTINE = GENERAL_OPERATION__ABORT_ROUTINE;

	/**
	 * The number of structural features of the '<em>Operation</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION_FEATURE_COUNT = GENERAL_OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Operation</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OPERATION_OPERATION_COUNT = GENERAL_OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.PhaseImpl <em>Phase</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.PhaseImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getPhase()
	 * @generated
	 */
	int PHASE = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__NAME = GENERAL_OPERATION__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__OBJECT_ID = GENERAL_OPERATION__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Pre</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__PRE = GENERAL_OPERATION__PRE;

	/**
	 * The feature id for the '<em><b>Post</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__POST = GENERAL_OPERATION__POST;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__BODY = GENERAL_OPERATION__BODY;

	/**
	 * The feature id for the '<em><b>Owned General Operation</b></em>' reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__OWNED_GENERAL_OPERATION = GENERAL_OPERATION__OWNED_GENERAL_OPERATION;

	/**
	 * The feature id for the '<em><b>Is implemented</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__IS_IMPLEMENTED = GENERAL_OPERATION__IS_IMPLEMENTED;

	/**
	 * The feature id for the '<em><b>Available for user</b></em>' attribute. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__AVAILABLE_FOR_USER = GENERAL_OPERATION__AVAILABLE_FOR_USER;

	/**
	 * The feature id for the '<em><b>Holding Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__HOLDING_ROUTINE = GENERAL_OPERATION__HOLDING_ROUTINE;

	/**
	 * The feature id for the '<em><b>Reset Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__RESET_ROUTINE = GENERAL_OPERATION__RESET_ROUTINE;

	/**
	 * The feature id for the '<em><b>Abort Routine</b></em>' attribute. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE__ABORT_ROUTINE = GENERAL_OPERATION__ABORT_ROUTINE;

	/**
	 * The number of structural features of the '<em>Phase</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE_FEATURE_COUNT = GENERAL_OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Phase</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PHASE_OPERATION_COUNT = GENERAL_OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.ConstraintImpl
	 * <em>Constraint</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.ConstraintImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getConstraint()
	 * @generated
	 */
	int CONSTRAINT = 13;

	/**
	 * The feature id for the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT__BODY = 0;

	/**
	 * The number of structural features of the '<em>Constraint</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Constraint</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.ConstraintSetImpl <em>Constraint
	 * Set</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.ConstraintSetImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getConstraintSet()
	 * @generated
	 */
	int CONSTRAINT_SET = 14;

	/**
	 * The feature id for the '<em><b>Pre</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_SET__PRE = 0;

	/**
	 * The feature id for the '<em><b>Post</b></em>' containment reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_SET__POST = 1;

	/**
	 * The feature id for the '<em><b>Constraint Set</b></em>' reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_SET__CONSTRAINT_SET = 2;

	/**
	 * The number of structural features of the '<em>Constraint Set</em>' class. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_SET_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Constraint Set</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_SET_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.AreaImpl <em>Area</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.AreaImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getArea()
	 * @generated
	 */
	int AREA = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int AREA__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int AREA__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Owned Module</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int AREA__OWNED_MODULE = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int AREA__INTERFACE = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Area</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int AREA_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Area</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int AREA_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.SiteImpl <em>Site</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.SiteImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getSite()
	 * @generated
	 */
	int SITE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SITE__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SITE__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Area</b></em>' containment reference list. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SITE__AREA = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Site</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SITE_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Site</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SITE_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.EnterpriseImpl
	 * <em>Enterprise</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.EnterpriseImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getEnterprise()
	 * @generated
	 */
	int ENTERPRISE = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENTERPRISE__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENTERPRISE__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Site</b></em>' containment reference list. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENTERPRISE__SITE = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Enterprise</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENTERPRISE_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Enterprise</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENTERPRISE_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.InterfaceImpl
	 * <em>Interface</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.InterfaceImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getInterface()
	 * @generated
	 */
	int INTERFACE = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERFACE__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERFACE__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>ITF property</b></em>' containment reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERFACE__ITF_PROPERTY = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Interface</em>' class. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERFACE_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Interface</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERFACE_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link de.tum.mw.ais.isa88.impl.ITF_PropertyImpl <em>ITF
	 * Property</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see de.tum.mw.ais.isa88.impl.ITF_PropertyImpl
	 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getITF_Property()
	 * @generated
	 */
	int ITF_PROPERTY = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ITF_PROPERTY__NAME = NAMED_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ITF_PROPERTY__OBJECT_ID = NAMED_ELEMENT__OBJECT_ID;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ITF_PROPERTY__TYPE = NAMED_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Direction</b></em>' attribute. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ITF_PROPERTY__DIRECTION = NAMED_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>ITF Property</em>' class. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ITF_PROPERTY_FEATURE_COUNT = NAMED_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>ITF Property</em>' class. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ITF_PROPERTY_OPERATION_COUNT = NAMED_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Property <em>Property</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Property</em>'.
	 * @see de.tum.mw.ais.isa88.Property
	 * @generated
	 */
	EClass getProperty();

	/**
	 * Returns the meta object for the reference '{@link de.tum.mw.ais.isa88.Property#getType
	 * <em>Type</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Type</em>'.
	 * @see de.tum.mw.ais.isa88.Property#getType()
	 * @see #getProperty()
	 * @generated
	 */
	EReference getProperty_Type();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Property#getConstraintSet <em>Constraint Set</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Constraint Set</em>'.
	 * @see de.tum.mw.ais.isa88.Property#getConstraintSet()
	 * @see #getProperty()
	 * @generated
	 */
	EReference getProperty_ConstraintSet();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Module <em>Module</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Module</em>'.
	 * @see de.tum.mw.ais.isa88.Module
	 * @generated
	 */
	EClass getModule();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Module#getOwnedProperty <em>Owned Property</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Owned Property</em>'.
	 * @see de.tum.mw.ais.isa88.Module#getOwnedProperty()
	 * @see #getModule()
	 * @generated
	 */
	EReference getModule_OwnedProperty();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Module#getOwnedGeneralOperation <em>Owned General
	 * Operation</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Owned General
	 *         Operation</em>'.
	 * @see de.tum.mw.ais.isa88.Module#getOwnedGeneralOperation()
	 * @see #getModule()
	 * @generated
	 */
	EReference getModule_OwnedGeneralOperation();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Module#getDatatype <em>Datatype</em>}'. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Datatype</em>'.
	 * @see de.tum.mw.ais.isa88.Module#getDatatype()
	 * @see #getModule()
	 * @generated
	 */
	EReference getModule_Datatype();

	/**
	 * Returns the meta object for the reference '{@link de.tum.mw.ais.isa88.Module#getInterface
	 * <em>Interface</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Interface</em>'.
	 * @see de.tum.mw.ais.isa88.Module#getInterface()
	 * @see #getModule()
	 * @generated
	 */
	EReference getModule_Interface();

	/**
	 * Returns the meta object for the attribute '{@link de.tum.mw.ais.isa88.Module#getBody
	 * <em>Body</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Body</em>'.
	 * @see de.tum.mw.ais.isa88.Module#getBody()
	 * @see #getModule()
	 * @generated
	 */
	EAttribute getModule_Body();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.DataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Data Type</em>'.
	 * @see de.tum.mw.ais.isa88.DataType
	 * @generated
	 */
	EClass getDataType();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.ProcessCell <em>Process
	 * Cell</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Process Cell</em>'.
	 * @see de.tum.mw.ais.isa88.ProcessCell
	 * @generated
	 */
	EClass getProcessCell();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Unit <em>Unit</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Unit</em>'.
	 * @see de.tum.mw.ais.isa88.Unit
	 * @generated
	 */
	EClass getUnit();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.EquipmentModule <em>Equipment
	 * Module</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Equipment Module</em>'.
	 * @see de.tum.mw.ais.isa88.EquipmentModule
	 * @generated
	 */
	EClass getEquipmentModule();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.ControlModule <em>Control
	 * Module</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Control Module</em>'.
	 * @see de.tum.mw.ais.isa88.ControlModule
	 * @generated
	 */
	EClass getControlModule();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.NamedElement <em>Named
	 * Element</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Named Element</em>'.
	 * @see de.tum.mw.ais.isa88.NamedElement
	 * @generated
	 */
	EClass getNamedElement();

	/**
	 * Returns the meta object for the attribute '{@link de.tum.mw.ais.isa88.NamedElement#getName
	 * <em>Name</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see de.tum.mw.ais.isa88.NamedElement#getName()
	 * @see #getNamedElement()
	 * @generated
	 */
	EAttribute getNamedElement_Name();

	/**
	 * Returns the meta object for the attribute
	 * '{@link de.tum.mw.ais.isa88.NamedElement#getObjectId <em>Object Id</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Object Id</em>'.
	 * @see de.tum.mw.ais.isa88.NamedElement#getObjectId()
	 * @see #getNamedElement()
	 * @generated
	 */
	EAttribute getNamedElement_ObjectId();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.GeneralOperation <em>General
	 * Operation</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>General Operation</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation
	 * @generated
	 */
	EClass getGeneralOperation();

	/**
	 * Returns the meta object for the containment reference
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#getPre <em>Pre</em>}'. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference '<em>Pre</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#getPre()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EReference getGeneralOperation_Pre();

	/**
	 * Returns the meta object for the containment reference
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#getPost <em>Post</em>}'. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference '<em>Post</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#getPost()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EReference getGeneralOperation_Post();

	/**
	 * Returns the meta object for the attribute
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#getBody <em>Body</em>}'. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Body</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#getBody()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EAttribute getGeneralOperation_Body();

	/**
	 * Returns the meta object for the reference list
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#getOwnedGeneralOperation <em>Owned General
	 * Operation</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference list '<em>Owned General Operation</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#getOwnedGeneralOperation()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EReference getGeneralOperation_OwnedGeneralOperation();

	/**
	 * Returns the meta object for the attribute
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#isIs_implemented <em>Is implemented</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Is implemented</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#isIs_implemented()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EAttribute getGeneralOperation_Is_implemented();

	/**
	 * Returns the meta object for the attribute
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#isAvailable_for_user <em>Available for
	 * user</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Available for user</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#isAvailable_for_user()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EAttribute getGeneralOperation_Available_for_user();

	/**
	 * Returns the meta object for the attribute
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#getHolding_Routine <em>Holding Routine</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Holding Routine</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#getHolding_Routine()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EAttribute getGeneralOperation_Holding_Routine();

	/**
	 * Returns the meta object for the attribute
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#getReset_Routine <em>Reset Routine</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Reset Routine</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#getReset_Routine()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EAttribute getGeneralOperation_Reset_Routine();

	/**
	 * Returns the meta object for the attribute
	 * '{@link de.tum.mw.ais.isa88.GeneralOperation#getAbort_Routine <em>Abort Routine</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Abort Routine</em>'.
	 * @see de.tum.mw.ais.isa88.GeneralOperation#getAbort_Routine()
	 * @see #getGeneralOperation()
	 * @generated
	 */
	EAttribute getGeneralOperation_Abort_Routine();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.RecipeProcedure <em>Recipe
	 * Procedure</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Recipe Procedure</em>'.
	 * @see de.tum.mw.ais.isa88.RecipeProcedure
	 * @generated
	 */
	EClass getRecipeProcedure();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.UnitProcedure <em>Unit
	 * Procedure</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Unit Procedure</em>'.
	 * @see de.tum.mw.ais.isa88.UnitProcedure
	 * @generated
	 */
	EClass getUnitProcedure();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Operation <em>Operation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Operation</em>'.
	 * @see de.tum.mw.ais.isa88.Operation
	 * @generated
	 */
	EClass getOperation();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Phase <em>Phase</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Phase</em>'.
	 * @see de.tum.mw.ais.isa88.Phase
	 * @generated
	 */
	EClass getPhase();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Constraint
	 * <em>Constraint</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Constraint</em>'.
	 * @see de.tum.mw.ais.isa88.Constraint
	 * @generated
	 */
	EClass getConstraint();

	/**
	 * Returns the meta object for the attribute '{@link de.tum.mw.ais.isa88.Constraint#getBody
	 * <em>Body</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Body</em>'.
	 * @see de.tum.mw.ais.isa88.Constraint#getBody()
	 * @see #getConstraint()
	 * @generated
	 */
	EAttribute getConstraint_Body();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.ConstraintSet <em>Constraint
	 * Set</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Constraint Set</em>'.
	 * @see de.tum.mw.ais.isa88.ConstraintSet
	 * @generated
	 */
	EClass getConstraintSet();

	/**
	 * Returns the meta object for the containment reference
	 * '{@link de.tum.mw.ais.isa88.ConstraintSet#getPre <em>Pre</em>}'. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @return the meta object for the containment reference '<em>Pre</em>'.
	 * @see de.tum.mw.ais.isa88.ConstraintSet#getPre()
	 * @see #getConstraintSet()
	 * @generated
	 */
	EReference getConstraintSet_Pre();

	/**
	 * Returns the meta object for the containment reference
	 * '{@link de.tum.mw.ais.isa88.ConstraintSet#getPost <em>Post</em>}'. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference '<em>Post</em>'.
	 * @see de.tum.mw.ais.isa88.ConstraintSet#getPost()
	 * @see #getConstraintSet()
	 * @generated
	 */
	EReference getConstraintSet_Post();

	/**
	 * Returns the meta object for the reference
	 * '{@link de.tum.mw.ais.isa88.ConstraintSet#getConstraintSet <em>Constraint Set</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Constraint Set</em>'.
	 * @see de.tum.mw.ais.isa88.ConstraintSet#getConstraintSet()
	 * @see #getConstraintSet()
	 * @generated
	 */
	EReference getConstraintSet_ConstraintSet();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Area <em>Area</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Area</em>'.
	 * @see de.tum.mw.ais.isa88.Area
	 * @generated
	 */
	EClass getArea();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Area#getOwnedModule <em>Owned Module</em>}'. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Owned Module</em>'.
	 * @see de.tum.mw.ais.isa88.Area#getOwnedModule()
	 * @see #getArea()
	 * @generated
	 */
	EReference getArea_OwnedModule();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Area#getInterface <em>Interface</em>}'. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Interface</em>'.
	 * @see de.tum.mw.ais.isa88.Area#getInterface()
	 * @see #getArea()
	 * @generated
	 */
	EReference getArea_Interface();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Site <em>Site</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Site</em>'.
	 * @see de.tum.mw.ais.isa88.Site
	 * @generated
	 */
	EClass getSite();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Site#getArea <em>Area</em>}'. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Area</em>'.
	 * @see de.tum.mw.ais.isa88.Site#getArea()
	 * @see #getSite()
	 * @generated
	 */
	EReference getSite_Area();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Enterprise
	 * <em>Enterprise</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Enterprise</em>'.
	 * @see de.tum.mw.ais.isa88.Enterprise
	 * @generated
	 */
	EClass getEnterprise();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Enterprise#getSite <em>Site</em>}'. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Site</em>'.
	 * @see de.tum.mw.ais.isa88.Enterprise#getSite()
	 * @see #getEnterprise()
	 * @generated
	 */
	EReference getEnterprise_Site();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.Interface <em>Interface</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Interface</em>'.
	 * @see de.tum.mw.ais.isa88.Interface
	 * @generated
	 */
	EClass getInterface();

	/**
	 * Returns the meta object for the containment reference list
	 * '{@link de.tum.mw.ais.isa88.Interface#getITF_property <em>ITF property</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>ITF property</em>'.
	 * @see de.tum.mw.ais.isa88.Interface#getITF_property()
	 * @see #getInterface()
	 * @generated
	 */
	EReference getInterface_ITF_property();

	/**
	 * Returns the meta object for class '{@link de.tum.mw.ais.isa88.ITF_Property <em>ITF
	 * Property</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>ITF Property</em>'.
	 * @see de.tum.mw.ais.isa88.ITF_Property
	 * @generated
	 */
	EClass getITF_Property();

	/**
	 * Returns the meta object for the attribute '{@link de.tum.mw.ais.isa88.ITF_Property#getType
	 * <em>Type</em>}'. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see de.tum.mw.ais.isa88.ITF_Property#getType()
	 * @see #getITF_Property()
	 * @generated
	 */
	EAttribute getITF_Property_Type();

	/**
	 * Returns the meta object for the attribute
	 * '{@link de.tum.mw.ais.isa88.ITF_Property#getDirection <em>Direction</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Direction</em>'.
	 * @see de.tum.mw.ais.isa88.ITF_Property#getDirection()
	 * @see #getITF_Property()
	 * @generated
	 */
	EAttribute getITF_Property_Direction();

	/**
	 * Returns the factory that creates the instances of the model. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	isa88Factory getisa88Factory();

	/**
	 * <!-- begin-user-doc --> Defines literals for the meta objects that represent
	 * <ul>
	 * <li>each class,</li>
	 * <li>each feature of each class,</li>
	 * <li>each operation of each class,</li>
	 * <li>each enum,</li>
	 * <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.PropertyImpl
		 * <em>Property</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.PropertyImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getProperty()
		 * @generated
		 */
		EClass PROPERTY = eINSTANCE.getProperty();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' reference feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference PROPERTY__TYPE = eINSTANCE.getProperty_Type();

		/**
		 * The meta object literal for the '<em><b>Constraint Set</b></em>' containment reference
		 * list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference PROPERTY__CONSTRAINT_SET = eINSTANCE.getProperty_ConstraintSet();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.ModuleImpl
		 * <em>Module</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.ModuleImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getModule()
		 * @generated
		 */
		EClass MODULE = eINSTANCE.getModule();

		/**
		 * The meta object literal for the '<em><b>Owned Property</b></em>' containment reference
		 * list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference MODULE__OWNED_PROPERTY = eINSTANCE.getModule_OwnedProperty();

		/**
		 * The meta object literal for the '<em><b>Owned General Operation</b></em>' containment
		 * reference list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference MODULE__OWNED_GENERAL_OPERATION = eINSTANCE.getModule_OwnedGeneralOperation();

		/**
		 * The meta object literal for the '<em><b>Datatype</b></em>' containment reference list
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference MODULE__DATATYPE = eINSTANCE.getModule_Datatype();

		/**
		 * The meta object literal for the '<em><b>Interface</b></em>' reference feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference MODULE__INTERFACE = eINSTANCE.getModule_Interface();

		/**
		 * The meta object literal for the '<em><b>Body</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute MODULE__BODY = eINSTANCE.getModule_Body();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.DataTypeImpl <em>Data
		 * Type</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.DataTypeImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getDataType()
		 * @generated
		 */
		EClass DATA_TYPE = eINSTANCE.getDataType();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.ProcessCellImpl
		 * <em>Process Cell</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.ProcessCellImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getProcessCell()
		 * @generated
		 */
		EClass PROCESS_CELL = eINSTANCE.getProcessCell();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.UnitImpl <em>Unit</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.UnitImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getUnit()
		 * @generated
		 */
		EClass UNIT = eINSTANCE.getUnit();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.EquipmentModuleImpl
		 * <em>Equipment Module</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.EquipmentModuleImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getEquipmentModule()
		 * @generated
		 */
		EClass EQUIPMENT_MODULE = eINSTANCE.getEquipmentModule();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.ControlModuleImpl
		 * <em>Control Module</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.ControlModuleImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getControlModule()
		 * @generated
		 */
		EClass CONTROL_MODULE = eINSTANCE.getControlModule();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.NamedElementImpl
		 * <em>Named Element</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.NamedElementImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getNamedElement()
		 * @generated
		 */
		EClass NAMED_ELEMENT = eINSTANCE.getNamedElement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute NAMED_ELEMENT__NAME = eINSTANCE.getNamedElement_Name();

		/**
		 * The meta object literal for the '<em><b>Object Id</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute NAMED_ELEMENT__OBJECT_ID = eINSTANCE.getNamedElement_ObjectId();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.GeneralOperationImpl
		 * <em>General Operation</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.GeneralOperationImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getGeneralOperation()
		 * @generated
		 */
		EClass GENERAL_OPERATION = eINSTANCE.getGeneralOperation();

		/**
		 * The meta object literal for the '<em><b>Pre</b></em>' containment reference feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference GENERAL_OPERATION__PRE = eINSTANCE.getGeneralOperation_Pre();

		/**
		 * The meta object literal for the '<em><b>Post</b></em>' containment reference feature.
		 * <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference GENERAL_OPERATION__POST = eINSTANCE.getGeneralOperation_Post();

		/**
		 * The meta object literal for the '<em><b>Body</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute GENERAL_OPERATION__BODY = eINSTANCE.getGeneralOperation_Body();

		/**
		 * The meta object literal for the '<em><b>Owned General Operation</b></em>' reference list
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference GENERAL_OPERATION__OWNED_GENERAL_OPERATION = eINSTANCE.getGeneralOperation_OwnedGeneralOperation();

		/**
		 * The meta object literal for the '<em><b>Is implemented</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute GENERAL_OPERATION__IS_IMPLEMENTED = eINSTANCE.getGeneralOperation_Is_implemented();

		/**
		 * The meta object literal for the '<em><b>Available for user</b></em>' attribute feature.
		 * <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute GENERAL_OPERATION__AVAILABLE_FOR_USER = eINSTANCE.getGeneralOperation_Available_for_user();

		/**
		 * The meta object literal for the '<em><b>Holding Routine</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute GENERAL_OPERATION__HOLDING_ROUTINE = eINSTANCE.getGeneralOperation_Holding_Routine();

		/**
		 * The meta object literal for the '<em><b>Reset Routine</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute GENERAL_OPERATION__RESET_ROUTINE = eINSTANCE.getGeneralOperation_Reset_Routine();

		/**
		 * The meta object literal for the '<em><b>Abort Routine</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute GENERAL_OPERATION__ABORT_ROUTINE = eINSTANCE.getGeneralOperation_Abort_Routine();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.RecipeProcedureImpl
		 * <em>Recipe Procedure</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.RecipeProcedureImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getRecipeProcedure()
		 * @generated
		 */
		EClass RECIPE_PROCEDURE = eINSTANCE.getRecipeProcedure();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.UnitProcedureImpl
		 * <em>Unit Procedure</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.UnitProcedureImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getUnitProcedure()
		 * @generated
		 */
		EClass UNIT_PROCEDURE = eINSTANCE.getUnitProcedure();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.OperationImpl
		 * <em>Operation</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.OperationImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getOperation()
		 * @generated
		 */
		EClass OPERATION = eINSTANCE.getOperation();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.PhaseImpl
		 * <em>Phase</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.PhaseImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getPhase()
		 * @generated
		 */
		EClass PHASE = eINSTANCE.getPhase();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.ConstraintImpl
		 * <em>Constraint</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.ConstraintImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getConstraint()
		 * @generated
		 */
		EClass CONSTRAINT = eINSTANCE.getConstraint();

		/**
		 * The meta object literal for the '<em><b>Body</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute CONSTRAINT__BODY = eINSTANCE.getConstraint_Body();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.ConstraintSetImpl
		 * <em>Constraint Set</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.ConstraintSetImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getConstraintSet()
		 * @generated
		 */
		EClass CONSTRAINT_SET = eINSTANCE.getConstraintSet();

		/**
		 * The meta object literal for the '<em><b>Pre</b></em>' containment reference feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CONSTRAINT_SET__PRE = eINSTANCE.getConstraintSet_Pre();

		/**
		 * The meta object literal for the '<em><b>Post</b></em>' containment reference feature.
		 * <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CONSTRAINT_SET__POST = eINSTANCE.getConstraintSet_Post();

		/**
		 * The meta object literal for the '<em><b>Constraint Set</b></em>' reference feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CONSTRAINT_SET__CONSTRAINT_SET = eINSTANCE.getConstraintSet_ConstraintSet();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.AreaImpl <em>Area</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.AreaImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getArea()
		 * @generated
		 */
		EClass AREA = eINSTANCE.getArea();

		/**
		 * The meta object literal for the '<em><b>Owned Module</b></em>' containment reference list
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference AREA__OWNED_MODULE = eINSTANCE.getArea_OwnedModule();

		/**
		 * The meta object literal for the '<em><b>Interface</b></em>' containment reference list
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference AREA__INTERFACE = eINSTANCE.getArea_Interface();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.SiteImpl <em>Site</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.SiteImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getSite()
		 * @generated
		 */
		EClass SITE = eINSTANCE.getSite();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' containment reference list
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference SITE__AREA = eINSTANCE.getSite_Area();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.EnterpriseImpl
		 * <em>Enterprise</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.EnterpriseImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getEnterprise()
		 * @generated
		 */
		EClass ENTERPRISE = eINSTANCE.getEnterprise();

		/**
		 * The meta object literal for the '<em><b>Site</b></em>' containment reference list
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference ENTERPRISE__SITE = eINSTANCE.getEnterprise_Site();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.InterfaceImpl
		 * <em>Interface</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.InterfaceImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getInterface()
		 * @generated
		 */
		EClass INTERFACE = eINSTANCE.getInterface();

		/**
		 * The meta object literal for the '<em><b>ITF property</b></em>' containment reference list
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference INTERFACE__ITF_PROPERTY = eINSTANCE.getInterface_ITF_property();

		/**
		 * The meta object literal for the '{@link de.tum.mw.ais.isa88.impl.ITF_PropertyImpl <em>ITF
		 * Property</em>}' class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see de.tum.mw.ais.isa88.impl.ITF_PropertyImpl
		 * @see de.tum.mw.ais.isa88.impl.isa88PackageImpl#getITF_Property()
		 * @generated
		 */
		EClass ITF_PROPERTY = eINSTANCE.getITF_Property();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute ITF_PROPERTY__TYPE = eINSTANCE.getITF_Property_Type();

		/**
		 * The meta object literal for the '<em><b>Direction</b></em>' attribute feature. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute ITF_PROPERTY__DIRECTION = eINSTANCE.getITF_Property_Direction();

	}

} // isa88Package
