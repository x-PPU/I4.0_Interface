package de.tum.mw.ais.xppu.middleware.operation.impl;

import de.tum.mw.ais.xppu.middleware.operation.OperationInformation;

/**
 * Implementation of {@link OperationInformation}.
 *
 * @author Lucas Koehler
 *
 */
public class OperationInformationImpl implements OperationInformation {
	private String operationId;
	private String path;
	private String name;

	/**
	 * Constructor for Jackson
	 */
	protected OperationInformationImpl() {
	}

	/**
	 * Creates a new OperationInformationImpl object.
	 * <p>
	 * <strong>All parameters must not be null.</strong>
	 *
	 * @param operationId
	 *            The operation's unique id
	 * @param name
	 *            The operation's name
	 * @param path
	 *            The unambiguous path to the operation's usage in the isa88 model
	 */
	public OperationInformationImpl(String operationId, String name, String path) {
		this.operationId = operationId;
		this.name = name;
		this.path = path;
	}

	@Override
	public String getOperationId() {
		return operationId;
	}

	/**
	 * @param operationId
	 *            the operationId to set
	 */
	public void setOperationId(String operationId) {
		this.operationId = operationId;
	}

	@Override
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getPath() {
		return path;
	}

	/**
	 * @param path
	 *            the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((operationId == null) ? 0 : operationId.hashCode());
		result = prime * result + ((path == null) ? 0 : path.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof OperationInformationImpl)) {
			return false;
		}
		final OperationInformationImpl other = (OperationInformationImpl) obj;
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		if (operationId == null) {
			if (other.operationId != null) {
				return false;
			}
		} else if (!operationId.equals(other.operationId)) {
			return false;
		}
		if (path == null) {
			if (other.path != null) {
				return false;
			}
		} else if (!path.equals(other.path)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return String.format("OperationInformationImpl [operationId=%s, name=%s, path=%s]", operationId, name, path);
	}
}
