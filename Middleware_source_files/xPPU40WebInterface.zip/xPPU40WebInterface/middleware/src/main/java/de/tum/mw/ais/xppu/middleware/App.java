package de.tum.mw.ais.xppu.middleware;

import static spark.Spark.get;
import static spark.Spark.port;
import static spark.Spark.post;

import java.util.LinkedHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.tum.mw.ais.xppu.middleware.config.Configuration;
import de.tum.mw.ais.xppu.middleware.config.ConfigurationException;
import de.tum.mw.ais.xppu.middleware.controller.Controller;
import de.tum.mw.ais.xppu.middleware.controller.ControllerInitializationException;
import de.tum.mw.ais.xppu.middleware.controller.ControllerSettings;
import de.tum.mw.ais.xppu.middleware.controller.impl.ControllerImpl;
import de.tum.mw.ais.xppu.middleware.history.History;
import de.tum.mw.ais.xppu.middleware.history.impl.HistoryImpl;
import de.tum.mw.ais.xppu.middleware.operation.InstanceModelLoader;
import de.tum.mw.ais.xppu.middleware.operation.OperationInformationLoader;
import de.tum.mw.ais.xppu.middleware.operation.OperationResolver;
import de.tum.mw.ais.xppu.middleware.operation.impl.OperationInformationLoaderImpl;
import de.tum.mw.ais.xppu.middleware.operation.impl.OperationResolverImpl;
import de.tum.mw.ais.xppu.middleware.operation.impl.XmiInstanceModelLoader;
import de.tum.mw.ais.xppu.middleware.plc.PlcConnection;
import de.tum.mw.ais.xppu.middleware.plc.PlcConnectionException;
import de.tum.mw.ais.xppu.middleware.plc.opc.OpcUaConnection;
import de.tum.mw.ais.xppu.middleware.plc.opc.OpcUaSettings;

/**
 * The middleware's main class which configures and starts up the web service and connection to the
 * plc.
 *
 */
public class App {

	private static Logger logger = LoggerFactory.getLogger(App.class);

	/**
	 * @param args
	 *            The command line arguments of the application
	 */
	public static void main(String[] args) {
		Controller controller;
		try {
			final Configuration config = new Configuration(args);

			final InstanceModelLoader modelLoader = new XmiInstanceModelLoader();
			final OperationInformationLoader operationInformationLoader = new OperationInformationLoaderImpl();
			final OperationResolver operationResolver = new OperationResolverImpl();
			final History history = new HistoryImpl(config.getHistoryCapacity());

			final PlcConnection plc = new OpcUaConnection();
			final LinkedHashMap<Object, Object> plcConfiguration = new LinkedHashMap<>();
			plcConfiguration.put(OpcUaSettings.NAMESPACE_INDEX, config.getNamespaceIndex());
			plcConfiguration.put(OpcUaSettings.NAMESPACE_URI, config.getNamespaceUri());
			plcConfiguration.put(OpcUaSettings.SERVER_URI, config.getServerUri());
			plcConfiguration.put(OpcUaSettings.FLAG_SWITCH_DELAY, config.getFlagSwitchDelay());
			plcConfiguration.put(OpcUaSettings.HISTORY, history);
			plc.initialize(plcConfiguration);
			plc.connectAndConfigure();

			final LinkedHashMap<Object, Object> controllerConfiguration = new LinkedHashMap<>();
			controllerConfiguration.put(ControllerSettings.MODEL_PATH, config.getInstanceModelPath());
			controllerConfiguration.put(ControllerSettings.OPERATION_LIST_PATH, config.getOperationListPath());
			controllerConfiguration.put(ControllerSettings.HISTORY, history);

			controller = new ControllerImpl(plc, modelLoader, operationInformationLoader,
					operationResolver);
			controller.initialize(controllerConfiguration);

		} catch (final ConfigurationException | PlcConnectionException | ControllerInitializationException e) {
			logger.error("The application could not be started due to a fatal exception during start up.", e);
			System.exit(1);
			return;
		}

		// Configure Spark
		port(4567);

		// Set up routes

		// Get all resolved operations
		get("/operations", (request, response) -> {
			return controller.getOperations(request, response);
		});

		// Get an operation for a given operation ID
		get("/operations/:operationId", (request, response) -> {
			return controller.getOperation(request, response);
		});

		// mode selection
		post("mode/manual", (request, response) -> {
			return controller.setManualMode(request, response);
		});

		post("mode/automatic", (request, response) -> {
			return controller.setAutomaticMode(request, response);
		});

		// execute batch with ids from operationids query parameter
		post("startbatch", (request, response) -> {
			return controller.startBatchFromQuery(request, response);
		});

		// execute the operation with the id given as the last path segment (manual)
		post("start/:operationId", (request, response) -> {
			return controller.startOperation(request, response);
		});

		post("restart", (request, response) -> {
			return controller.restartOperationExcecution(request, response);
		});

		post("hold", (request, response) -> {
			return controller.holdOperationExcecution(request, response);
		});

		post("abort", (request, response) -> {
			return controller.abortOperationExcecution(request, response);
		});

		// get the emf isa88 instance model of the PLC
		get("instance", (request, response) -> {
			return controller.getInstanceModel(request, response);
		});

		// history methods
		get("history/complete", (request, response) -> {
			return controller.getCompleteHistory(request, response);
		});

		get("history/operationid/:id", (request, response) -> {
			return controller.getHistoryByOperationId(request, response);
		});

		get("history/executionid/:id", (request, response) -> {
			return controller.getHistoryByExecutionId(request, response);
		});

		get("history/module/:name", (request, response) -> {
			return controller.getHistoryByModuleName(request, response);
		});

		get("history/timestamp/:timestamp", (request, response) -> {
			return controller.getHistoryNewerThanDate(request, response);
		});

	}
}
