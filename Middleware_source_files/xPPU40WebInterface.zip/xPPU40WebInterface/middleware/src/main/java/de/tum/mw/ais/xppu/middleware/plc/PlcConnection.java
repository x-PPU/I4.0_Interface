package de.tum.mw.ais.xppu.middleware.plc;

import java.util.Map;

/**
 * A {@link PlcConnection} offers methods to communicate with a PLC (Programmable Logic Controller)
 * and execute operations on it. Operations are identified by an unique ID. Operations are executed
 * asynchronously. This means the PlcConnection tells the connected PLC which operation should be
 * executed but does not block until the operation is finished. Therefore, callbacks are used. Their
 * methods are executed when the connected PLC delivers feedback on the operation's execution.
 *
 * @author Lucas Koehler
 *
 */
public interface PlcConnection {

	/**
	 * Initializes the {@link PlcConnection} with all the parameters it needs for operation. This
	 * method must be called before any other methods of a {@link PlcConnection} can be executed.
	 *
	 * @param configuration
	 *            The map containing the configuration of the {@link PlcConnection}
	 * @throws PlcInitializationException
	 *             If the configuration did not contain all necessary configuration parameters
	 */
	void initialize(Map<Object, Object> configuration) throws PlcInitializationException;

	/**
	 * The PlcConnection connects to the PLC and gets ready to execute operations. Thereby, the
	 * connection configures and initializes options that are only possible after a successful
	 * connection to the server (e.g. subscriptions). The {@link PlcConnection} must be initialized
	 * before this method is called.
	 *
	 * @throws PlcConnectionException
	 *             If an exception occurred during the connection or configuration process
	 */
	void connectAndConfigure() throws PlcConnectionException;

	/**
	 * Tells the connected PLC to execute the operation defined by the operations unique ID. The
	 * execution happens asynchronously. The callback is called when the PLC writes out a result of
	 * the operations execution.
	 *
	 * @param operationId
	 *            The unique ID identifying the operation to execute
	 * @param callback
	 *            The {@link ExecuteOperationCallback} to call after the PLC provided feedback.
	 * @throws PlcConnectionException
	 *             If an exception occurred while transmitting the execution information to the PLC
	 */
	void startOperation(String operationId, ExecuteOperationCallback callback) throws PlcConnectionException;

	/**
	 * Tells the PLC to execute the batch of given operation ids in automatic mode. The executions
	 * happen asynchronously. The corresponding callback is called whenever the PLC writes out a
	 * result code for the currently executed operation. For every operationId there has to be
	 * exactly one callback.
	 *
	 * @param operationIds
	 *            The batch of operations to execute
	 * @param resolvedOperationPaths
	 *            The operations' resolved paths
	 * @param callbacks
	 *            The {@link ExecuteBatchOperationCallback ExecuteBatchOperationCallbacks} to call
	 *            when the PLC provides feedback
	 * @throws PlcConnectionException
	 *             If an exception occurred while transmitting the execution information to the PLC
	 */
	void executeBatch(String[] operationIds, String[] resolvedOperationPaths, ExecuteBatchOperationCallback[] callbacks)
			throws PlcConnectionException;

	/**
	 * Tells the Plc to pause the execution of the current Operation. Pausing means that the
	 * operation can be continued later on. Furthermore, no other operation can be executed until
	 * the current operation has finished or has been canceled.
	 * <p>
	 * <strong>Note:</strong> It is not checked whether the Plc is actually executing an operation.
	 *
	 * @param manualOperation
	 *            <code>true</code> = cancel manual operation, <code>false</code> cancel batch
	 *            execution
	 *
	 * @throws PlcConnectionException
	 *             If an exception occurred while telling the PLC to pause the current operation
	 */
	void holdOperationExecution(boolean manualOperation) throws PlcConnectionException;

	/**
	 * Tells the Plc to continue a paused operation.
	 * <p>
	 * <strong>Note:</strong> It is not checked whether there actually is a paused operation on the
	 * Plc. But if there is not, nothing should happen on the Plc.
	 *
	 * @param manualOperation
	 *            <code>true</code> = cancel manual operation, <code>false</code> cancel batch
	 *            execution
	 *
	 * @throws PlcConnectionException
	 *             If an exception occurred while telling the PLC to continue the current operation
	 */
	void restartOperationExecution(boolean manualOperation) throws PlcConnectionException;

	/**
	 * Tells the Plc to cancel the execution of the current Operation. This means the operation
	 * cannot be continued and another operation can be executed instead.
	 * <p>
	 * <strong>Note:</strong> It is not checked whether the Plc is actually executing an operation.
	 * But if no operation is executed, simply nothing should happen on the Plc
	 *
	 * @param manualOperation
	 *            <code>true</code> = cancel manual operation, <code>false</code> cancel batch
	 *            execution
	 *
	 * @throws PlcConnectionException
	 *             If an exception occurred while telling the PLC to cancel the current operation
	 */
	void abortOperationExecution(boolean manualOperation) throws PlcConnectionException;

	/**
	 * Sets the PLC's execution mode to manual.
	 *
	 * @throws PlcConnectionException
	 *             If an exception occurred while communicating with the PLC
	 */
	void setManualMode() throws PlcConnectionException;

	/**
	 * Sets the PLC's execution mode to automatic.
	 *
	 * @throws PlcConnectionException
	 *             If an exception occurred while communicating with the PLC
	 */
	void setAutomaticMode() throws PlcConnectionException;
}
