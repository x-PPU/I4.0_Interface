package de.tum.mw.ais.xppu.middleware.controller.impl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import de.tum.mw.ais.isa88.Enterprise;
import de.tum.mw.ais.xppu.middleware.controller.Controller;
import de.tum.mw.ais.xppu.middleware.controller.ControllerInitializationException;
import de.tum.mw.ais.xppu.middleware.controller.ControllerSettings;
import de.tum.mw.ais.xppu.middleware.history.History;
import de.tum.mw.ais.xppu.middleware.history.HistoryEntry;
import de.tum.mw.ais.xppu.middleware.history.HistoryException;
import de.tum.mw.ais.xppu.middleware.operation.InstanceModelLoader;
import de.tum.mw.ais.xppu.middleware.operation.ModelLoadException;
import de.tum.mw.ais.xppu.middleware.operation.OperationInformation;
import de.tum.mw.ais.xppu.middleware.operation.OperationInformationLoader;
import de.tum.mw.ais.xppu.middleware.operation.OperationInstance;
import de.tum.mw.ais.xppu.middleware.operation.OperationResolver;
import de.tum.mw.ais.xppu.middleware.plc.ExecuteBatchOperationCallback;
import de.tum.mw.ais.xppu.middleware.plc.PlcConnection;
import de.tum.mw.ais.xppu.middleware.plc.PlcConnectionException;
import de.tum.mw.ais.xppu.middleware.plc.opc.OpcUaConnection;
import spark.Request;
import spark.Response;

/**
 * Implementation of {@link Controller}.
 *
 * @author Lucas Koehler
 *
 */
public class ControllerImpl implements Controller {

	private static final String OPERATION_IDS = "operationids";
	private static final String EXECUTION_ID = "executionid";
	private static final String MSG_NO_EXECUTION_ID = "No execution id was provided. It has to be provided as a query parameter with the key: "
			+ EXECUTION_ID;
	/**
	 * MIME type for xmi data.
	 */
	private static final String APPLICATION_XMI_XML = "application/xmi+xml";
	private static final int HTTP_INTERNAL_SERVER_ERROR = 500;
	private static final String MSG_NOT_INITIALIZED = "Webservice has not been initialized, yet.";
	/**
	 * MIME type for JSON data.
	 */
	private static final String APPLICATION_JSON = "application/json";
	private static final int HTTP_BAD_REQUEST = 400;
	private static final Logger logger = LoggerFactory.getLogger(ControllerImpl.class);

	/**
	 * The maximum batch size for a execution task in automatic mode.
	 */
	private static final int MAX_BATCH_SIZE = 20;

	private boolean initialized = false;
	/**
	 * True = manual mode. False = automatic mode.
	 */
	private boolean manualMode = true;
	private final PlcConnection plcConnection;
	private final InstanceModelLoader modelLoader;
	private final OperationInformationLoader operationInformationLoader;
	private final OperationResolver operationResolver;
	private ObjectMapper objectMapper;
	private String modelPath;
	private Map<String, OperationInstance> resolvedOperations;
	private History history;

	/**
	 * Creates a new instance of {@link ControllerImpl}. Before its methods can be used, the
	 * {@link #initialize(Map)} method must be executed successfully.
	 * <p>
	 * The Controller is initialized in <strong>manual</strong> execution mode.
	 *
	 * @param plcConnection
	 *            The {@link PlcConnection} to use to communicate with the PLC to remote control
	 * @param modelLoader
	 *            The {@link InstanceModelLoader} to read in the isa88 instance model of the PLC
	 * @param operationInformationLoader
	 *            The {@link OperationInformationLoader} to load the operation list of the instance
	 *            model
	 * @param operationResolver
	 *            The {@link OperationResolver} to resolve the operations defined in the operation
	 *            list against the loaded instance model
	 */
	public ControllerImpl(PlcConnection plcConnection, InstanceModelLoader modelLoader,
			OperationInformationLoader operationInformationLoader, OperationResolver operationResolver) {
		this.plcConnection = plcConnection;
		this.modelLoader = modelLoader;
		this.operationInformationLoader = operationInformationLoader;
		this.operationResolver = operationResolver;

	}

	@Override
	public void initialize(Map<Object, Object> configuration) throws ControllerInitializationException {
		logger.debug("Start initializing controller...");
		modelPath = readInitializationParameter(configuration, ControllerSettings.MODEL_PATH, String.class, true);
		final String operationListPath = readInitializationParameter(configuration,
				ControllerSettings.OPERATION_LIST_PATH, String.class, true);
		history = readInitializationParameter(configuration, ControllerSettings.HISTORY, History.class, true);

		// Load and resolve model
		try {
			final Enterprise modelRoot = modelLoader.loadModel(modelPath);
			final List<OperationInformation> operationInformation = operationInformationLoader
					.loadOperationInformation(operationListPath);
			resolvedOperations = operationResolver.resolveOperations(operationInformation, modelRoot);
		} catch (final IOException | ModelLoadException e) {
			throw new ControllerInitializationException("Could not initialize the Controller due to an exception.", e);
		}

		// Create and configure Jackson object mapper
		objectMapper = new ObjectMapper();
		objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
		initialized = true;
	}

	/**
	 * Reads configuration parameter for the given key from the configuration map, checks that it is
	 * not <code>null</code>, and converts it to the type given by the valueClass parameter.
	 *
	 * @param configuration
	 *            The configuration map
	 * @param key
	 *            The configuration parameter key
	 * @param valueClass
	 *            The class to convert the value to
	 * @param required
	 *            Whether the parameter must be set for this {@link OpcUaConnection} to be
	 *            initialized correctly
	 * @return The converted configuration parameter's value
	 * @throws ControllerInitializationException
	 *             if the value is null or cannot be converted to the given type
	 */
	private <T> T readInitializationParameter(Map<Object, Object> configuration, Object key, Class<T> valueClass,
			boolean required) throws ControllerInitializationException {
		final Object valueObject = configuration.get(key);
		if (valueObject == null) {
			if (required) {
				throw new ControllerInitializationException(
						String.format(
								"The required configuration parameter for key %s was null. Check whether you provided all necessessary parameters in the configuration file.",
								key));
			}
			return null;
		}
		try {
			return valueClass.cast(valueObject);
		} catch (final ClassCastException e) {
			throw new ControllerInitializationException(
					String.format("The configuration parameter for key %1$s must be of type %2$s but is of type %3$s",
							key, valueClass.getSimpleName(), valueObject.getClass().getSimpleName()));
		}
	}

	@Override
	public String getInstanceModel(Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}
		final StringBuilder builder = new StringBuilder();
		try (final BufferedReader br = new BufferedReader(new FileReader(modelPath))) {
			String line = br.readLine();
			for (; line != null; line = br.readLine()) {
				builder.append(line);
				builder.append("\n");
			}
		} catch (final IOException e) {
			response.status(500); // internal server error
			return "Could not return the model due to an internal error reading the model file.";
		}
		// mime-type for xmi data which the emf instance model is serialized as
		response.type(APPLICATION_XMI_XML);
		return builder.toString();
	}

	@Override
	public String getOperations(Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}
		String result;
		try {
			result = objectMapper.writeValueAsString(resolvedOperations.values());
		} catch (final IOException e) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			logger.error("An unexpected IOException occured while serializing the resolved operations.", e);
			return "An unexpected IOException occured while serializing the resolved operations.";
		}
		response.type(APPLICATION_JSON);
		return result;
	}

	@Override
	public String getOperation(Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}
		final String operationId = request.params("operationId");
		if (operationId == null || operationId.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return "The provided operation id must not be null nor empty.";
		}

		final OperationInstance operationInstance = resolvedOperations.get(operationId);
		if (operationInstance == null) {
			response.status(HTTP_BAD_REQUEST);
			return String.format("There does not exist an operation with id: %s.", operationId);
		}

		response.type(APPLICATION_JSON);
		try {
			return objectMapper.writeValueAsString(operationInstance);
		} catch (final JsonProcessingException e) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			logger.error(String.format("Could not serialize resolved operation with id: %s.", operationId), e);
			return "An unexpected JsonProcessingException occured while serializing the resolved operation with id: "
			+ operationId;
		}
	}

	@Override
	public synchronized String abortOperationExcecution(Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}

		final String executionId = request.queryParams(EXECUTION_ID);
		if (executionId == null || executionId.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return MSG_NO_EXECUTION_ID;
		}

		try {
			history.offerAbortOperation(executionId);
		} catch (final HistoryException e) {
			logger.warn(String.format("Could not offer cancel operation for execution id: %s", executionId), e);
			response.status(HTTP_BAD_REQUEST);
			return e.getMessage();
		}

		HistoryEntry entry;
		try {
			plcConnection.abortOperationExecution(manualMode);
			entry = history.finishOffer();
		} catch (final PlcConnectionException e) {
			history.resetOffer();
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			logger.error("Could not cancel operation execution.", e);
			return "Could not tell the PLC to cancel the operation execution due to an exception while communicating with the PLC.";
		} catch (final HistoryException e) {
			logger.error(String.format("Could not finish cancel operation for execution id: %s", executionId), e);
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return e.getMessage();
		}

		// Serialize and return the created history entry
		try {
			final String result = objectMapper.writeValueAsString(entry);
			response.type(APPLICATION_JSON);
			return result;
		} catch (final JsonProcessingException e) {
			logger.error("Could not serialize HistoryEntry", e);
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return "Operation was canceled but the resulting history entry could not be serialized due to an unexpected exception.";
		}
	}

	@Override
	public synchronized String restartOperationExcecution(Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}

		final String executionId = request.queryParams(EXECUTION_ID);
		if (executionId == null || executionId.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return MSG_NO_EXECUTION_ID;
		}

		HistoryEntry entry;
		try {
			entry = history.restartOperation(executionId);
			plcConnection.restartOperationExecution(manualMode);
		} catch (final HistoryException e) {
			logger.error(String.format("Could not continue operation for execution id: %s", executionId), e);
			response.status(HTTP_BAD_REQUEST);
			return e.getMessage();
		} catch (final PlcConnectionException e) {
			history.removeNewestEntry(); // Remove added entry that is now obsolete
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			logger.error("Could not continue operation execution.", e);
			return "Could not tell the PLC to continue operation execution due to an exception while communicating with the PLC.";
		}

		// Serialize and return the created history entry
		try {
			final String result = objectMapper.writeValueAsString(entry);
			response.type(APPLICATION_JSON);
			return result;
		} catch (final JsonProcessingException e) {
			logger.error("Could not serialize HistoryEntry", e);
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return "Operation was continued but the resulting history entry could not be serialized due to an unexpected exception.";
		}
	}

	@Override
	public synchronized String holdOperationExcecution(Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}
		final String executionId = request.queryParams(EXECUTION_ID);
		if (executionId == null || executionId.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return MSG_NO_EXECUTION_ID;
		}

		try {
			history.offerHoldOperation(executionId);
		} catch (final HistoryException e) {
			logger.warn(String.format("Could not offer pause operation for execution id: %s", executionId), e);
			response.status(HTTP_BAD_REQUEST);
			return e.getMessage();
		}

		HistoryEntry entry;
		try {
			plcConnection.holdOperationExecution(manualMode);
			entry = history.finishOffer();
		} catch (final PlcConnectionException e) {
			history.resetOffer();
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			logger.error("Could not pause operation execution.", e);
			return "Could not tell the PLC to pause operation execution due to an exception while communicating with the PLC.";
		} catch (final HistoryException e) {
			logger.error(String.format("Could not finish pause operation for execution id: %s", executionId), e);
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return e.getMessage();
		}

		// Serialize and return the created history entry
		try {
			final String result = objectMapper.writeValueAsString(entry);
			response.type(APPLICATION_JSON);
			return result;
		} catch (final JsonProcessingException e) {
			logger.error("Could not serialize HistoryEntry", e);
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return "Operation was paused but the resulting history entry could not be serialized due to an unexpected exception.";
		}
	}


	@Override
	public synchronized String startOperation(Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}

		// Check that there exists a resolved operation for the given id
		final String operationId = request.params("operationId");
		if (operationId == null || operationId.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return "The provided operation id must not be null nor empty.";
		}
		final OperationInstance operationInstance = resolvedOperations.get(operationId);
		if (operationInstance == null) {
			response.status(HTTP_BAD_REQUEST);
			return String.format("There does not exist an operation with id: %s.", operationId);
		}

		// Execute the operation
		HistoryEntry entry;
		try {
			entry = history.startOperation(operationId, operationInstance.getResolvedPath());
			plcConnection.startOperation(operationId, new ExecutionCallback(history, entry.getExecutionId()));
		} catch (final HistoryException e) {
			response.status(HTTP_BAD_REQUEST);
			logger.error(String.format("Could not execute operation for operation id: %s", operationId), e);
			return e.getMessage();
		} catch (final PlcConnectionException e) {
			history.removeNewestEntry(); // Remove added entry that is now obsolete
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			logger.error(String.format("Could not execute operation with id: %s.", operationId), e);
			return String.format(
					"Could not tell the PLC to execute operation with id %s due to an exception while communicating with the PLC.",
					operationId);
		}

		// Serialize and return the created history entry
		try {
			final String result = objectMapper.writeValueAsString(entry);
			response.type(APPLICATION_JSON);
			return result;
		} catch (final JsonProcessingException e) {
			logger.error("Could not serialize HistoryEntry", e);
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return "Operation was executed but the resulting history entry could not be serialized due to an unexpected exception.";
		}
	}

	@Override
	public String getCompleteHistory(Request request, Response response) {
		final List<HistoryEntry> entries = history.getAllEntries();
		return serializeHistoryEntriesAndPrepareResponse(response, entries);
	}

	@Override
	public String getHistoryByOperationId(Request request, Response response) {
		final String operationId = request.params("id");
		if (operationId == null || operationId.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return "No operation id was provided";
		}
		final List<HistoryEntry> entries = history.getEntriesForOperationId(operationId);
		return serializeHistoryEntriesAndPrepareResponse(response, entries);
	}

	@Override
	public String getHistoryByExecutionId(Request request, Response response) {
		final String executionId = request.params("id");
		if (executionId == null || executionId.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return "No execution id was provided";
		}
		final List<HistoryEntry> entries = history.getEntriesForExecutionId(executionId);
		return serializeHistoryEntriesAndPrepareResponse(response, entries);
	}

	@Override
	public String getHistoryByModuleName(Request request, Response response) {
		final String moduleName = request.params("name");
		if (moduleName == null || moduleName.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return "No module name was provided";
		}
		final List<HistoryEntry> entries = history.getEntriesForModule(moduleName);
		return serializeHistoryEntriesAndPrepareResponse(response, entries);
	}

	@Override
	public String getHistoryNewerThanDate(Request request, Response response) {
		final String timestampString = request.params("timestamp");
		try {
			final Instant timestamp = Instant.parse(timestampString);
			final List<HistoryEntry> entries = history.getEntriesNewerThan(timestamp);
			return serializeHistoryEntriesAndPrepareResponse(response, entries);
		} catch (final DateTimeParseException e) {
			logger.info(String.format("The provided timestamp %s could not be deserialized to an Instant.",
					timestampString), e);
			response.status(HTTP_BAD_REQUEST);
			return "The timestamp was provided in an illegal format. Your timestamp needs to be provided like this: 2011-12-03T10:15:30.123Z. Fractional seconds can be speciefied with zero to nine digits. All times are in UTC. For more information see https://docs.oracle.com/javase/8/docs/api/java/time/format/DateTimeFormatter.html#ISO_INSTANT";
		}
	}

	/**
	 * Serializes the given list of history entries and sets the appropriate fields in the
	 * {@link Response}.
	 *
	 * @param response
	 * @param entries
	 * @return
	 */
	private String serializeHistoryEntriesAndPrepareResponse(Response response, final List<HistoryEntry> entries) {
		try {
			final String result = objectMapper.writeValueAsString(entries);
			response.type(APPLICATION_JSON);
			return result;
		} catch (final JsonProcessingException e) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			logger.error("Could not serialize a list of history entries.", e);
			return "History entries could not be serialized due to an unexpected exception.";
		}
	}

	@Override
	public synchronized String setAutomaticMode(Request request, Response response) {
		return setManualMode(false, request, response);
	}

	@Override
	public synchronized String setManualMode(Request request, Response response) {
		return setManualMode(true, request, response);
	}

	/**
	 * Sets the execution mode to manual or automatic mode.
	 *
	 * @param manual
	 *            <code>true</code> sets the execution mode to <strong>manual</strong>,
	 *            <code>false</code> sets it to <strong>automatic</strong>
	 * @return
	 */
	private String setManualMode(boolean manual, Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}
		if (manualMode == manual) {
			// Nothing to change
			response.status(204);
			return "";
		}
		try {
			HistoryEntry resultEntry;
			if (manual) {
				resultEntry = history.setManualMode();
				plcConnection.setManualMode();
				logger.info("Execution mode was set to manual.");
			} else {
				resultEntry = history.setAutomaticMode();
				plcConnection.setAutomaticMode();
				logger.info("Execution mode was set to automatic.");
			}
			manualMode = manual;
			// Serialize and return the created history entry
			final String result = objectMapper.writeValueAsString(resultEntry);
			response.type(APPLICATION_JSON);
			return result;
		} catch (final HistoryException e) {
			logger.error("Could change execution mode.", e);
			response.status(HTTP_BAD_REQUEST);
			return e.getMessage();
		} catch (final JsonProcessingException e) {
			logger.error("Could not serialize HistoryEntry", e);
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return "Execution mode was changed but the resulting history entry could not be serialized due to an unexpected exception.";
		} catch (final PlcConnectionException e) {
			history.removeNewestEntry();
			logger.error("Could not change execution mode on the PLC.", e);
			return "Could not change execution mode on the PLC due to an exception: " + e.getMessage();
		}
	}


	@Override
	public synchronized String startBatchFromQuery(Request request, Response response) {
		if (!initialized) {
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return MSG_NOT_INITIALIZED;
		}
		if (manualMode) {
			response.status(HTTP_BAD_REQUEST);
			return "The middleware must be set to automatic mode before a batch can be executed.";
		}

		final String operationIds = request.queryParams(OPERATION_IDS);
		if (operationIds == null || operationIds.isEmpty()) {
			response.status(HTTP_BAD_REQUEST);
			return "No operation ids were provided. At least one needs to be provided for the key operationIds.";
		}
		final String[] idArray = operationIds.trim().split(";");
		if (idArray.length == 0) {
			response.status(HTTP_BAD_REQUEST);
			return "The batch must contain at least one operation id.";
		}
		if (idArray.length > MAX_BATCH_SIZE) {
			response.status(HTTP_BAD_REQUEST);
			return String.format("The batch must contain at most %d operation ids.", MAX_BATCH_SIZE);
		}

		HistoryEntry historyEntry;
		try {
			historyEntry = history.startBatchExecution(idArray.length);
			final ExecuteBatchOperationCallback[] callbacks = new ExecuteBatchOperationCallback[idArray.length];

			// The callbacks for all but the last operation work the same
			final BatchExecutionCallback defaultCallback = new BatchExecutionCallback(history,
					historyEntry.getExecutionId());
			for (int i = 0; i < callbacks.length - 1; i++) {
				callbacks[i] = defaultCallback;
			}
			// The callback of the last batch operation closes the batch after successful execution
			callbacks[callbacks.length - 1] = new FinalisingBatchExecutionCallback(history,
					historyEntry.getExecutionId());

			final String[] resolvedOperationPaths = new String[idArray.length];
			for (int i = 0; i < idArray.length; i++) {
				resolvedOperationPaths[i] = resolvedOperations.get(idArray[i]).getResolvedPath();
			}
			plcConnection.executeBatch(idArray, resolvedOperationPaths, callbacks);
		} catch (final HistoryException e) {
			response.status(HTTP_BAD_REQUEST);
			logger.error(String.format("Could not execute batch for operation ids: %s", Arrays.toString(idArray)), e);
			return e.getMessage();
		} catch (final PlcConnectionException e) {
			history.removeNewestEntry();
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			logger.error(String.format("Could not execute batch for operation ids: %s", Arrays.toString(idArray)), e);
			return String.format(
					"Could not tell the PLC to execute operation with ids %s due to an exception while communicating with the PLC.",
					Arrays.toString(idArray));
		}

		// Serialize and return the created history entry
		try {
			final String result = objectMapper.writeValueAsString(historyEntry);
			response.type(APPLICATION_JSON);
			return result;
		} catch (final JsonProcessingException e) {
			logger.error("Could not serialize HistoryEntry", e);
			response.status(HTTP_INTERNAL_SERVER_ERROR);
			return "Batch execution was started but the resulting history entry could not be serialized due to an unexpected exception.";
		}
	}
}
