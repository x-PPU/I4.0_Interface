/**
 */
package de.tum.mw.ais.isa88;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Equipment Module</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getEquipmentModule()
 * @model
 * @generated
 */
public interface EquipmentModule extends Module {
} // EquipmentModule
