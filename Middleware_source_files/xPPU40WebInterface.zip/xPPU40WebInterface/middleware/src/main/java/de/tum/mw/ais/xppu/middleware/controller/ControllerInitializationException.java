package de.tum.mw.ais.xppu.middleware.controller;

/**
 * @author Lucas Koehler
 *
 */
public class ControllerInitializationException extends Exception {

	/**
	 * Generated serialization ID.
	 */
	private static final long serialVersionUID = -1442457481038530430L;

	/**
	 * An {@link Exception} that is thrown when something goes wrong during the initialization of a
	 * {@link Controller}.
	 * 
	 * @param message
	 *            The error message
	 */
	public ControllerInitializationException(String message) {
		super(message);
	}

	/**
	 * An {@link Exception} that is thrown when something goes wrong during the initialization of a
	 * {@link Controller}.
	 * 
	 * @param message
	 *            The error message
	 * @param cause
	 *            The Throwable causing this {@link Exception}
	 */
	public ControllerInitializationException(String message, Throwable cause) {
		super(message, cause);
	}
}
