package de.tum.mw.ais.xppu.middleware.plc;

/**
 * Indicates that something went wrong while initializing a {@link PlcConnection}.
 *
 * @author Lucas Koehler
 *
 */
public class PlcInitializationException extends PlcConnectionException {
	/**
	 * Generated serialization ID.
	 */
	private static final long serialVersionUID = 2741322056089440739L;

	/**
	 * Creates a new {@link PlcInitializationException} with the given detail message.
	 *
	 * @param message
	 *            The exception's detail message
	 */
	public PlcInitializationException(String message) {
		super(message);
	}

	/**
	 * Create a new {@link PlcInitializationException} with the given detail message and cause.
	 *
	 * @param message
	 *            The exception's detail message
	 * @param cause
	 *            The {@link Throwable} that caused this exception
	 */
	public PlcInitializationException(String message, Throwable cause) {
		super(message, cause);
	}
}
