/**
 */
package de.tum.mw.ais.isa88;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Process Cell</b></em>'. <!--
 * end-user-doc -->
 *
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getProcessCell()
 * @model
 * @generated
 */
public interface ProcessCell extends Module {
} // ProcessCell
