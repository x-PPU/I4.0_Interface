package de.tum.mw.ais.xppu.middleware.history.impl;

import java.util.UUID;

/**
 * Generates unique execution ids for the {@link HistoryImpl}.
 *
 * @author Lucas Koehler
 *
 */
public class ExecutionIdGenerator {

	/**
	 * @return The next id.
	 */
	public String next() {
		return UUID.randomUUID().toString();
	}
}
