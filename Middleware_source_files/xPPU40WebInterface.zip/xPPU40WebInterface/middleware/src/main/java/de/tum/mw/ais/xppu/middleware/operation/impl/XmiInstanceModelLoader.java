package de.tum.mw.ais.xppu.middleware.operation.impl;

import java.io.IOException;
import java.util.Map;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.tum.mw.ais.isa88.Enterprise;
import de.tum.mw.ais.isa88.isa88Package;
import de.tum.mw.ais.xppu.middleware.operation.InstanceModelLoader;
import de.tum.mw.ais.xppu.middleware.operation.ModelLoadException;

/**
 * Loads a model from an EMF model serialized in XMI format.
 *
 * @author Lucas Koehler
 *
 */
public class XmiInstanceModelLoader implements InstanceModelLoader {
	private static Logger logger = LoggerFactory.getLogger(XmiInstanceModelLoader.class);

	/**
	 * {@inheritDoc}
	 *
	 * @param modelFilePath
	 *            The path to the model file. Must have file extension .xmi or .isa88
	 */
	@Override
	public Enterprise loadModel(String modelFilePath) throws IOException, ModelLoadException {
		logger.debug("Try to load model from file at: {}", modelFilePath);

		// Registers the isa88 package so it is available to load the instance
		isa88Package.eINSTANCE.eClass();

		// Register the XMI resource factory for the .isa88 and .xmi extension: Other extensions are
		// not allowed for now.
		final Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
		final Map<String, Object> m = reg.getExtensionToFactoryMap();
		m.put("isa88", new XMIResourceFactoryImpl());
		m.put("xmi", new XMIResourceFactoryImpl());

		// Obtain a new resource set
		final ResourceSet resSet = new ResourceSetImpl();

		// Get the resource
		final Resource resource;
		try {
			resource = resSet.getResource(URI.createFileURI(modelFilePath), true);
		} catch (final RuntimeException e) {
			throw new ModelLoadException(String.format("Model could not be loaded from path: %s.", modelFilePath), e);
		}
		if (resource == null) {
			throw new ModelLoadException(String.format("Model could not be loaded from path: %s.", modelFilePath));
		}

		// Check that there is exactly one root level element and that it is an Enterprise
		final EList<EObject> topLevelContent = resource.getContents();
		if (topLevelContent.size() != 1) {
			throw new ModelLoadException(
					String.format("The model must contain exactly one root level object but it contains %d.",
							topLevelContent.size()));
		}
		final EObject rootEObject = topLevelContent.get(0);
		if (rootEObject instanceof Enterprise) {
			logger.info("Successfully loaded model with root Enterprise: {}", rootEObject.toString());
			return (Enterprise) rootEObject;
		}
		throw new ModelLoadException("The root EObject must be of type Enterprise.");
	}

}
