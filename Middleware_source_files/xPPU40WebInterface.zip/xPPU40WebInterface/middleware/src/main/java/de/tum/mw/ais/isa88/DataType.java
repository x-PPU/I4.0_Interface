/**
 */
package de.tum.mw.ais.isa88;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Data Type</b></em>'. <!--
 * end-user-doc -->
 *
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getDataType()
 * @model
 * @generated
 */
public interface DataType extends NamedElement {
} // DataType
