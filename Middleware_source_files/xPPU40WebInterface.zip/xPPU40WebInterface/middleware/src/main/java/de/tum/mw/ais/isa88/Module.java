/**
 */
package de.tum.mw.ais.isa88;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Module</b></em>'. <!--
 * end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.Module#getOwnedProperty <em>Owned Property</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.Module#getOwnedGeneralOperation <em>Owned General
 * Operation</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.Module#getDatatype <em>Datatype</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.Module#getInterface <em>Interface</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.Module#getBody <em>Body</em>}</li>
 * </ul>
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getModule()
 * @model
 * @generated
 */
public interface Module extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Owned Property</b></em>' containment reference list. The
	 * list contents are of type {@link de.tum.mw.ais.isa88.Property}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned Property</em>' containment reference list isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Owned Property</em>' containment reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getModule_OwnedProperty()
	 * @model containment="true"
	 * @generated
	 */
	EList<Property> getOwnedProperty();

	/**
	 * Returns the value of the '<em><b>Owned General Operation</b></em>' containment reference
	 * list. The list contents are of type {@link de.tum.mw.ais.isa88.GeneralOperation}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned General Operation</em>' containment reference list isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Owned General Operation</em>' containment reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getModule_OwnedGeneralOperation()
	 * @model containment="true"
	 * @generated
	 */
	EList<GeneralOperation> getOwnedGeneralOperation();

	/**
	 * Returns the value of the '<em><b>Datatype</b></em>' containment reference list. The list
	 * contents are of type {@link de.tum.mw.ais.isa88.DataType}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Datatype</em>' containment reference list isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Datatype</em>' containment reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getModule_Datatype()
	 * @model containment="true"
	 * @generated
	 */
	EList<DataType> getDatatype();

	/**
	 * Returns the value of the '<em><b>Interface</b></em>' reference. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interface</em>' reference isn't clear, there really should be more
	 * of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Interface</em>' reference.
	 * @see #setInterface(Interface)
	 * @see de.tum.mw.ais.isa88.isa88Package#getModule_Interface()
	 * @model
	 * @generated
	 */
	Interface getInterface();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.Module#getInterface <em>Interface</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Interface</em>' reference.
	 * @see #getInterface()
	 * @generated
	 */
	void setInterface(Interface value);

	/**
	 * Returns the value of the '<em><b>Body</b></em>' attribute. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Body</em>' attribute isn't clear, there really should be more of a
	 * description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Body</em>' attribute.
	 * @see #setBody(String)
	 * @see de.tum.mw.ais.isa88.isa88Package#getModule_Body()
	 * @model
	 * @generated
	 */
	String getBody();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.Module#getBody <em>Body</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Body</em>' attribute.
	 * @see #getBody()
	 * @generated
	 */
	void setBody(String value);

} // Module
