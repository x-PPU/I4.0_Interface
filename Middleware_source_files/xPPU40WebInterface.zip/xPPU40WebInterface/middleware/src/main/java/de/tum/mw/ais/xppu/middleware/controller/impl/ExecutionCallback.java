package de.tum.mw.ais.xppu.middleware.controller.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.tum.mw.ais.xppu.middleware.history.History;
import de.tum.mw.ais.xppu.middleware.history.HistoryException;
import de.tum.mw.ais.xppu.middleware.plc.ExecuteOperationCallback;

/**
 * The {@link ExecuteOperationCallback} that is used when this controller executes an operation.
 *
 * @author Lucas Koehler
 *
 */
class ExecutionCallback implements ExecuteOperationCallback {
	private static final Logger logger = LoggerFactory.getLogger(ExecutionCallback.class);

	private final History history;
	private final String executionId;

	public ExecutionCallback(History history, String executionId) {
		this.history = history;
		this.executionId = executionId;
	}

	@Override
	public void executionSuccessful(String operationId, int operationResult) {
		System.out.println("Success: " + operationId);
		try {
			history.completeOperation(executionId, operationResult);
		} catch (final HistoryException e) {
			logger.error("Could not add finish history entry.", e);
		}
	}

	@Override
	public void executionFailed(String operationId, int operationResult) {
		System.out.println("Failure (" + operationResult + "): " + operationId);
		try {
			history.completeOperation(executionId, operationResult);
		} catch (final HistoryException e) {
			logger.error("Could not add finish history entry.", e);
		}
	}

	@Override
	public void executionCanceled(String operationId, int operationResult) {
		// Do nothing as a history entry is already logged when the controller tells the PLC to
		// cancel the current operation.
	}
}
