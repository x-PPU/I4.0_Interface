package de.tum.mw.ais.xppu.middleware.history;

import java.time.Instant;
import java.util.List;

/**
 * The {@link History} is used to save recent events executed on the PLC. Thereby, the
 * {@link History} has a limited capacity. When this capacity is reached and a new entry is added,
 * the oldest entry is deleted according to the First-In-First-Out principle.
 *
 * @author Lucas Koehler
 *
 */
public interface History {

	/**
	 * Returns <code>true</code> when the PLC is currently busy with an operation. This is the case
	 * if an operation has been started in the past and it has not been completed or canceled, yet.
	 * This means the PLC is also busy if an operation is paused. A new operation can only be
	 * executed if the PLC is not busy.
	 *
	 * @return <code>true</code> if the PLC is busy, <code>false</code> otherwise
	 */
	boolean isBusy();

	/**
	 *
	 * @param executionId
	 *            The execution id to check
	 * @return <code>true</code> if the current execution process has the given execution id,
	 *         <code>false</code> otherwise
	 */
	boolean isCurrentExecution(String executionId);

	/**
	 * Adds an entry for starting to execute the operation with the given id and resolved path.
	 *
	 * @param operationId
	 *            The operation's id
	 * @param resolvedOperationPath
	 *            The operation usage's resolved path
	 * @return The {@link HistoryEntry} which was added to the history
	 * @throws HistoryException
	 *             If another operation is still running
	 */
	HistoryEntry startOperation(String operationId, String resolvedOperationPath) throws HistoryException;

	/**
	 * Adds an entry for starting to execute an operation belonging to a batch.
	 *
	 * @param executionId
	 *            The batch's and thereby this execution's execution id.
	 * @param operationId
	 *            The operation's id
	 * @param resolvedOperationPath
	 *            The operation usage's resolved path
	 * @return The {@link HistoryEntry} which was added to the history
	 * @throws HistoryException
	 *             If something went wrong
	 */
	HistoryEntry startBatchOperation(String executionId, String operationId, String resolvedOperationPath)
			throws HistoryException;

	/**
	 * Adds an entry for continuing the operation for the given execution id.
	 *
	 * @param executionId
	 *            The execution id of the process that is continued
	 * @return The {@link HistoryEntry} which was added to the history
	 * @throws HistoryException
	 *             If the given execution id does not match the history's current execution id
	 */
	HistoryEntry restartOperation(String executionId) throws HistoryException;

	/**
	 * Offers to add an entry for pausing the operation for the given execution id.
	 * <p>
	 *
	 *
	 * @param executionId
	 *            The execution id of the process that is paused
	 * @return The offered {@link HistoryEntry}
	 * @throws HistoryException
	 *             If the given execution id does not match the history's current execution id
	 */
	HistoryEntry offerHoldOperation(String executionId) throws HistoryException;

	/**
	 * Offers to add an entry for canceling the operation for the given execution id.
	 *
	 * @param executionId
	 *            The execution id of the process that is canceled
	 * @return The offered {@link HistoryEntry}
	 * @throws HistoryException
	 *             If the given execution id does not match the history's current execution id
	 */
	HistoryEntry offerAbortOperation(String executionId) throws HistoryException;

	/**
	 * Resets the offering mechanism to its original state as if the last offer did not happen. Does
	 * nothing if nothing was offered.
	 *
	 * @return The offered {@link HistoryEntry} or <code>null</code> if nothing was offered.
	 */
	HistoryEntry resetOffer();

	/**
	 * Finishes an earlier offered cancel or pause operation. If between the offering and finishing
	 * of the operation {@link #completeOperation(String, int)} has been called successfully, the
	 * offered operation is not added to the history.
	 *
	 * @return The added {@link HistoryEntry} for the cancel/pause operation that added to the
	 *         history
	 * @throws HistoryException
	 *             If there has not been offered any operation before calling this method or the
	 *             offered operation could not be finished
	 */
	HistoryEntry finishOffer() throws HistoryException;

	/**
	 * Adds an entry for finishing the current operation with the given result code
	 *
	 * @param executionId
	 *            The execution id of the process that is finished
	 * @param resultCode
	 *            The result of the currently executing operation
	 * @throws HistoryException
	 *             If there is no operation to finish
	 */
	void completeOperation(String executionId, int resultCode) throws HistoryException;

	/**
	 * @return The list of all entries in the history in chronological order (index 0 is the oldest
	 *         entry)
	 */
	List<HistoryEntry> getAllEntries();

	/**
	 * @param moduleName
	 *            The module name that must be present in a operation's resolved path
	 * @return The list of all entries in the history in chronological order whose operations'
	 *         resolved paths' contain the given module name
	 */
	List<HistoryEntry> getEntriesForModule(String moduleName);

	/**
	 *
	 * @param operationId
	 *            The operation id all returned entries must have
	 * @return The list of all entries in the history in chronological order with the given
	 *         operation id
	 */
	List<HistoryEntry> getEntriesForOperationId(String operationId);

	/**
	 *
	 * @param executionId
	 *            The process's execution id
	 * @return The list of all entries in the history in chronological order with the given
	 *         execution id
	 */
	List<HistoryEntry> getEntriesForExecutionId(String executionId);

	/**
	 * Removes the newest {@link HistoryEntry} from the history.
	 *
	 * @return The removed {@link HistoryEntry}, <code>null</code> if the history was empty
	 */
	HistoryEntry removeNewestEntry();

	/**
	 * Returns all {@link HistoryEntry history entries} newer or equally old as the given timestamp.
	 * <p>
	 * <strong>Important:</strong> Timezones are not considered. Every timestamp is treated as being
	 * in UTC.
	 *
	 * @param timestamp
	 *            The timestamp given as an {@link Instant}
	 * @return The filtered {@link HistoryEntry history entries}
	 */
	List<HistoryEntry> getEntriesNewerThan(Instant timestamp);

	/**
	 * Creates a new {@link HistoryEntry} for a batch with the given size
	 *
	 * @param size
	 *            The number of operations contained in the batch
	 * @return The created {@link HistoryEntry}
	 * @throws HistoryException
	 *             if the history is busy or in manual mode
	 */
	HistoryEntry startBatchExecution(int size) throws HistoryException;

	/**
	 * Creates a new {@link HistoryEntry} for the completion of a batch execution
	 *
	 * @param resultCode
	 *            Describes in which state the batch finishes. Uses the same codes as single
	 *            operations
	 * @return The created {@link HistoryEntry}
	 * @throws HistoryException
	 *             if there isn't any batch to finish
	 */
	HistoryEntry finishBatchExecution(int resultCode) throws HistoryException;

	/**
	 * Sets the mode to manual if it is currently set to automatic and the history is not busy.
	 *
	 * @return The created {@link HistoryEntry} if the mode was changed, <code>null</code> otherwise
	 * @throws HistoryException
	 *             if the history is currently busy
	 */
	HistoryEntry setManualMode() throws HistoryException;

	/**
	 * Sets the mode to automatic if it is currently set to manual and the history is not busy.
	 *
	 * @return The created {@link HistoryEntry} if the mode was changed, <code>null</code> otherwise
	 * @throws HistoryException
	 *             if the history is currently busy
	 */
	HistoryEntry setAutomaticMode() throws HistoryException;

	/**
	 * Sets or unsets an emergency stop of the PLC
	 *
	 * @param emergencyStop
	 *            <strong>true</strong>: the PLC was stopped, <strong>false</strong>: the stop was
	 *            resolved
	 * @return the created history entry
	 */
	HistoryEntry setEmergencyStop(boolean emergencyStop);
}
