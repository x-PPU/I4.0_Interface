/**
 */
package de.tum.mw.ais.isa88;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Interface</b></em>'. <!--
 * end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.Interface#getITF_property <em>ITF property</em>}</li>
 * </ul>
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getInterface()
 * @model
 * @generated
 */
public interface Interface extends NamedElement {
	/**
	 * Returns the value of the '<em><b>ITF property</b></em>' containment reference list. The list
	 * contents are of type {@link de.tum.mw.ais.isa88.ITF_Property}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ITF property</em>' containment reference list isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>ITF property</em>' containment reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getInterface_ITF_property()
	 * @model containment="true"
	 * @generated
	 */
	EList<ITF_Property> getITF_property();

} // Interface
