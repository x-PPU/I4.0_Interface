package de.tum.mw.ais.xppu.middleware.plc;

/**
 * Handles the result of an operation executed as part of a batch.
 *
 * @author Lucas Koehler
 *
 */
public interface ExecuteBatchOperationCallback extends ExecuteOperationCallback {
	/**
	 * Called when the execution start of a batch operation was indicated by the PLC via the
	 * appropriate result code.
	 *
	 * @param operationId
	 *            The operation id of the started operation
	 * @param resolvedOperationPath
	 *            The operation usage's resolved path
	 * @param resultCode
	 *            The result code that indicated the execution start
	 */
	void executionStarted(String operationId, String resolvedOperationPath, int resultCode);
}
