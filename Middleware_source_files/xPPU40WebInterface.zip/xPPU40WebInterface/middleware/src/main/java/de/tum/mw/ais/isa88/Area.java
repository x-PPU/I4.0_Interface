/**
 */
package de.tum.mw.ais.isa88;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Area</b></em>'. <!--
 * end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.Area#getOwnedModule <em>Owned Module</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.Area#getInterface <em>Interface</em>}</li>
 * </ul>
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getArea()
 * @model
 * @generated
 */
public interface Area extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Owned Module</b></em>' containment reference list. The list
	 * contents are of type {@link de.tum.mw.ais.isa88.Module}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned Module</em>' containment reference list isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Owned Module</em>' containment reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getArea_OwnedModule()
	 * @model containment="true"
	 * @generated
	 */
	EList<Module> getOwnedModule();

	/**
	 * Returns the value of the '<em><b>Interface</b></em>' containment reference list. The list
	 * contents are of type {@link de.tum.mw.ais.isa88.Interface}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interface</em>' containment reference list isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Interface</em>' containment reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getArea_Interface()
	 * @model containment="true"
	 * @generated
	 */
	EList<Interface> getInterface();

} // Area
