/**
 */
package de.tum.mw.ais.isa88;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Phase</b></em>'. <!--
 * end-user-doc -->
 *
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getPhase()
 * @model
 * @generated
 */
public interface Phase extends GeneralOperation {
} // Phase
