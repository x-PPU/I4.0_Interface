/**
 */
package de.tum.mw.ais.isa88;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Property</b></em>'. <!--
 * end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.Property#getType <em>Type</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.Property#getConstraintSet <em>Constraint Set</em>}</li>
 * </ul>
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getProperty()
 * @model
 * @generated
 */
public interface Property extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear, there really should be more of a
	 * description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(Module)
	 * @see de.tum.mw.ais.isa88.isa88Package#getProperty_Type()
	 * @model required="true"
	 * @generated
	 */
	Module getType();

	/**
	 * Sets the value of the '{@link de.tum.mw.ais.isa88.Property#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(Module value);

	/**
	 * Returns the value of the '<em><b>Constraint Set</b></em>' containment reference list. The
	 * list contents are of type {@link de.tum.mw.ais.isa88.ConstraintSet}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constraint Set</em>' containment reference list isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Constraint Set</em>' containment reference list.
	 * @see de.tum.mw.ais.isa88.isa88Package#getProperty_ConstraintSet()
	 * @model containment="true"
	 * @generated
	 */
	EList<ConstraintSet> getConstraintSet();

} // Property
