package de.tum.mw.ais.xppu.middleware.plc.opc;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;

import org.opcfoundation.ua.builtintypes.DataValue;
import org.opcfoundation.ua.builtintypes.LocalizedText;
import org.opcfoundation.ua.builtintypes.NodeId;
import org.opcfoundation.ua.core.ApplicationDescription;
import org.opcfoundation.ua.core.ApplicationType;
import org.opcfoundation.ua.transport.security.SecurityMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prosysopc.ua.ApplicationIdentity;
import com.prosysopc.ua.ServiceException;
import com.prosysopc.ua.StatusException;
import com.prosysopc.ua.client.MonitoredDataItem;
import com.prosysopc.ua.client.MonitoredDataItemListener;
import com.prosysopc.ua.client.Subscription;
import com.prosysopc.ua.client.UaClient;

import de.tum.mw.ais.xppu.middleware.history.History;
import de.tum.mw.ais.xppu.middleware.plc.ExecuteBatchOperationCallback;
import de.tum.mw.ais.xppu.middleware.plc.ExecuteOperationCallback;
import de.tum.mw.ais.xppu.middleware.plc.PlcConnection;
import de.tum.mw.ais.xppu.middleware.plc.PlcConnectionException;
import de.tum.mw.ais.xppu.middleware.plc.PlcInitializationException;

/**
 * An implementation of {@link PlcConnection} that connects to a PLC that runs a OPC UA server.
 *
 * @author Lucas Koehler
 *
 */
public class OpcUaConnection implements PlcConnection {
	// Application identity constants
	private static final String PRODUCT_URI = "urn:ais.mw.tum.de:UA:AisXppuMiddleware";
	// 'localhost' in the URI is converted to the actual host name of the executing computer
	private static final String APPLICATION_URI = "urn:localhost:UA:AisXppuMiddleware";
	private static final String APPLICATION_NAME = "AIS XPPU Middleware";

	private static final int MAX_BATCH_SIZE = 20;

	// BEGIN: OPC UA Server variable identifiers
	/**
	 * Variable identifier for the emergency stop.
	 */
	private static final String EMERGENCY_STOP = "GVL.EmergencyStop";
	private static final String AUTOMATIC_EXECUTION = "GVL.AutomaticExecution";
	// Operation variables
	// operation id
	private static final String OPERATION_STR_ID = ".strID";
	// execution flag
	private static final String OPERATION_START = ".iStart";
	// result
	private static final String OPERATION_STR_RESULT = ".strResult";

	/**
	 * Prefix for all variable identifiers that are used for executing operations in manual mode.
	 */
	private static final String MANUAL_OPERATION = "GVL.ManualOperation";
	private static final String MANUAL_OPERATION_START_EXECUTION = MANUAL_OPERATION + "_START_command";
	private static final String MANUAL_OPERATION_ABORT_EXECUTION = MANUAL_OPERATION + "_ABORT_command";
	private static final String MANUAL_OPERATION_START = MANUAL_OPERATION + OPERATION_START;
	private static final String MANUAL_OPERATION_ID = MANUAL_OPERATION + OPERATION_STR_ID;
	private static final String MANUAL_OPERATION_RESULT = MANUAL_OPERATION + OPERATION_STR_RESULT;

	/**
	 * Prefix for all variable identifiers (except for the operation array) that are used for executing operations in automatic/batch
	 * mode.
	 */
	private static final String AUTOMATIC_OPERATION = "GVL.AutomaticOperation";
	private static final String AUTOMATIC_OPERATIONS_ARRAY = "GVL.AutomaticOperations";
	private static final String AUTOMATIC_OPERATION_START_EXECUTION = AUTOMATIC_OPERATION + "_START_command";
	private static final String AUTOMATIC_OPERATION_ABORT_EXECUTION = AUTOMATIC_OPERATION + "_ABORT_command";
	// pause
	private static final String AUTOMATIC_OPERATION_HOLD_EXECUTION = AUTOMATIC_OPERATION + "_HOLD_command";
	// continue
	private static final String AUTOMATIC_OPERATION_RESTART_EXECUTION = AUTOMATIC_OPERATION + "_RESTART_command";

	// END: OPC UA Server variable identifiers

	// Constants defining the execution mode of an operation
	private static final short START_FALSE = 0;
	private static final short START_TRUE = 1;

	private static Logger logger = LoggerFactory.getLogger(OpcUaConnection.class);

	private boolean initialized;
	private boolean connected;
	private String serverUri;
	private Integer namespaceIndex;
	/**
	 * Do not use except in connect()
	 */
	private String namespaceUri;
	/**
	 * The delay in milliseconds that is waited when flags are switched two times in order to
	 * trigger falling or rising edges. This is done so that the PLC can register the falling/rising
	 * edges as it does not register them when flags are switched too quickly.
	 * <p>
	 * <strong>Example:</strong> StartExecution rising edge should be triggered:<br/>
	 * set StartExectuion to false<br/>
	 * wait flagSwitchDelay milliseconds<br/>
	 * set StartExecution to true
	 */
	private int flagSwitchDelay;
	/**
	 * The {@link History} which is notified in case of an emergency stop.
	 */
	private History history;

	private UaClient client;
	private Subscription subscription;
	private MonitoredDataItem emergencyStopResultItem;
	private MonitoredDataItem manualResultItem;
	private MonitoredDataItem[] automaticResultItems;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initialize(Map<Object, Object> configuration) throws PlcInitializationException {
		logger.debug("Start initializing...");
		if (initialized) {
			throw new PlcInitializationException("OpcUaPlcConnection was already initialized.");
		}
		if (connected) {
			throw new PlcInitializationException("OpcUaPlcConnection is already connected.");
		}

		// Read configuration parameters
		serverUri = readInitializationParameter(configuration, OpcUaSettings.SERVER_URI, String.class, true);
		namespaceIndex = readInitializationParameter(configuration, OpcUaSettings.NAMESPACE_INDEX, Integer.class,
				false);
		if (namespaceIndex == null) {
			namespaceUri = readInitializationParameter(configuration, OpcUaSettings.NAMESPACE_URI, String.class, true);
		}
		flagSwitchDelay = readInitializationParameter(configuration, OpcUaSettings.FLAG_SWITCH_DELAY, Integer.class,
				true);
		history = readInitializationParameter(configuration, OpcUaSettings.HISTORY, History.class, true);

		// configure the ua client
		try {
			client = new UaClient(serverUri);
		} catch (final URISyntaxException e) {
			throw new PlcInitializationException("The server uri has an invalid syntax.", e);
		}
		client.setApplicationIdentity(createApplicationIdentity());
		// XXX: Security for the PLC Connection may be configured here
		client.setSecurityMode(SecurityMode.NONE);

		logger.info("Initialized successfully. Server Uri: {}, Namespace Index: {}, Namespace Uri: {}", serverUri,
				namespaceIndex, namespaceUri);
		initialized = true;
	}

	/**
	 * Reads configuration parameter for the given key from the configuration map, checks that it is
	 * not <code>null</code>, and converts it to the type given by the valueClass parameter.
	 *
	 * @param configuration
	 *            The configuration map
	 * @param key
	 *            The configuration parameter key
	 * @param valueClass
	 *            The class to convert the value to
	 * @param required
	 *            Whether the parameter must be set for this {@link OpcUaConnection} to be
	 *            initialized correctly
	 * @return The converted configuration parameter's value
	 * @throws PlcInitializationException
	 *             if the value is null or cannot be converted to the given type
	 */
	private <T> T readInitializationParameter(Map<Object, Object> configuration, Object key, Class<T> valueClass,
			boolean required) throws PlcInitializationException {
		final Object valueObject = configuration.get(key);
		if (valueObject == null) {
			if (required) {
				throw new PlcInitializationException(
						String.format(
								"The required configuration parameter for key %s was null. Check whether you provided all necessessary parameters in the configuration file.",
								key));
			}
			return null;
		}
		try {
			return valueClass.cast(valueObject);
		} catch (final ClassCastException e) {
			throw new PlcInitializationException(
					String.format("The configuration parameter for key %1$s must be of type %2$s but is of type %3$s",
							key, valueClass.getSimpleName(), valueObject.getClass().getSimpleName()));
		}
	}

	/**
	 * Creates the {@link ApplicationIdentity} for this {@link UaClient} which is used to
	 * communicate with the PLC's OPC UA server.
	 *
	 * @return The created {@link ApplicationIdentity}
	 */
	private ApplicationIdentity createApplicationIdentity() {
		final ApplicationDescription appDescription = new ApplicationDescription();
		appDescription.setApplicationName(new LocalizedText(APPLICATION_NAME, Locale.ENGLISH));
		appDescription.setApplicationUri(APPLICATION_URI);
		appDescription.setProductUri(PRODUCT_URI);
		appDescription.setApplicationType(ApplicationType.Client);

		final ApplicationIdentity identity = new ApplicationIdentity();
		identity.setApplicationDescription(appDescription);
		return identity;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Connects to the OPC UA Server and resolves the namespace index if only a namespace uri was
	 * given. Configures necessary subscriptions with the OPC UA server.
	 */
	@Override
	public void connectAndConfigure() throws PlcConnectionException {
		if (!initialized) {
			throw new PlcConnectionException("OpcUaConnection has not been initialized, yet.");
		}

		logger.info("Start connecting to OPC UA Server at {}", serverUri);
		try {
			client.connect();
			client.setKeepSubscriptions(false);
		} catch (final ServiceException e) {
			initialized = false;
			throw new PlcConnectionException(
					"Connection failed. Please reinitialize with proper parameters and then connect again.", e);
		}
		logger.debug("Connected successfully. Now resolve namespace index if it was not given.");

		// Resolve namespace index from namespace uri if the index is not set
		if (namespaceIndex == null) {
			final int index = client.getAddressSpace().getNamespaceTable().getIndex(namespaceUri);
			if (index < 0) {
				initialized = false;
				logger.error(
						"No namespace index was set and the configured namespace uri does not resolve to a namespace index.");
				throw new IllegalStateException(
						"No namespace index was set and the configured namespace uri does not resolve to a namespace index.");
			}
			namespaceIndex = index;
			logger.debug("Namespace uri \"{}\" was resolved to namespace index {}", namespaceUri, namespaceIndex);
		}

		createAndConfigureSubscription();

		connected = true;
		logger.info("Connected successfully. Server URI: {}. Used namespace index: {}.", serverUri, namespaceIndex);
	}

	/**
	 * Creates and configures a new {@link Subscription} with the OPC UA server and saves it in the
	 * subscription field. {@link com.prosysopc.ua.client.MonitoredItem MonitoredItems} can be added
	 * to the subscription to track variable changes on the server.
	 *
	 * @throws PlcConnectionException
	 *             if something goes wrong creating the subscriptions
	 */
	private void createAndConfigureSubscription() throws PlcConnectionException {
		subscription = new Subscription();
		try {
			logger.debug("Create Subscription for monitoring values...");
			subscription.setPublishingInterval(50);
			subscription.setMaxKeepAliveCount(50000);
			subscription.setLifetimeCount(1000000);
			client.addSubscription(subscription);
			logger.info("Successfully created new Subscription and added it to the UaClient.");
			logger.debug("Add monitored items to subscription...");

			// emergency stop
			if (emergencyStopResultItem == null) {
				final NodeId emergencyStopNodeId = new NodeId(namespaceIndex, EMERGENCY_STOP);
				emergencyStopResultItem = new MonitoredDataItem(emergencyStopNodeId);
			}
			emergencyStopResultItem.setDataChangeListener(new EmergencyStopListener());
			subscription.addItem(emergencyStopResultItem);


			// manual result item
			final NodeId manualNodeId = new NodeId(namespaceIndex, MANUAL_OPERATION_RESULT);
			if (manualResultItem == null) {
				manualResultItem = new MonitoredDataItem(manualNodeId);
			}
			// data change listener is added when an operation is executed.
			subscription.addItem(manualResultItem);

			// automatic result items
			if (automaticResultItems == null) {
				automaticResultItems = new MonitoredDataItem[MAX_BATCH_SIZE];
				for (int i = 0; i < MAX_BATCH_SIZE; i++) {
					// OPC UA indices start at 1
					final String identifier = createBatchOperationResultIdentifier(i + 1);
					final NodeId batchNodeId = new NodeId(namespaceIndex, identifier);
					automaticResultItems[i] = new MonitoredDataItem(batchNodeId);
					subscription.addItem(automaticResultItems[i]);
				}
			}

			logger.info("Successfully added monitored items to subscription.");
		} catch (final ServiceException | StatusException e) {
			throw new PlcConnectionException("Configuring subscription failed", e);
		}
	}

	/**
	 * @param index
	 *            The index of the batch operation (careful: OPC UA indices start at 1)
	 * @return The OPC UA identifier of the batch operation
	 */
	private StringBuilder createBatchOperationIdentifier(int index) {
		final StringBuilder builder = new StringBuilder(AUTOMATIC_OPERATIONS_ARRAY);
		builder.append("[");
		builder.append(index);
		builder.append("]");
		return builder;
	}

	/**
	 * @param index
	 *            The index of the batch operation (careful: OPC UA indices start at 1)
	 * @return The OPC UA identifier of the batch operation's result field
	 */
	private String createBatchOperationResultIdentifier(int index) {
		final StringBuilder builder = createBatchOperationIdentifier(index);
		builder.append(OPERATION_STR_RESULT);
		return builder.toString();
	}

	/**
	 *
	 * @param index
	 *            The index of the batch operation (careful: OPC UA indices start at 1)
	 * @return The OPC UA identifier of the batch operation's operation id field
	 */
	private String createBatchOperationIdIdentifier(int index) {
		final StringBuilder builder = createBatchOperationIdentifier(index);
		builder.append(OPERATION_STR_ID);
		return builder.toString();
	}

	/**
	 *
	 * @param index
	 *            The index of the batch operation (careful: OPC UA indices start at 1)
	 * @return The OPC UA identifier of the batch operation's execute field
	 */
	private String createBatchOperationExecuteIdentifier(int index) {
		final StringBuilder builder = createBatchOperationIdentifier(index);
		builder.append(OPERATION_START);
		return builder.toString();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void startOperation(String operationId, ExecuteOperationCallback callback) throws PlcConnectionException {
		if (!connected) {
			throw new PlcConnectionException("Cannot execute operations while not connected.");
		}
		logger.debug("Try to execute operation with operation id: {}", operationId);
		if (subscription == null || !subscription.isConnected()) {
			// subscription was deleted from the server => create a new one
			createAndConfigureSubscription();
		}

		// If another operation is still running, cancel it first. This is only done for safety
		// reasons. Because of using a History, there should not be another operation running.
		// cancelOperationExecution();

		final NodeId operationIdNodeId = new NodeId(namespaceIndex, MANUAL_OPERATION_ID);
		final NodeId executeNodeId = new NodeId(namespaceIndex, MANUAL_OPERATION_START);
		try {
			// Write operation to the server, set execute flag
			client.writeValues(new NodeId[] { operationIdNodeId, executeNodeId },
					new Object[] { operationId, START_TRUE });
			manualResultItem.setDataChangeListener(new ResultChangeListener(manualResultItem, callback, operationId));
			// reset start execution flag
			triggerEdge(MANUAL_OPERATION_START_EXECUTION, true);
		} catch (final ServiceException | StatusException e) {
			throw new PlcConnectionException("Could not execute operation with id: " + operationId, e);
		}
		logger.info("Successfully told the server to execute operation with id: {}.", operationId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void holdOperationExecution(boolean manualOperation) throws PlcConnectionException {
		if (!connected) {
			throw new PlcConnectionException("Cannot pause an executing operation while not connected.");
		}
		logger.debug("Try to tell the server to pause the current operation.");

		try {
			if (manualOperation) {
				final NodeId executeNodeId = new NodeId(namespaceIndex, MANUAL_OPERATION_START);
				client.writeValue(executeNodeId, START_FALSE);
				// Do not delete the old result listener as it will be triggered when the execution
				// is continued and finished
			} else {
				triggerEdge(AUTOMATIC_OPERATION_HOLD_EXECUTION, true);
			}
		} catch (final ServiceException | StatusException e) {
			throw new PlcConnectionException("Could not pause operation execution", e);
		}
		logger.info("Successfully told the server to pause the current operation.");
	}

	@Override
	public void restartOperationExecution(boolean manualOperation) throws PlcConnectionException {
		if (!connected) {
			throw new PlcConnectionException("Cannot continue an operation while not connected.");
		}
		logger.debug("Try to tell the server to continue the currently paused operation.");

		try {
			if (manualOperation) {
				final NodeId executeNodeId = new NodeId(namespaceIndex, MANUAL_OPERATION_START);
				client.writeValue(executeNodeId, START_TRUE);
			} else {
				triggerEdge(AUTOMATIC_OPERATION_RESTART_EXECUTION, true);
			}
		} catch (final ServiceException | StatusException e) {
			throw new PlcConnectionException("Could not continue operation execution", e);
		}
		logger.info("Successfully told the server to continue the currently paused operation.");
	}

	@Override
	public void abortOperationExecution(boolean manualOperation) throws PlcConnectionException {
		if (!connected) {
			throw new PlcConnectionException("Cannot stop an executing operation while not connected.");
		}
		logger.debug("Try to tell the server to cancel the current operation.");

		try {
			if (manualOperation) {
				triggerEdge(MANUAL_OPERATION_ABORT_EXECUTION, true);
			} else {
				triggerEdge(AUTOMATIC_OPERATION_ABORT_EXECUTION, true);
			}
		} catch (final ServiceException | StatusException e) {
			throw new PlcConnectionException("Could not cancel operation execution", e);
		}
		logger.info("Successfully told the server to cancel the current operation.");
	}

	/**
	 * Triggers a rising or falling edge for the given variable.
	 *
	 * @param variable
	 *            The String identifying the variable to trigger
	 * @param risingEdge
	 *            triggers a rising edge for true and a falling edge for false
	 * @throws ServiceException
	 * @throws StatusException
	 */
	private void triggerEdge(String variable, boolean risingEdge) throws ServiceException, StatusException {
		final NodeId nodeId = new NodeId(namespaceIndex, variable);
		client.writeValue(nodeId, !risingEdge);
		if (flagSwitchDelay > 0) {
			try {
				Thread.sleep(flagSwitchDelay);
			} catch (final InterruptedException e) {
				logger.warn("Sleep was interrupted but execution can proceed normally.", e);
			}
		}
		client.writeValue(nodeId, risingEdge);
	}

	@Override
	public void executeBatch(String[] operationIds, String[] resolvedOperationPaths,
			ExecuteBatchOperationCallback[] callbacks)
					throws PlcConnectionException {
		if (!connected) {
			throw new PlcConnectionException("Cannot execute operations while not connected.");
		}
		logger.debug("Try to execute batch with operation ids: {}", Arrays.toString(operationIds));
		if (operationIds.length < 1 || operationIds.length > MAX_BATCH_SIZE) {
			throw new PlcConnectionException(
					String.format("There must be at least 1 and at most %d operation ids in a batch.", MAX_BATCH_SIZE));
		}
		if (operationIds.length != callbacks.length) {
			throw new PlcConnectionException("There must be the same number of operation ids and callbacks.");
		}
		if (operationIds.length != resolvedOperationPaths.length) {
			throw new PlcConnectionException(
					"There must be the same number of operation ids and resolved operation paths.");
		}

		cleanBatchOperations();

		final LinkedList<NodeId> nodes = new LinkedList<>();
		final LinkedList<Object> values = new LinkedList<>();
		for (int i = 0; i < operationIds.length; i++) {
			// OPC UA indices start at 1
			final NodeId idNode = new NodeId(namespaceIndex, createBatchOperationIdIdentifier(i + 1));
			final NodeId executeNode = new NodeId(namespaceIndex, createBatchOperationExecuteIdentifier(i + 1));

			nodes.add(idNode);
			nodes.add(executeNode);
			values.add(operationIds[i]);
			values.add(START_TRUE);
		}
		final NodeId[] nodesArray = nodes.toArray(new NodeId[nodes.size()]);
		try {
			client.writeValues(nodesArray, values.toArray());
			for (int i = 0; i < operationIds.length; i++) {
				automaticResultItems[i].setDataChangeListener(
						new BatchResultChangeListener(automaticResultItems[i], callbacks[i], operationIds[i],
								resolvedOperationPaths[i]));
			}
			triggerEdge(AUTOMATIC_OPERATION_START_EXECUTION, true);
		} catch (final ServiceException | StatusException e) {
			throw new PlcConnectionException("Could not execute batch with ids: " + Arrays.toString(operationIds), e);
		}
		logger.info("Successfully told PLC to execute batch with operation ids: {}", Arrays.toString(operationIds));
	}

	/**
	 * Resets the operation id and execute fields of all batch operation slots.
	 *
	 * @throws PlcConnectionException
	 *             if something goes wrong
	 */
	private void cleanBatchOperations() throws PlcConnectionException {
		final LinkedList<NodeId> nodes = new LinkedList<>();
		final LinkedList<Object> values = new LinkedList<>();

		for (int i = 0; i < MAX_BATCH_SIZE; i++) {
			// OPC UA indices start at 1
			final NodeId idNode = new NodeId(namespaceIndex, createBatchOperationIdIdentifier(i + 1));
			final NodeId executeNode = new NodeId(namespaceIndex, createBatchOperationExecuteIdentifier(i + 1));
			nodes.add(idNode);
			nodes.add(executeNode);
			values.add("");
			values.add(START_FALSE);
		}

		try {
			client.writeValues(nodes.toArray(new NodeId[nodes.size()]), values.toArray());
		} catch (ServiceException | StatusException e) {
			throw new PlcConnectionException("Could not clean batch operations", e);
		}
		logger.debug("Resetted operation id and execute fields of all batch operations.");
	}

	@Override
	public void setManualMode() throws PlcConnectionException {
		try {
			client.writeValue(new NodeId(namespaceIndex, AUTOMATIC_EXECUTION), false);
		} catch (final ServiceException | StatusException e) {
			throw new PlcConnectionException("Could not set manual mode", e);
		}
		logger.debug("Set manual mode on the PLC.");
	}

	@Override
	public void setAutomaticMode() throws PlcConnectionException {
		try {
			client.writeValue(new NodeId(namespaceIndex, AUTOMATIC_EXECUTION), true);
		} catch (final ServiceException | StatusException e) {
			throw new PlcConnectionException("Could not set automatic mode", e);
		}
		logger.debug("Set automatic mode on the PLC.");
	}

	private class EmergencyStopListener implements MonitoredDataItemListener {

		@Override
		public void onDataChange(MonitoredDataItem sender, DataValue prevValue, DataValue value) {
			final boolean emergencyStop = (boolean) value.getValue().getValue();
			if (emergencyStop) {
				logger.info("An emergency stop occurred.");
				history.setEmergencyStop(true);
				// Remove listeners from manual/automatic results
				manualResultItem.setDataChangeListener(null);
				for (final MonitoredDataItem item : automaticResultItems) {
					item.setDataChangeListener(null);
				}
				logger.debug("Removed listeners from manual and automatic operations' result fields");
			} else if (prevValue != null) {
				/*
				 * If prevValue is null this is the first notification of the current value.
				 * Therefore, if there is not stop, nothing has to be done because this is the
				 * standard case.
				 */
				logger.info("Emergency stop has been resolved.");
				history.setEmergencyStop(false);
			}
		}

	}
}
