/**
 */
package de.tum.mw.ais.isa88.impl;

import de.tum.mw.ais.isa88.ConstraintSet;
import de.tum.mw.ais.isa88.Module;
import de.tum.mw.ais.isa88.Property;
import de.tum.mw.ais.isa88.isa88Package;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Property</b></em>'. <!--
 * end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 * <li>{@link de.tum.mw.ais.isa88.impl.PropertyImpl#getType <em>Type</em>}</li>
 * <li>{@link de.tum.mw.ais.isa88.impl.PropertyImpl#getConstraintSet <em>Constraint Set</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PropertyImpl extends NamedElementImpl implements Property {
	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' reference. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected Module type;

	/**
	 * The cached value of the '{@link #getConstraintSet() <em>Constraint Set</em>}' containment
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getConstraintSet()
	 * @generated
	 * @ordered
	 */
	protected EList<ConstraintSet> constraintSet;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected PropertyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return isa88Package.Literals.PROPERTY;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Module getType() {
		if (type != null && type.eIsProxy()) {
			InternalEObject oldType = (InternalEObject) type;
			type = (Module) eResolveProxy(oldType);
			if (type != oldType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, isa88Package.PROPERTY__TYPE, oldType,
							type));
			}
		}
		return type;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Module basicGetType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setType(Module newType) {
		Module oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, isa88Package.PROPERTY__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList<ConstraintSet> getConstraintSet() {
		if (constraintSet == null) {
			constraintSet = new EObjectContainmentEList<ConstraintSet>(ConstraintSet.class, this,
					isa88Package.PROPERTY__CONSTRAINT_SET);
		}
		return constraintSet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case isa88Package.PROPERTY__CONSTRAINT_SET:
			return ((InternalEList<?>) getConstraintSet()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case isa88Package.PROPERTY__TYPE:
			if (resolve)
				return getType();
			return basicGetType();
		case isa88Package.PROPERTY__CONSTRAINT_SET:
			return getConstraintSet();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case isa88Package.PROPERTY__TYPE:
			setType((Module) newValue);
			return;
		case isa88Package.PROPERTY__CONSTRAINT_SET:
			getConstraintSet().clear();
			getConstraintSet().addAll((Collection<? extends ConstraintSet>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case isa88Package.PROPERTY__TYPE:
			setType((Module) null);
			return;
		case isa88Package.PROPERTY__CONSTRAINT_SET:
			getConstraintSet().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case isa88Package.PROPERTY__TYPE:
			return type != null;
		case isa88Package.PROPERTY__CONSTRAINT_SET:
			return constraintSet != null && !constraintSet.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} // PropertyImpl
