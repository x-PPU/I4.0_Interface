/**
 */
package de.tum.mw.ais.isa88;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Control Module</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.tum.mw.ais.isa88.isa88Package#getControlModule()
 * @model
 * @generated
 */
public interface ControlModule extends Module {
} // ControlModule
