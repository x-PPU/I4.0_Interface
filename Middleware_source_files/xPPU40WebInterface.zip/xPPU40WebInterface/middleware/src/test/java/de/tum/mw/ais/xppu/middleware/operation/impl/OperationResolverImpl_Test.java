package de.tum.mw.ais.xppu.middleware.operation.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import de.tum.mw.ais.isa88.Enterprise;
import de.tum.mw.ais.xppu.middleware.operation.ModelLoadException;
import de.tum.mw.ais.xppu.middleware.operation.OperationInformation;
import de.tum.mw.ais.xppu.middleware.operation.OperationInstance;

/**
 * JUnit test cases for {@link OperationResolverImpl}.
 * <p>
 * This test is only reliable if the tests for {@link XmiInstanceModelLoader} all succeed.
 *
 * @author Lucas Koehler
 *
 */
public class OperationResolverImpl_Test {

	private OperationResolverImpl resolver;
	private List<OperationInformation> operations;
	Enterprise modelRoot;

	/**
	 * Sets up the unit tests
	 *
	 * @throws ModelLoadException
	 * @throws IOException
	 */
	@Before
	public void setUp() throws IOException, ModelLoadException {
		resolver = new OperationResolverImpl();
		modelRoot = new XmiInstanceModelLoader().loadModel("src/test/resources/sampleInstance.isa88");
		assertNotNull(modelRoot);
		operations = new LinkedList<>();
		// Resolvable operations
		operations.add(new OperationInformationImpl("_1_2_2_P1_P1_O1", "DetectObject",
				"site(1).area(2).ownedModule(2).ownedProperty(1).type.ownedProperty(1).type.ownedGeneralOperation(1)"));
		operations.add(new OperationInformationImpl("_1_2_2_P2_P2_O1", "DetectObject",
				"site(1).area(2).ownedModule(2).ownedProperty(2).type.ownedProperty(2).type.ownedGeneralOperation(1)"));
		operations.add(new OperationInformationImpl("_1_2_2_P2_P3_O4", "MoveForward",
				"site(1).area(2).ownedModule(2).ownedProperty(2).type.ownedProperty(3).type.ownedGeneralOperation(4)"));
		operations.add(new OperationInformationImpl("_1_2_2_P3_P3_O2", "InitializeComponents",
				"site(1).area(2).ownedModule(2).ownedProperty(3).type.ownedProperty(3).type.ownedGeneralOperation(2)"));
		// multiref without index
		operations.add(new OperationInformationImpl("_1_2_2_P3_P3_O2_NO_INDEX", "InitializeComponents",
				"site(1).area(2).ownedModule.ownedProperty(3).type.ownedProperty(3).type.ownedGeneralOperation(2)"));
		// non existing feature
		operations.add(new OperationInformationImpl("_1_2_2_P3_P3_O2_NON_EXISTING_FEATURE", "InitializeComponents",
				"site(1).area(2).nonExistingFeature.ownedProperty(3).type.ownedProperty(3).type.ownedGeneralOperation(2)"));
	}

	/**
	 * Test method for {@link de.tum.mw.ais.xppu.middleware.operation.impl.OperationResolverImpl#resolveOperations(java.util.List, de.tum.mw.ais.isa88.Enterprise)}.
	 */
	@Test
	public void testResolveOperations() {
		final Map<String, OperationInstance> result = resolver.resolveOperations(operations, modelRoot);
		assertEquals(4, result.size());
		assertTrue(result.keySet().contains("_1_2_2_P1_P1_O1"));
		assertTrue(result.keySet().contains("_1_2_2_P2_P2_O1"));
		assertTrue(result.keySet().contains("_1_2_2_P2_P3_O4"));
		assertTrue(result.keySet().contains("_1_2_2_P3_P3_O2"));

		// Correct operations resolved
		assertEquals("DetectObject", result.get("_1_2_2_P1_P1_O1").getOperation().getName());
		assertEquals("DetectObject", result.get("_1_2_2_P2_P2_O1").getOperation().getName());
		assertEquals("MoveForward", result.get("_1_2_2_P2_P3_O4").getOperation().getName());
		assertEquals("InitializeComponents", result.get("_1_2_2_P3_P3_O2").getOperation().getName());

		assertEquals("AIS/Garching/XPPU/SorterUnit/ConvUnit1/ConveyorUnit/LS1/LightSensor/DetectObject",
				result.get("_1_2_2_P1_P1_O1").getResolvedPath());
	}

}
