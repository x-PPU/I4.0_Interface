package de.tum.mw.ais.xppu.middleware.operation.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import de.tum.mw.ais.isa88.Area;
import de.tum.mw.ais.isa88.Enterprise;
import de.tum.mw.ais.isa88.Site;
import de.tum.mw.ais.xppu.middleware.operation.ModelLoadException;

/**
 * @author Lucas Koehler
 *
 */
public class XmiInstanceModelLoader_Test {

	private XmiInstanceModelLoader modelLoader;

	/**
	 * Set up.
	 */
	@Before
	public void setUp() {
		modelLoader = new XmiInstanceModelLoader();
	}

	/**
	 * Test method for
	 * {@link de.tum.mw.ais.xppu.middleware.operation.impl.XmiInstanceModelLoader#loadModel(java.lang.String)}.
	 *
	 * @throws ModelLoadException
	 * @throws IOException
	 */
	@Test
	public void testLoadModel() throws IOException, ModelLoadException {
		final Enterprise enterprise = modelLoader.loadModel("src/test/resources/sampleInstance.isa88");
		assertNotNull(enterprise);
		assertEquals("AIS", enterprise.getName());
		assertEquals(1, enterprise.getSite().size());
		final Site garching = enterprise.getSite().get(0);
		assertEquals("Garching", garching.getName());
		assertEquals(2, garching.getArea().size());
		final Area repository = garching.getArea().get(0);
		final Area xppu = garching.getArea().get(1);
		assertEquals("Repository", repository.getName());
		assertEquals("XPPU", xppu.getName());
	}

	/**
	 * Test method for
	 * {@link de.tum.mw.ais.xppu.middleware.operation.impl.XmiInstanceModelLoader#loadModel(java.lang.String)}.
	 *
	 * @throws ModelLoadException
	 * @throws IOException
	 */
	@Test(expected = ModelLoadException.class)
	public void testLoadModelIllegalFileExtension() throws IOException, ModelLoadException {
		modelLoader.loadModel("src/test/resources/sampleInstance.model");
	}

	/**
	 * Test method for
	 * {@link de.tum.mw.ais.xppu.middleware.operation.impl.XmiInstanceModelLoader#loadModel(java.lang.String)}.
	 *
	 * @throws ModelLoadException
	 * @throws IOException
	 */
	@Test(expected = ModelLoadException.class)
	public void testLoadModelNoEnterprise() throws IOException, ModelLoadException {
		modelLoader.loadModel("src/test/resources/sampleInstanceNoEnterprise.isa88");
	}
}
