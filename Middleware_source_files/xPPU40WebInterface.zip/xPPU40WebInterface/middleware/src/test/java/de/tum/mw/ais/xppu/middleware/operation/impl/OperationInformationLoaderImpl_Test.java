package de.tum.mw.ais.xppu.middleware.operation.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import de.tum.mw.ais.xppu.middleware.operation.OperationInformation;

/**
 * JUnit test cases for {@link OperationInformationLoaderImpl}.
 *
 * @author Lucas Koehler
 *
 */
public class OperationInformationLoaderImpl_Test {

	private OperationInformationLoaderImpl loader;

	/**
	 * Set up.
	 */
	@Before
	public void setUp() {
		loader = new OperationInformationLoaderImpl();
	}

	/**
	 * Test method for
	 * {@link de.tum.mw.ais.xppu.middleware.operation.impl.OperationInformationLoaderImpl#loadOperationInformation(java.lang.String)}.
	 *
	 * @throws IOException
	 */
	@Test
	public void testLoadOperationInformation() throws IOException {
		final List<OperationInformation> result = loader
				.loadOperationInformation("src/test/resources/sampleInstance_operationList.txt");
		assertEquals(21, result.size());
		// sample check the read in data
		assertFalse(result.contains(null));
		assertEquals("_1_2_2_P1_P1_O1", result.get(0).getOperationId());
		assertEquals(
				"site(1).area(2).ownedModule(2).ownedProperty(1).type.ownedProperty(3).type.ownedGeneralOperation(1)",
				result.get(2).getPath());
		assertEquals("MoveForward", result.get(5).getName());
		assertEquals("_1_2_2_P3_P3_O5", result.get(20).getOperationId());
	}

	/**
	 * Test method for
	 * {@link de.tum.mw.ais.xppu.middleware.operation.impl.OperationInformationLoaderImpl#loadOperationInformation(java.lang.String)}.
	 *
	 * @throws IOException
	 */
	@Test(expected = FileNotFoundException.class)
	public void testLoadOperationInformationFileDoesNotExist() throws IOException {
		loader.loadOperationInformation("src/test/resources/this_does_not_exist.txt");
	}
}
